const webpack = require('webpack');
const path = require('path');

module.exports = {
  plugins: [
    new webpack.DefinePlugin({
      APP_VERSION: JSON.stringify(require('./package.json').version),
      MIX_ENV: JSON.stringify(process.env.NODE_ENV),
    }),
  ],
  resolve: {
    alias: {
      '@': path.resolve(__dirname, 'src'),
    },
  },
  module: {
    rules: [
      {
        test: /\.vue$/,
        loader: 'vue-loader',
        options: {
          reactivityTransform: true,
        }
      },
      {
        test: /\.md$/,
        use: [
          {
            loader: 'html-loader',
          },
          {
            loader: 'markdown-loader',
            options: {
              // See https://marked.js.org/using_advanced#options
            },
          },
        ],
      }
    ]
  }
};

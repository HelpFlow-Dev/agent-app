# Setup local development environment

## HF and LC users
Each team member should test using their respective LC and HF account both in HF and LC, more on this in the **Testing** section of the [README](README.md) file.

In this guide we'll assume you want to test from `sandbox3@helpflow.net` account.

## Setup
### Step 1 - Sync LC tags
We need to sync up the tags from our staging instance.

Export `lc_tags` table from staging DB **including auto-incrementing IDs** and import it to your local DB.

### Step 2 - HF API token
Find `sandbox3@helpflow.net` user in `users` table in staging DB and copy `api_token` to the same `sandbox3@helpflow.net` user in your local DB.

### Step 3 - LC PAT token
Find `sandbox3@helpflow.net` user in `agents` table in your local DB, add this as `livechat_base64_token`:

```
Y2VhNDFmNWMtNTFlMi00N2FhLTk2ZDEtNmU3Mjk4YjdmZWY0OmRhbDpuNjdVcFZtOFlnU09Ha3kzUnM0SHNwcDN6YTg=
```

### Step 4 - LC API
You need to update .env file so your local instance could use LiveChat API.

Credentials for `sandbox3@helpflow.net` LiveChat user:

```
LIVECHAT_USERNAME=cea41f5c-51e2-47aa-96d1-6e7298b7fef4
LIVECHAT_API_KEY=dal:n67UpVm8YgSOGky3Rs4Hspp3za8

LIVECHAT_V3_ENDPOINT="https://api.livechatinc.com/v3.5/"
LIVECHAT_V3_USERNAME=cea41f5c-51e2-47aa-96d1-6e7298b7fef4
LIVECHAT_V3_API_KEY=dal:n67UpVm8YgSOGky3Rs4Hspp3za8
```

### Step 5 - Verifying HAS works
Time to test that Agent Chat app works.

First, go to local HelpFlow instance and log in as `sandbox3@helpflow.net`.

Open Agent Chat app locally, typically found at http://helpflow.test/agent-app/#/.

Update your status to "Accepting", it should also update your LiveChat status, you can verify this by visiting https://my.livechatinc.com/chats.

Then visit sandbox website for STEEL client at https://staging.helpflow.net/sandbox/steel.html

You should be able to start a chat as a visitor and you should see an incoming chat. Yay!

/** @type {import('tailwindcss').Config} */
module.exports = {
  darkMode: 'class',
  content: [
    "./src/**/*.{vue,js,ts,jsx,tsx}",
  ],
  theme: {
    screens: {
      'laptop': '1280px',
      'desktop': '1600px',
    },
    extend: {
      animation: {
        'bounce-sm': 'bounce-sm 1s ease-in-out infinite',
        'checkbox-check': 'checkbox-check 0.4s ease',
        'checkbox-uncheck': 'checkbox-uncheck 0.4s ease',
        'pulse-fast': 'pulse 1s cubic-bezier(0.4, 0, 0.6, 1) infinite',
        'typing-indicator': 'typing-indicator 1.4s infinite both',
      },
      keyframes: {
        'bounce-sm': {
          '0%, 100%': { transform: 'translateY(-13%)', 'animation-timing-function': 'cubic-bezier(0.8, 0, 1, 1)' },
          '50%': { transform: 'translateY(0)', 'animation-timing-function': 'cubic-bezier(0, 0, 0.2, 1)' },
        },
        'typing-indicator': {
          '0%': { opacity: '0.2' },
          '20%': { opacity: '0.6' },
          '100%': { opacity: '0.2' },
        },
        'checkbox-check': {
          '50%': { scale: '0.9' },
        },
        'checkbox-uncheck': {
          '50%': { scale: '0.9' },
        },
      }
    },
  },
  plugins: [],
}

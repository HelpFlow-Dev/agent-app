<script setup>
import { inject, onMounted, onUnmounted, watch } from 'vue';
import { useRoute, useRouter } from 'vue-router';
import { useAppStore } from '@/stores/app';
import { useChatsStore } from '@/stores/chats';
import { useToast } from '@/stores/toasts';
import BaseTextMessage from '@/components/BaseTextMessage.vue';
import TheChatDeactivatedMessage from '@/components/TheChatDeactivatedMessage.vue';
import TheChatHeader from '@/components/TheChatHeader.vue';
import TheChatFileInput from '@/components/TheChatFileInput.vue';
import TheChatInputBox from '@/components/TheChatInputBox.vue';
import TheChatMessageHistory from '@/components/TheChatMessageHistory.vue';
import TheChatTagBox from '@/components/TheChatTagBox.vue';

const app = useAppStore();
const chats = useChatsStore();
const route = useRoute();
const router = useRouter();
const toast = useToast();
const appEnvironment = inject('appEnvironment');

let dropZoneIsVisible = $ref(false);

watch(() => route.params.id, handleRouteChange);

onMounted(() => {
  if (appEnvironment !== 'production') console.debug('[onMounted:ChatView]');

  if (!app.livechatEnabled) {
    router.push({ name: 'home' });
  } else {
    handleRouteChange();
  }
});

onUnmounted(() => {
  if (appEnvironment !== 'production') console.debug('[onUnmounted:ChatView]');
});

function showDropZone() {
  dropZoneIsVisible = !chats.activeChat.is_deactivated && !chats.activeChat.is_unassigned;
}

async function handleRouteChange() {
  let chatId = route.params.id;

  if (route.name !== 'chat' || !chatId) return;

  if (appEnvironment !== 'production') console.log('Loading chat #' + chatId + '...');

  await chats
    .openChat(chatId)
    .then(function (chat) {
      setTimeout(() => {
        // We'll broadcast this message again because some agents complained it doesn't work 100% of time
        chats.broadcastChatSwitchedMessage(chat);
      }, 100);
    })
    .catch(function () {
      if (chatId) toast.chatNotFound(chatId);

      router.push({ name: 'home' });
    });
}
</script>

<template>
  <div v-if="chats.activeChatIsLoaded" class="relative flex flex-1 flex-col">
    <TheChatHeader />

    <div class="relative flex flex-1 shrink-0 flex-col">
      <div
        class="absolute inset-0 flex w-full flex-col"
        @dragenter.prevent="showDropZone()"
        @dragover.prevent="showDropZone()"
      >
        <TheChatFileInput
          v-if="!chats.activeChat.is_deactivated && !chats.activeChat.is_unassigned"
          :show-drop-zone="dropZoneIsVisible"
          @left-drop-zone="dropZoneIsVisible = false"
        />

        <TheChatMessageHistory
          :chat="chats.activeChat"
          :events="chats.getCurrentThreadEvents(chats.activeChat)"
        />

        <div
          class="flex shrink-0 flex-col border-gray-200 px-3 pb-3"
          :class="{
            'border-t-2': chats.activeChat.is_deactivated || chats.activeChat.is_unassigned,
          }"
        >
          <TheChatDeactivatedMessage v-if="(chats.activeChat.is_deactivated || chats.activeChat.is_unassigned) && !chats.activeChat.visitor.banned_until" />
          <TheChatInputBox v-if="!chats.activeChat.is_deactivated && !chats.activeChat.is_unassigned" />
          <TheChatTagBox />
        </div>
      </div>
    </div>
  </div>
</template>

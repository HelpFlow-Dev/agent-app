<script setup>
import { inject, onMounted, onUnmounted } from 'vue';
import { useRouter } from 'vue-router';
import { DateTime } from 'luxon';
import { formatLuxonChatTimerDuration, waitFor } from '@/helpers';
import { useAppStore } from '@/stores/app';
import { useChatsStore } from '@/stores/chats';
import { useClientsStore } from '@/stores/clients';
import objectPath from 'object-path';
import IconLoader from '@/components/icons/IconLoader.vue';
import BaseAvatar from '@/components/BaseAvatar.vue';
import BaseButton from '@/components/BaseButton.vue';
import BaseTextMessage from '@/components/BaseTextMessage.vue';

const app = useAppStore();
const chats = useChatsStore();
const clients = useClientsStore();
const router = useRouter();
const appEnvironment = inject('appEnvironment');
const now = inject('now');

// All supervisable chats will be loaded to this variable
let supervisableChats = $ref({});

// Interval for loadSupervisableChats method
let loadSupervisableChatsInterval = $ref(null);

// Determines if agent should the the page loader in UI
let isLoaded = $ref(false);

// List of chats that we're currently loading (after "Supervise chat" button is clicked)
let loadingChatIds = $ref([]);

onMounted(() => {
  if (appEnvironment !== 'production') console.debug('[onMounted:SuperviseView]');

  if (!app.livechatEnabled) {
    router.push({ name: 'home' });
  } else {
    loadSupervisableChats();

    loadSupervisableChatsInterval = setInterval(loadSupervisableChats, 1000 * 4); // Every 4 seconds
  }
});

onUnmounted(() => {
  if (appEnvironment !== 'production') console.debug('[onUnmounted:SuperviseView]');

  clearInterval(loadSupervisableChatsInterval);
});

async function superviseChat(chatId) {
  // Add chat to the list of loading chats to hide the "Supervise chat" button
  if (loadingChatIds.indexOf(chatId) === -1) {
    loadingChatIds.push(chatId);
  }

  try {
    // This call can throw errors
    await chats.superviseChat(chatId);

    let condition = function () {
      return chats.activeChatIds.includes(chatId);
    };

    // Remove chat from list of loading chats, but only after it's loaded
    waitFor(condition, function() {
      loadingChatIds = loadingChatIds.filter(function(id) { return id !== chatId });
    });
  } catch (error) {
    console.error(error);

    // Remove chat from loading chats
    loadingChatIds = loadingChatIds.filter(function(id) { return id !== chatId });
  }
}

async function loadSupervisableChats() {
  let chatSummaries = await chats.getSupervisableChats();

  // Sort chats by starting timestamp, from newest to oldest
  supervisableChats = chatSummaries.sort(function(aChatData, bChatData) {
    let aThreadCreatedAt = DateTime.fromISO(aChatData.last_thread_summary.created_at);
    let bThreadCreatedAt = DateTime.fromISO(bChatData.last_thread_summary.created_at);

    return bThreadCreatedAt.toMillis() - aThreadCreatedAt.toMillis();
  });

  isLoaded = true;
}

function getChatTimerDiffFormatted(chatData, now) {
  let threadCreatedAt = DateTime.fromISO(chatData.last_thread_summary.created_at);

  // We should not allow negative values because
  // in some cases agent's clock on local machine can be off by a few seconds
  if (threadCreatedAt && DateTime.now().diff(threadCreatedAt).as('seconds') >= 0) {
    return formatLuxonChatTimerDuration(DateTime.now().diff(threadCreatedAt));
  }

  return '00:00:00';
}

function getClientCode(chatData) {
  let clientGroups = objectPath.get(chatData, 'access.group_ids', []);

  if (clientGroups.length) {
    let client = clients.getClientByLiveChatId(clientGroups[0]);

    if (client) return client.code;
  }

  return '—';
}

function getChattingAgentAvatarUrl(chatData) {
  let agent = chats.getChattingAgentFromChatSummary(chatData);

  if (agent) return agent.avatar_url;

  return null;
}

function getChattingAgentName(chatData) {
  let agent = chats.getChattingAgentFromChatSummary(chatData);

  if (agent) return agent.display_name;

  return 'Unknown';
}

function getVisitorName(chatData) {
  let visitorUser = chats.getVisitorUserFromChatSummary(chatData);

  return objectPath.get(visitorUser, 'name', 'Visitor');
}

function getVisitorLocationFormatted(chatData) {
  let visitorUser = chats.getVisitorUserFromChatSummary(chatData);

  let locationObject = objectPath.get(visitorUser, 'last_visit.geolocation', null);

  if (locationObject) {
    let location = '';

    if (locationObject.city) location += locationObject.city + ', ';

    if (locationObject.region) location += locationObject.region + ', ';

    if (locationObject.country) location += locationObject.country + ', ';

    // Remove ", " from the end (if present)
    return location.replace(/\,\ $/, '');
  }

  return 'Unknown location';
}

function getVisitorCountryName(chatData) {
  let visitorUser = chats.getVisitorUserFromChatSummary(chatData);

  let locationObject = objectPath.get(visitorUser, 'last_visit.geolocation', null);

  if (locationObject && locationObject.country) return locationObject.country;

  return 'Unknown';
}

function getVisitorCountryCodeForFlagIcon(chatData) {
  let visitorUser = chats.getVisitorUserFromChatSummary(chatData);

  let locationObject = objectPath.get(visitorUser, 'last_visit.geolocation', null);

  if (locationObject && locationObject.country_code) return locationObject.country_code.toLowerCase();

  return 'xx';
}
</script>

<template>
  <div v-if="!isLoaded" class="flex w-full flex-1 justify-center items-center flex-col p-3">
    <BaseTextMessage class="flex-col">
      <IconLoader size="lg" class="text-blue-500"></IconLoader>

      <div class="mt-3">Loading supervisable chats...</div>

      <BaseButton class="mt-3" variant="gray-outline" @click="router.push({ name: 'home' })">
        Go back
      </BaseButton>
    </BaseTextMessage>
  </div>
  <div v-else-if="supervisableChats.length === 0" class="flex w-full flex-1 flex-col p-3">
    <BaseTextMessage class="flex-col">
      <div>
        <!-- Active chats of other agents that are available for supervision will appear here -->
        No chats available for supervision
      </div>

      <BaseButton class="mt-3" variant="gray-outline" @click="router.push({ name: 'home' })">
        Go back
      </BaseButton>
    </BaseTextMessage>
  </div>
  <div v-else class="relative rounded max-h-[300px]">
    <table class="table-auto border-separate border-spacing-0 w-full">
      <thead class="bg-gray-50 sticky top-0 z-10">
        <tr>
          <th class="border-b-2 font-medium px-3 py-5 text-gray-400 whitespace-nowrap text-center">
            Visitor
          </th>
          <th class="border-b-2 border-l-2 font-medium px-3 py-5 text-gray-400 whitespace-nowrap text-center">
            Chat ID
          </th>
          <th class="border-b-2 border-l-2 border-gray-200 font-medium px-3 py-5 text-gray-400 whitespace-nowrap text-center w-[1px]">
            Client
          </th>
          <th class="border-b-2 border-l-2 border-gray-200 font-medium px-3 py-5 text-gray-400 whitespace-nowrap text-center w-[1px]">
            Chatting with
          </th>
          <th class="border-b-2 border-l-2 border-gray-200 font-medium px-3 py-5 text-gray-400 whitespace-nowrap text-center w-[1px]">
            Time chatting
          </th>
          <th class="border-b-2 border-l-2 border-gray-200 font-medium px-3 py-5 text-gray-400 whitespace-nowrap text-center w-[1px]">
            Actions
          </th>
        </tr>
      </thead>
      <tbody>
        <tr v-for="chatData in supervisableChats" :key="chatData.id" class="border-b-2">
          <td class="border-b-2 border-gray-200 p-3">
            <div class="flex flex-row items-center">
              <div class="pr-3 hidden laptop:flex">
                <BaseAvatar variant="visitor" :text="getVisitorName(chatData)" />
              </div>
              <div>
                <div class="whitespace-nowrap">
                  {{ getVisitorName(chatData) }}
                </div>
                <div class="whitespace-nowrap">
                  <span
                    class="fi mr-1.5"
                    :class="'fi-' + getVisitorCountryCodeForFlagIcon(chatData)"
                    v-tooltip="getVisitorCountryName(chatData)"
                  ></span><span>{{ getVisitorLocationFormatted(chatData) }}</span>
                </div>
              </div>
            </div>
          </td>
          <td class="border-b-2 border-gray-200 p-3 whitespace-nowrap text-center">
            {{ chatData.last_thread_summary.id }}
          </td>
          <td class="border-b-2 border-gray-200 p-3 whitespace-nowrap text-center">
            {{ getClientCode(chatData) }}
          </td>
          <td class="border-b-2 border-gray-200 p-3">
            <div class="flex flex-row items-center">
              <div class="flex pr-3 hidden laptop:flex">
                <BaseAvatar v-if="getChattingAgentAvatarUrl(chatData)" variant="agent" :url="getChattingAgentAvatarUrl(chatData)" />
                <BaseAvatar v-else variant="agent" :text="getChattingAgentName(chatData)" />
              </div>
              <div>
                <div class="whitespace-nowrap">
                  {{ getChattingAgentName(chatData) }}
                </div>
              </div>
            </div>
          </td>
          <td class="border-b-2 border-gray-200 p-3 whitespace-nowrap font-mono text-center">
            {{ getChatTimerDiffFormatted(chatData, now) }}
          </td>
          <td class="border-b-2 border-gray-200 p-3 text-center min-w-[149px] laptop:min-w-[161px] desktop:min-w-[183px]">
            <BaseButton
              v-if="loadingChatIds.includes(chatData.id)"
              class="w-full whitespace-nowrap"
              variant="gray"
              :disabled="true"
              :show-loader="true"
            >
              <span class="desktop:hidden">Loading...</span>
              <span class="hidden desktop:inline">Loading chat...</span>
            </BaseButton>
            <BaseButton
              v-else-if="chats.activeChatIds.includes(chatData.id)"
              class="w-full whitespace-nowrap"
              variant="gray-outline"
              @click="router.push({ name: 'chat', params: { id: chatData.id } })"
            >
              <span>Go to chat</span>
            </BaseButton>
            <BaseButton
              v-else
              class="w-full whitespace-nowrap"
              variant="gray"
              :disabled="chats.chatIds.includes(chatData.id) || !app.online || !app.livechatOnline"
              @click="superviseChat(chatData.id)"
            >
              <span>Supervise</span> <span class="hidden laptop:inline">chat</span>
            </BaseButton>
          </td>
        </tr>
      </tbody>
    </table>

    <div class="text-center py-3">
      <BaseButton variant="gray-outline" @click="router.push({ name: 'home' })">
        Go back
      </BaseButton>
    </div>
  </div>
</template>

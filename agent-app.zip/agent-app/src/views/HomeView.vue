<script setup>
import { inject, onMounted, onUnmounted } from 'vue';
import { useRouter } from 'vue-router';
import { useAppStore } from '@/stores/app';
import BaseButton from '@/components/BaseButton.vue';
import BaseTextMessage from '@/components/BaseTextMessage.vue';

const app = useAppStore();
const router = useRouter();
const appEnvironment = inject('appEnvironment');

onMounted(() => {
  if (appEnvironment !== 'production') console.debug('[onMounted:HomeView]');
});

onUnmounted(() => {
  if (appEnvironment !== 'production') console.debug('[onUnmounted:HomeView]');
});
</script>

<template>
  <div class="flex w-full flex-1 flex-col p-3">
    <BaseTextMessage class="flex-col">
      <div>
        Open a chat to start messaging
      </div>
      <BaseButton
        v-if="app.livechatEnabled"
        class="mt-3"
        variant="primary"
        :disabled="!app.online || !app.livechatOnline"
        @click="router.push({ name: 'supervise' })"
      >
        Supervise chats
      </BaseButton>
    </BaseTextMessage>
  </div>
</template>

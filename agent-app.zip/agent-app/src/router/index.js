import { createRouter, createWebHashHistory } from 'vue-router';
import HomeView from '@/views/HomeView.vue';
import ChatView from '@/views/ChatView.vue';
import SuperviseView from '@/views/SuperviseView.vue';

const router = createRouter({
    history: createWebHashHistory(),
    routes: [
        {
            path: '/',
            name: 'home',
            component: HomeView,
        },
        {
            path: '/chats/:id',
            name: 'chat',
            component: ChatView,
        },
        {
            path: '/supervise',
            name: 'supervise',
            component: SuperviseView,
        },
        {
            path: '/:pathMatch(.*)*',
            name: '404',
            redirect: '/',
        },
    ],
});

export default router;

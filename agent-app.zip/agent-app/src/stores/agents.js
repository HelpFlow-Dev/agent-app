import { defineStore } from 'pinia';
import { DateTime } from 'luxon';
import { useToast } from '@/stores/toasts';
import { formatLuxonDuration } from '@/helpers';
import axios from 'axios';

export const useAgentsStore = defineStore('agents', {
  // data
  state: () => ({
    agents: [
      /*
        Each agent has these fields:
        - id
        - livechat_id
        - livechat_routing_status (offline, not_accepting_chats, accepting_chats)
        - display_name

        Each agent has these additional fields fields if they have a HelpFlow account:
        - user_id
        - email

        Auth agent has these additional fields loaded from LiveChat:
        - livechat_email
        - livechat_name
        - livechat_avatar
        - livechat_role
        - livechat_type
      */
    ],
    authAgentId: null,
    privateMessageModeAvailable: false,
    privateMessageModePlans: ['business', 'enterprise'],
    goingToBreakTimeout: 300, // timeout in seconds after which status will be set to "Break"
    statusUpdating: false,
    statuses: [],
    currentStatusId: null,
    currentStatusUpdatedAt: null,
    acceptingStatusSetAt: null,
  }),

  // methods
  actions: {
    async loadAuthAgentDataFromLiveChat() {
      console.debug('Loading auth agent information from LiveChat...');

      const self = this;

      // Get auth agent LiveChat profile
      await this.livechatApi.getAgentDetails().then(data => {
        self.agent.livechat_id = data.my_profile.id;
        self.agent.livechat_email = data.my_profile.email;
        self.agent.livechat_name = data.my_profile.name;
        self.agent.livechat_avatar = data.my_profile.avatar;
        self.agent.livechat_role = data.my_profile.permission;
        self.agent.livechat_type = data.my_profile.type;

        // Check if agents can respond back to the chat supervisor
        self.privateMessageModeAvailable = self.privateMessageModePlans.includes(data.license.plan.toLowerCase());

        console.debug('LiveChat agent information loaded:', data);
      });
    },
    async updateStatus(statusId) {
      const toast = useToast();
      const self = this;

      console.debug('Updating agent status to #' + statusId + ' - "' + this.getStatusName(statusId) + '"...');

      if (this.currentStatusId === statusId || this.statusUpdating) return false;

      this.statusUpdating = true;

      await axios.put('/api/profile/update-status', {
        'status_id': statusId
      }).then(function (response) {
        self.currentStatusId = statusId;

        let statusName = self.getStatusName(self.currentStatusId);

        toast.agentStatusUpdated(statusName);
      }).catch(function (error) {
        console.error(error);
      });

      await axios.get('/api/v2/agent/status').then(function (response) {
        self.currentStatusId = response.data.status.id;

        if (response.data.status_updated_at) {
          self.currentStatusUpdatedAt = DateTime.fromISO(response.data.status_updated_at);
        } else {
          self.currentStatusUpdatedAt = DateTime.now();
        }

        self.handleStatusUpdated();
      });

      self.statusUpdating = false;
    },
    handleStatusUpdated() {
      if (this.currentStatusId === this.acceptingStatusId) {
        // Set the timestamp of when we've transitioned to Accepting status,
        // we're not using currentStatusUpdatedAt because it could be wrong especially when we've just loaded the application
        // and for the warning to begin screen recording we need this to be the time when application loaded
        this.acceptingStatusSetAt = DateTime.now();
      } else {
        // If we are not accepting then we need to clear this data
        this.acceptingStatusSetAt = null;
      }
    },
    handleRoutingStatusChange(data) {
      // Update routing status for specific agent
      let agent = this.getAgentByLivechatId(data.payload.agent_id);

      if (agent) {
        agent.livechat_routing_status = data.payload.status;
      }

      // Currently authenticated agent opened LiveChat and changed the status there,
      // which they shouldn't do, so we'll sync the status with HelpFlow
      if (data.payload.agent_id === this.agent.livechat_id) this.syncStatus();
    },
    async syncStatus() {
      const self = this;

      if (!this.isProduction) console.debug('Syncing agent status...');

      this.statusUpdating = true;

      await axios.get('/api/v2/agent/status').then(function (response) {
        self.currentStatusId = response.data.status.id;

        if (response.data.status_updated_at) {
          self.currentStatusUpdatedAt = DateTime.fromISO(response.data.status_updated_at);
        } else {
          // In this case we've changed the status for the first time (likely a new agent)
          self.currentStatusUpdatedAt = DateTime.now();
        }

        self.handleStatusUpdated();

        self.statusUpdating = false;
      });

      if (this.currentStatusId === this.goingOnBreakStatusId) {
        // Automatically set status to "Break" if "Going on a break" timer has run out
        if (this.currentStatusUpdatedAt.plus({seconds: this.goingToBreakTimeout}).diff(DateTime.now(), ['seconds']).toObject().seconds <= 0) {
          this.updateStatus(this.breakStatusId);
        }
      }

      await this.syncLiveChatRoutingStatuses();

      if (!this.isProduction) console.debug('Agent status has been synced.');
    },
    async syncLiveChatRoutingStatuses() {
      const self = this;

      await this.livechatApi.getRoutingStatuses().then(function (response) {
        response.forEach((item) => {
          let agent = self.getAgentByLivechatId(item.agent_id);

          if (agent) {
            agent.livechat_routing_status = item.status;

            if (self.agent.livechat_id === item.agent_id) {
              if (item.status === 'accepting_chats' && self.currentStatusId !== self.acceptingStatusId) {
                if (!self.isProduction) console.debug('LiveChat routing status is out of sync with auth agent, should be "Not accepting chats", syncing...');

                self.livechatApi.setAgentStatusToNotAcceptingChats().then(function (response) {
                  if (!self.isProduction) console.debug('LiveChat routing status has been synced for auth agent.');
                });
              }

              if (item.status === 'not_accepting_chats' && self.currentStatusId === self.acceptingStatusId) {
                if (!self.isProduction) console.debug('LiveChat routing status is out of sync with auth agent, should be "Accepting chats", syncing...');

                self.livechatApi.setAgentStatusToAcceptingChats().then(function (response) {
                  if (!self.isProduction) console.debug('LiveChat routing status has been synced for auth agent.');
                });
              }
            }
          }
        });

        if (!self.isProduction) console.debug('Synced LiveChat routing statuses for all agents.');
      });
    },
    getAgent(id) {
      return this.agents.find(agent => agent.id === id) ?? null;
    },
    getAgentByLivechatId(id) {
      return this.agents.find(agent => agent.livechat_id === id) ?? null;
    },
    getStatusName(statusId) {
      let status = this.statuses.find((status) => status.id == statusId);

      return status ? status.status : null;
    },
    currentStatusUpdatedAtDiffFormatted(now) {
        let diff = DateTime.now().diff(this.currentStatusUpdatedAt);

        return formatLuxonDuration(diff);
    },
    goingToBreakInDiffFormatted(now) {
      if (this.currentStatusId === this.goingOnBreakStatusId) {
        let diff = this.currentStatusUpdatedAt.plus({seconds: this.goingToBreakTimeout}).diff(DateTime.now());

        // Automatically set status to "Break"
        if (this.currentStatusUpdatedAt.plus({seconds: this.goingToBreakTimeout}).diff(DateTime.now()).as('seconds') < 1) {
          this.updateStatus(this.breakStatusId);
        }

        return formatLuxonDuration(diff);
      }

      return null;
    }
  },

  // computed
  getters: {
    agent(state) {
      return state.agents.find(agent => agent.id === state.authAgentId) || null;
    },
    acceptingStatusId(state) {
      let status = state.statuses.find(status => status.status.toLowerCase() === 'accepting');

      return status ? status.id : null;
    },
    dnaStatusId(state) {
      let status = state.statuses.find(status => status.status.toLowerCase() === 'dna');

      return status ? status.id : null;
    },
    breakStatusId(state) {
      let status = state.statuses.find(status => status.status.toLowerCase() === 'break');

      return status ? status.id : null;
    },
    goingOnBreakStatusId(state) {
      let status = state.statuses.find(status => status.status.toLowerCase() === 'going on a break');

      return status ? status.id : null;
    },
  },
});

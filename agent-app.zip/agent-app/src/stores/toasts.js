import { defineStore } from 'pinia';
import { useToast as useToastification } from 'vue-toastification';
import { useAgentsStore } from '@/stores/agents';
import CopilotAnswerRatedToast from '@/components/toasts/CopilotAnswerRatedToast.vue';
import FaqSuggestedToast from '@/components/toasts/FaqSuggestedToast.vue';
import ScreenRecordingUploadFailedToast from '@/components/toasts/ScreenRecordingUploadFailedToast.vue';

const toast = useToastification();

export const useToast = defineStore('toasts', {
  // data
  state: () => ({
    apiDisconnectedToastId: null,
    internetDisconnectedToastId: null,
  }),

  // methods
  actions: {
    // Proxy methods to VueToastification
    success(content, options) {
      return toast.success(content, options);
    },
    info(content, options) {
      return toast.info(content, options);
    },
    warning(content, options) {
      return toast.warning(content, options);
    },
    error(content, options) {
      return toast.error(content, options);
    },

    formatLaravelValidationMessage(message) {
      // Remove "The" word in the beginning of the string
      message = message.replace(/^The /, '');

      // Remove period character at the end of the string
      if (message[message.length - 1] === '.') {
        message = message.slice(0, -1);
      }

      return message;
    },

    // Application-related
    bugReportSubmitted() {
      this.success('Bug report has been submitted');
    },
    bugReportSubmissionFailed() {
      this.error('Failed to submit bug report because BugSnag is down');
    },
    cannotDoWhileOffline(action) {
      if (action) {
        this.error('Can\'t ' + action + ' while you are offline', { timeout: 2000 });
      } else {
        this.error('This action can\'t be done while you are offline', { timeout: 2000 });
      }
    },
    internetDisconnected() {
      this.internetDisconnectedToastId = this.error('You\'re offline, trying to connect...', { timeout: false, closeButton: false });
    },
    internetReconnected() {
      this.success('Your internet connection was restored', { timeout: 6000, closeButton: false });

      toast.dismiss(this.internetDisconnectedToastId);

      this.internetDisconnectedToastId = null;
    },
    apiDisconnected() {
      this.apiDisconnectedToastId = this.error('LiveChat API is offline, trying to connect...', { timeout: false, closeButton: false });
    },
    apiReconnected() {
      this.success('LiveChat API connection was restored', { timeout: 6000, closeButton: false });

      toast.dismiss(this.apiDisconnectedToastId);

      this.apiDisconnectedToastId = null;
    },

    // Chat-related
    chatStopped(threadId) {
      this.success('Chat #' + threadId + ' has been stopped and archived');
    },
    chatClosed(threadId) {
      this.success('Chat #' + threadId + ' has been closed');
    },
    chatClosedAndArchived(threadId) {
      this.success('Chat #' + threadId + ' has been closed and archived');
    },
    chatSupervisionStopped(threadId) {
      this.success('Chat #' + threadId + ' supervision ended');
    },
    chatTransferred(threadId, agentLivechatId) {
      const agents = useAgentsStore();

      let agent = agents.getAgentByLivechatId(agentLivechatId);
      let agentName = agent ? agent.display_name : agentLivechatId;

      this.success('Chat #' + threadId + ' has been transferred to ' + agentName);
    },
    failedToLoadChat(threadId) {
      this.error('Failed to load chat #' + threadId + ', will retry in a few seconds...');
    },
    failedToCloseChat(threadId) {
      this.error('Failed to close chat #' + threadId);
    },
    failedToTransferChat(threadId) {
      this.error('Failed to transfer chat #' + threadId);
    },
    chatMarkedAsImportant() {
      this.success('Chat has been marked as important');
    },
    chatMarkedAsNotImportant() {
      this.success('Chat has been marked as not important');
    },
    chatFlaggedForHelp() {
      this.success('Chat has been flagged for help');
    },
    failedToLoadVisitor(threadId) {
      this.error('Failed to load visitor information for chat # ' + threadId);
    },
    failedToSendMessage(reason) {
      if (reason === 'Requester is not user of the chat') {
        this.error('Failed to send a message: chat was transferred to somebody else');
      } else if (reason) {
        this.error('Failed to send a message: ' + reason);
      } else {
        this.error('Failed to send a message');
      }
    },
    failedToAddTag(title) {
      this.error('Failed to add a "' + title + '" tag');
    },
    failedToRemoveTag(title) {
      this.error('Failed to remove a "' + title + '" tag');
    },
    chatNotFound(chatId) {
      this.error('Chat #' + chatId + ' not found');
    },
    visitorBanned() {
      this.success('Visitor has been banned');
    },
    visitorUnbanned() {
      this.success('Visitor has been unbanned');
    },
    failedToBanVisitor(reason) {
      let text = 'Failed to ban visitor';

      if (reason) text += ': ' + reason;

      this.error(text);
    },
    chatTranscriptSent() {
      this.success('Chat transcript sent to email');
    },
    failedToSendChatTranscript() {
      this.error('Failed to send chat transcript');
    },
    googleAnalyticsEventLogged(label) {
      this.success('GA "' + label + '" event has been logged');
    },
    googleAnalyticsEventLogFailed(label) {
      this.error('Failed to log GA "' + label + '" event');
    },

    // FAQ-related
    faqSuggested(faqId, url) {
      this.success({
          component: FaqSuggestedToast,
          props: { url: url },
      });
    },

    // Agent-related
    agentStatusUpdated(statusName) {
      this.success('Status has been updated to "' + statusName + '"');
    },
    failedToLoadPerformanceReport() {
      this.error('Failed to load performance report');
    },

    // Canned responses
    cannedResponseSaved(shortcut) {
      this.success('Canned response has been saved');
    },
    failedToSaveCannedResponse() {
      this.error('Failed to save canned response');
    },

    // Copilot
    failedToGenerateCopilotAnswer() {
      this.error('Copilot failed to generate an answer');
    },
    copilotAnswerRatedAsGood(requestId) {
      const self = this;

      let rating = 1;

      let onCommentClick = function() {
        self.emitter.emit('show-update-copilot-answer-rating-modal', {
          requestId: requestId,
          rating: rating,
        });
      };

      this.success({
          component: CopilotAnswerRatedToast,
          props: { rating: rating, requestId: requestId },
          listeners: { comment: onCommentClick }
      }, { timeout: 10000 });
    },
    copilotAnswerRatedAsBad(requestId) {
      const self = this;

      let rating = 0;

      let onCommentClick = function() {
        self.emitter.emit('show-update-copilot-answer-rating-modal', {
          requestId: requestId,
          rating: rating,
        });
      };

      this.success({
          component: CopilotAnswerRatedToast,
          props: { rating: 0, requestId: requestId },
          listeners: { comment: onCommentClick }
      }, { timeout: 10000 });
    },
    copilotAnswerRatingRemoved(requestId) {
      this.success('Copilot answer rating has been removed');
    },
    copilotAnswerCommentAdded(requestId) {
      this.success('Your comment has been saved');
    },

    // RTO
    RTOEmailSent() {
      this.success('RTO email has been sent');
    },
    failedToSendRTOEmail(message) {
      if (message) {
        this.error('Failed to send RTO email: ' + message);
      } else {
        this.error('Failed to send RTO email');
      }
    },

    // Screen recording
    screenRecordingUploadFailed(recordingId, validationMessage) {
      // If agent is offline they cannot upload screen recording, no need to notify them
      if (this.internetDisconnectedToastId) return false;

      // If it's not a validation error then it's likely a network error so we won't show the notification
      if (!validationMessage) return false;

      validationMessage = this.formatLaravelValidationMessage(validationMessage);

      this.error({
          component: ScreenRecordingUploadFailedToast,
          props: {
            recordingId: recordingId,
            validationMessage: validationMessage,
          },
      });
    },

    // File uploads
    filesUploaded(uploadedFilesCount) {
      if (uploadedFilesCount === 1) {
        this.success('File has been uploaded successfully');
      } else {
        this.success(uploadedFilesCount + ' files have been uploaded successfully');
      }
    },
    fileUploadFailed(file, reason) {
      this.error('Failed to upload file: ' + file.name + ', reason: ' + reason, { timeout: 30000 });
    },
    selectedFileTooLarge(count) {
      if (count === 1) {
        this.error('Selected file is too large');
      } else {
        this.error('Selected files are too large');
      }
    },
    pastedFilesToInput(count) {
      if (count === 1) {
        this.success('Pasted 1 file');
      } else {
        this.success('Pasted ' + count + ' files');
      }
    },

    // Clipboard handling
    copiedToClipBoard(filename) {
      this.success('Copied to clipboard');
    },
    copyToClipBoardFailed(filename) {
      this.error('Failed to copy to clipboard');
    },
  },

  // computed
  getters: {
    //
  },
});

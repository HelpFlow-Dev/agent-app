import { defineStore } from 'pinia';

// To add support for new audio files put them in the assets folder and add the filenames here
const audioFiles = [
  'bell-notification.wav',
  'inteface-pop.wav',
  'interface-start.wav',
  'new-chat.wav',
  'new-message.wav',
  'start-screen-recording.wav',
];

export const useAudioStore = defineStore('audio', {
  // data
  state: () => ({
    audioList: {},
    initialized: false,
  }),

  actions: {
    async init() {
      audioFiles.forEach(file => {
        let name = file.split('.').slice(0, -1).join('.');

        this.audioList[name] = new Audio(`${window.location.origin}/agent-app/assets/audio/${file}`);
      });

      this.initialized = true;
    },
    play(name) {
      if (!this.initialized) return false;

      let audio = this.audioList[name];

      if (audio) {
        if (this.environment === 'local') console.debug('Playing audio: ' + name);

        // We'll stop and reset the audio track because this will allow
        // to play the same audio file many times as fast as possbile
        // for example when we're receiving many new messages
        audio.pause();
        audio.currentTime = 0;

        // Play the sound
        audio.play().catch(function (error) {
          // It's likely one of these two:
          // play() request was interrupted by a call to pause()
          // play() failed because the user didn't interact with the document first
          console.warn(error);
        });
      }
    },
  },

  // computed
  getters: {
    //
  },
});

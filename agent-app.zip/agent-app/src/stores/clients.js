import { defineStore } from 'pinia';
import { DateTime } from 'luxon';
import { useToast } from '@/stores/toasts';
import { useAgentsStore } from '@/stores/agents';
import { useChatsStore } from '@/stores/chats';
import axios from 'axios';

export const useClientsStore = defineStore('clients', {
  // data
  state: () => ({
    clients: [],
    expandedPromotionIds: [],
  }),

  // methods
  actions: {
    async load() {
      const self = this;

      if (!this.isProduction) console.debug('Loading clients...');

      await axios.get('/api/v2/clients').then(function (response) {
        self.mapAndSetClients(response.data);

        if (!self.isProduction) console.debug('Clients loaded:', self.clients);
      });
    },
    makeGeneralGroupClient() {
      // Special case for "General" LC group, we need to simulate a client model
      return {
        id: 0,
        code: 'General',
        company_name: 'none',
        website_url: null,
        summary: 'General chats do not come from a specific client\'s website.',
        announcements: 'There are no announcements at the moment.',
        strategy: null,
        livechat_id: 0,
        is_active: 1,
        top_faqs: [],
        links: [],
        promotions: [],
        rto_emails: [],
        updated_at: DateTime.now(),
        ga_event_tracking_enabled: 0,
        display_website_url: null,
      };
    },
    mapClient(client) {
      const self = this;

      try {
        client.display_website_url = new URL(client.website_url).hostname;
      } catch (e) {
        console.error(e, client);

        client.display_website_url = null;
      }

      client.updated_at = DateTime.fromISO(client.updated_at);

      client.promotions.map(function (promotion) {
        // Promotion dates use the local timezone of authenticated agent
        promotion.starts_at = DateTime.fromISO(promotion.starts_at, { zone: 'UTC' }).setZone('system', { keepLocalTime: true });
        promotion.ends_at = DateTime.fromISO(promotion.ends_at, { zone: 'UTC' }).setZone('system', { keepLocalTime: true });
        promotion.is_expanded = self.expandedPromotionIds.indexOf(promotion.id) > -1;
      });

      return client;
    },
    mapAndSetClients(clients) {
      const self = this;

      clients.map(function (client) {
        return self.mapClient(client);
      });

      this.clients = [this.makeGeneralGroupClient(), ...clients];
    },
    getClient(id) {
      return this.clients.find(client => client.id === id) || null;
    },
    getClientByLiveChatId(id) {
      return this.clients.find(client => client.livechat_id === id) || null;
    },
    getClientByCode(code) {
      return this.clients.find(client => client.code === code) || null;
    },
    getActivePromotionsByClientCode(code, now) {
      let client = this.getClientByCode(code);

      if (!client) return [];

      let promotions = client.promotions.filter(function(promotion) {
        let now = DateTime.now();
        return promotion.starts_at <= now && promotion.ends_at >= now;
      });

      return promotions;
    },
    expandPromotion(promotion) {
      promotion.is_expanded = true;

      if (this.expandedPromotionIds.indexOf(promotion.id) === -1) {
        this.expandedPromotionIds.push(promotion.id);
      }
    },
    collapsePromotion(promotion) {
      promotion.is_expanded = false;
      this.expandedPromotionIds = this.expandedPromotionIds.filter(id => id !== promotion.id);
    },
    promotionEndsAtDiffFormatted(promotion, now) {
      return promotion.ends_at.toRelative();
    },
    async suggestFaq(clientCode, threadId, title, event) {
      const agents = useAgentsStore();
      const toast = useToast();

      let generalGuidanceText = `FAQ suggested by ${agents.agent.display_name} ${agents.agent.livechat_id} for https://my.livechatinc.com/archives/${threadId} related to the following message in the chat.`;
      generalGuidanceText += 'Quality team should process this.';
      generalGuidanceText += '\n\n';
      generalGuidanceText += '--- message below ---';
      generalGuidanceText += '\n\n';
      generalGuidanceText += event.text;

      let data = {
        chat_id: threadId,
        client_code: clientCode,
        general_guidance: generalGuidanceText,
        referrer: 'livechat',
        title: title,
      };

      await axios.post('/api/faq', data).then(function (response) {
        let faqId = response.data.id;
        let url = response.data.link;

        toast.faqSuggested(faqId, url);

        console.debug('FAQ has been suggested:', data, response.data);
      });
    }
  },
  // computed
  getters: {
    activeClient(state) {
      const chats = useChatsStore();

      if (chats.activeChat) {
        return this.getClientByCode(chats.activeChat.client_code);
      }

      return null;
    },
    activeClientId(state) {
      return this.activeClient ? this.activeClient.id : null;
    },
    activeClientCode(state) {
      return this.activeClient ? this.activeClient.code : null;
    }
  },
});

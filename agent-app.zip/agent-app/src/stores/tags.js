import { defineStore } from 'pinia';
import axios from 'axios';
import Bugsnag from '@bugsnag/js';
import { useChatsStore } from '@/stores/chats';
import { useToast } from '@/stores/toasts';

export const useTagsStore = defineStore('tags', {
  // data
  state: () => ({
    tags: [],
    prospectTagId: null, // If a chat has this tag ID, this means that the visitor is a prospect
    chatSalesTypeTag: 'type_SALES', // This tag will be assigned by agent manually to determine chat type
    chatSupportTypeTag: 'type_SUPPORT', // This tag will be assigned by agent manually to determine chat type
    rtoSalesTag: 'sales_referred_lead', // This tag will be assigned after submitting RTO for SALES team
    rtoSupportTag: 'support_referred', // This tag will be assigned after submitting RTO for SUPPORT team
  }),

  // methods
  actions: {
    async load() {
      if (!this.isProduction) console.debug('Loading tags...');

      const self = this;

      await axios.get('/api/v2/tags').then(function (response) {
        self.tags = response.data;

        if (!self.isProduction) console.debug('Tags loaded:', response.data);
      });
    },
    getTag(id) {
      return this.tags.find(tag => tag.id == id) ?? null;
    },
    getTagByTitle(title) {
      return this.tags.find(tag => tag.title === title) ?? null;
    },
    getTagsByIds(tagIds) {
      let tags = [];

      tagIds.forEach((id, i) => {
        let tag = this.getTag(id);

        if (tag) tags.push(tag);
      });

      return tags;
    },
    convertTagTitlesToIds(titles) {
      let tagIds = [];

      for (var i = 0; i < titles.length; i++) {
        let tag = this.getTagByTitle(titles[i]);

        if (tag) tagIds.push(tag.id);
      }

      return tagIds;
    },
    includesLevelOneTag(tagIds) {
      let result = false;

      tagIds.forEach((tagId) => {
        let tag = this.getTag(tagId);

        if (tag && tag.level === 1) {
          result = true;
        }
      });

      return result;
    },
    getTagIdsForChatThread(chat, threadId) {
      this.objectPath.ensureExists(chat, 'threads.' + threadId + '.tags', []);

      return chat.threads[threadId].tags;
    },
    getTagsForChatThread(chat, threadId) {
      return this.getTagsByIds(this.getTagIdsForChatThread(chat, threadId));
    },
    getAvailableTagsForChatThread(chat, threadId, query) {
      const self = this;

      query = query ? query.toLowerCase().trim() : null;

      // At least one level 1 tag is required to show level 2 tags
      let canUseLevelTwoTags = this.includesLevelOneTag(this.getTagIdsForChatThread(chat, threadId));

      let tagsAvailable = this.tags;

      tagsAvailable = tagsAvailable.filter(function(tag) {
        return !self.getTagIdsForChatThread(chat, threadId).includes(tag.id);
      });

      if (!canUseLevelTwoTags) {
        tagsAvailable = tagsAvailable.filter(function(tag) {
          return tag.level !== 2;
        });
      }

      if (query) {
        tagsAvailable = tagsAvailable.filter(function(tag) {
          return tag.title.toLowerCase().includes(query);
        });
      }

      return this.sortTags(tagsAvailable);
    },
    sortTags(tags) {
      tags.sort(function(a, b) {
        // Tags sorted alphabetically asc
        return a.title.localeCompare(b.title);
      });

      return tags;
    },
    handleThreadTagged(data) {
      const chats = useChatsStore();

      let chat = chats.getChat(data.payload.chat_id);
      let threadId = data.payload.thread_id;

      if (!chat) return false;

      let tag = this.getTagByTitle(data.payload.tag);

      // Skip if tag is already added
      if (this.getTagIdsForChatThread(chat, threadId).includes(tag.id)) return;

      this.objectPath.push(chat, 'threads.' + threadId + '.tags', tag.id);
    },
    handleThreadUntagged(data) {
      const chats = useChatsStore();

      let chat = chats.getChat(data.payload.chat_id);
      let threadId = data.payload.thread_id;

      if (!chat) return false;

      let tag = this.getTagByTitle(data.payload.tag);

      // Skip if tag is already removed
      if (!this.getTagIdsForChatThread(chat, threadId).includes(tag.id)) return;

      this.objectPath.set(chat, 'threads.' + threadId + '.tags', this.getTagIdsForChatThread(chat, threadId).filter(function(id) {
        return id != tag.id;
      }));
    },
    async addTagToChatThread(chat, threadId, tagId) {
      const toast = useToast();
      const self = this;

      let tag = this.getTag(tagId);

      if (!tag) return false;

      // Skip if tag is already added
      if (this.getTagIdsForChatThread(chat, threadId).includes(tagId)) return false;

      // We'll display UI changes before we even send the request
      this.objectPath.push(chat, 'threads.' + threadId + '.tags', tagId);

      await axios.post('/api/threads/' + threadId + '/tags', { tag: tag.title, chat_id: chat.id }).catch(function (error) {
        console.error(error);

        toast.failedToAddTag(tag.title);

        // Sync tags to revert changes
        self.syncTagsForChatThread(chat.id, threadId);
      });
    },
    async removeTagFromChatThread(chat, threadId, tagId) {
      const toast = useToast();
      const self = this;

      let tag = this.getTag(tagId);

      if (!tag) return false;

      // Skip if tag is already removed
      if (!this.getTagIdsForChatThread(chat, threadId).includes(tagId)) return false;

      // We'll display UI changes before we even send the request
      this.objectPath.set(chat, 'threads.' + threadId + '.tags', this.getTagIdsForChatThread(chat, threadId).filter(function(id) {
        return id != tagId;
      }));

      await axios.delete('/api/threads/' + threadId + '/tags', {
        data: {
          tag: tag.title,
          chat_id: chat.id,
        }
      }).catch(function (error) {
        console.error(error);

        toast.failedToRemoveTag(tag.title);

        // Sync tags to revert changes
        self.syncTagsForChatThread(chat.id, threadId);
      });
    },
    async syncTagsForChatThread(chatId, threadId) {
      const chats = useChatsStore();
      const self = this;

      let chat = chats.getChat(chatId);

      if (!chat) return false;

      await axios.get('/api/threads/' + threadId + '/tags').then(function (response) {
        let tagIds = self.convertTagTitlesToIds(response.data);

        self.objectPath.set(chat, 'threads.' + threadId + '.tags', tagIds);

        console.debug('Synced tags for chat #' + chat.id + ' thread #' + threadId);
      }).catch(function (error) {
        // Probably we have no tags associated with the chat thread, not an actual error
        console.error(error);
      });
    },
    async handleRTOSubmitted(chat, rtoFor) {
      let threadId = chat.current_thread_id;
      let rtoSalesTag = this.getTagByTitle(this.rtoSalesTag);
      let rtoSupportTag = this.getTagByTitle(this.rtoSupportTag);
      let chatSalesTypeTag = this.getTagByTitle(this.chatSalesTypeTag);
      let chatSupportTypeTag = this.getTagByTitle(this.chatSupportTypeTag);

      let chatTagList = this.getTagIdsForChatThread(chat, threadId);

      // It's important to notify the developers that one or more required tags are missing from the backend
      if (!rtoSalesTag || !rtoSupportTag || !chatSalesTypeTag || !chatSupportTypeTag) {
        if (!rtoSalesTag) Bugsnag.notify(new Error('WARNING! Tag is missing: ' + this.rtoSalesTag));
        if (!rtoSupportTag) Bugsnag.notify(new Error('WARNING! Tag is missing: ' + this.rtoSupportTag));
        if (!chatSalesTypeTag) Bugsnag.notify(new Error('WARNING! Tag is missing: ' + this.chatSalesTypeTag));
        if (!chatSupportTypeTag) Bugsnag.notify(new Error('WARNING! Tag is missing: ' + this.chatSupportTypeTag));

        // All tags above are required in order for this method to work correctly
        return false;
      }

      // Remove related tags if they exists because now we need to reclassify this chat
      if (chatTagList.includes(rtoSalesTag.id)) await this.removeTagFromChatThread(chat, threadId, rtoSalesTag.id);
      if (chatTagList.includes(rtoSupportTag.id)) await this.removeTagFromChatThread(chat, threadId, rtoSupportTag.id);
      if (chatTagList.includes(chatSalesTypeTag.id)) await this.removeTagFromChatThread(chat, threadId, chatSalesTypeTag.id);
      if (chatTagList.includes(chatSupportTypeTag.id)) await this.removeTagFromChatThread(chat, threadId, chatSupportTypeTag.id);

      let rtoTag = rtoFor === 'SALES' ? rtoSalesTag : rtoSupportTag;

      this.addTagToChatThread(chat, chat.current_thread_id, rtoTag.id);
    },
  },

  // computed
  getters: {
    //
  },
});

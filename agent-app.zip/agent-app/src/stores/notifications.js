import { defineStore } from 'pinia';
import { useRouter } from 'vue-router';
import { useAppStore } from '@/stores/app';
import { useAudioStore } from '@/stores/audio';

export const useNotificationsStore = defineStore('notifications', {
  // data
  state: () => ({
    router: useRouter(),

    // "default" = the user decision is unknown
    // "denied" = the user has explicitly denied to display browser notifications
    // "granted" = the user has explicitly granted to display browser notifications
    browserNotificationsPermission: 'default',
  }),

  actions: {
    init() {
      // TODO-HAS: show a modal or toast in UI asking to enable notifications where agent needs to click to trigger method below
      this.requestBrowserNotificationsPermission();
    },
    requestBrowserNotificationsPermission() {
      return Notification.requestPermission().then((permission) => {
        this.browserNotificationsPermission = permission;
      });
    },
    notify({ title, body, sound, data }) {
      const app = useAppStore();
      const audio = useAudioStore();
      const self = this;

      // Prevent sending notifications for chats that are being loaded with the app
      if (!app.initialized) return false;

      // Notification options
      let options = {
        body: body,
        data: data,
      };

      if (this.browserNotificationsAreEnabled) {
        const notification = new Notification(title, options);

        notification.onclick = function(event) {
          // Make browser focus on the notification's tab
          window.focus();

          // Check if we have a router route path we need to open
          if (event.target.data && event.target.data.router_path) {
            // Redirect to specified route path
            self.router.push(event.target.data.router_path);
          }

          // Close the browser notification
          this.close();
        }
      }

      // Play a sound notification
      if (sound) audio.play(sound);
    }
  },

  // computed
  getters: {
    browserNotificationsAreSupported(state) {
      return 'Notification' in window;
    },
    browserNotificationsAreEnabled(state) {
      return state.browserNotificationsPermission === 'granted';
    }
  },
});

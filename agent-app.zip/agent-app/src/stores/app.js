import { defineStore } from 'pinia';
import { useRouter } from 'vue-router';
import { useChatsStore } from '@/stores/chats';
import { useToast } from '@/stores/toasts';

export const useAppStore = defineStore('app', {
  // data
  state: () => ({
    router: useRouter(),

    // App initialization state
    initialized: false,

    // Shows if agent has LiveChat token set and we should enable online chat functionality
    livechatEnabled: false,

    // Current network status
    online: true,

    // Current network status for LiveChat API
    livechatOnline: true,

    // Global app error object
    error: null,

    // Visitor ban duration options in days
    visitorBanDurations: [
      {
        label: 'Shortest',
        duration: 1, // in days
      },
      {
        label: 'Temporary',
        duration: 3, // in days
      },
      {
        label: 'Extended',
        duration: 30, // in days (~1 month)
      },
      {
        label: 'Permanent',
        duration: 999, // in days (~2.74 years)
      },
    ],

    // State of components, useful when we need to handle keyboard shortcuts for example
    modalOpen: false,
    tagPickerOpen: false,
    emojiPickerOpen: false,
    dropdownMenuOpen: false,
    chatInputFocused: false,
  }),

  // methods
  actions: {
    checkLivechatApiConnection() {
      const chats = useChatsStore();
      const toast = useToast();

      if (this.livechatApi.isConnected()) {
        if (toast.apiDisconnectedToastId !== null) {
          this.livechatOnline = true;

          toast.apiReconnected();

          chats.syncMissingChatsAndMessages();
        }
      } else {
        if (toast.apiDisconnectedToastId === null) {
          this.livechatOnline = false;

          toast.apiDisconnected();
        }
      }
    },
    reload() {
      // Go back to home page first
      this.router.push({ name: 'home' });

      // We need to wait for the Vue router to finish loading the route first before we do a page reload
      setTimeout(() => {
        window.location.reload();
      }, 0);
    },
    // After this, the app will stop working (except screen recording)
    // Available types: "initialization", "sleep", "connection"
    throwCriticalError(type, message) {
      this.error = {
        type: type,
        message: message,
      };
    },
    updateTabName(unreadMessagesCount) {
      let name = 'Chats';

      if (unreadMessagesCount) {
        name = `(${unreadMessagesCount}) ` + name;
      }

      document.title = name;
    },
  },

  // computed
  getters: {
    //
  },
});

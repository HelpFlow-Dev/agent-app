import { defineStore } from 'pinia';
import axios from 'axios';
import { DateTime } from 'luxon';
import { useChatsStore } from '@/stores/chats';
import { useClientsStore } from '@/stores/clients';
import { useToast } from '@/stores/toasts';

export const useCopilot = defineStore('copilot', {
  // data
  state: () => ({
    threads: {}, // Here we store all related copilot data for each chat thread
    positionTop: 75, // Copilot box top position property
    positionRight: 12, // Copilot box right position property
    positionTransform: null, // Copilot box transform position property, will be filled after dragging Copilot box
  }),

  // methods
  actions: {
    open(event, generateFreshAnswerFromEvent) {
      let threadId = event.thread_id;

      // We want to get the event that we've opened Copilot for previously (if exists)
      let previousEvent = this.objectPath.get(this.threads, event.thread_id + '.event', null);

      // We need to build inital data structure in case we open Copilot for the thread for the first time
      this.buildDefaultThreadDataStructureForThread(threadId);

      // Set the event that we've opened Copilot for
      this.objectPath.set(this.threads, threadId + '.event', event);

      // Only create fresh request if we open for different event (in case agent accidentally closes Copilot)
      if (!previousEvent || previousEvent.id !== event.id) {
        let index = this.createOrUpdateFreshRequestForThread(threadId, event.text);

        this.goToRequestIndex(index);
      } else {
        this.goToLastRequest(threadId);
      }

      if (generateFreshAnswerFromEvent) this.generateFreshRequest();

      // Now we can show the Copilot UI
      this.currentThread.show = true;

      setTimeout(() => {
        if (generateFreshAnswerFromEvent) this.generateAnswer();
      }, 0);
    },
    close(reset) {
      const chats = useChatsStore();

      if (this.currentThread) {
        this.currentThread.show = false;

        // Reset event so that we'd show fresh request next time agent opens Copilot for this thread
        if (reset) this.generateFreshRequest();
      }
    },
    async generateAnswer() {
      const chats = useChatsStore();
      const clients = useClientsStore();
      const toast = useToast();
      const self = this;

      if (!clients.activeClientId || !this.visibleThread || !this.visibleRequest) return;

      let threadId = this.visibleThread.id;
      let clientId = clients.activeClientId;
      let request = this.visibleRequest;

      this.setLoadingStatusForThread(threadId, true);

      chats.sendTypingIndicator(chats.activeChatId);

      await axios.post('/api/v2/copilot', {
        thread_id: threadId,
        client_id: clientId,
        question: request.question,
      }).then(function (response) {
        console.debug('Copilot generated answer:', response.data);

        request.id = response.data.id;
        request.answer = response.data.answer;
        request.response_time = response.data.response_time;
        request.reply_source_text = response.data.reply_source_text;
      }).catch(function (error) {
        console.error(error);

        toast.failedToGenerateCopilotAnswer();
      });

      this.setLoadingStatusForThread(threadId, false);
    },
    async regenerateAnswer() {
      if (!this.visibleRequest) return;

      this.generateFreshRequest(this.visibleRequest.question);

      return this.generateAnswer();
    },
    async sendAnswer() {
      const chats = useChatsStore();
      const self = this;

      if (!chats.activeChat || !this.visibleRequest || !this.visibleRequest.answer) return;

      let threadId = this.currentThread.id;
      let requestId = this.visibleRequest.id;
      let requestIndex = this.visibleRequestIndex;
      let answer = this.visibleRequest.answer;

      chats.sendMessage(chats.activeChat, {
        chat_id: chats.activeChat.id,
        message: answer,
        is_private: false,
      });

      // Track answer usage via HF API
      axios.put('/api/v2/copilot/' + requestId, {
        reply_text: answer,
        replied_at: DateTime.now().setZone('UTC').toFormat('yyyy-MM-dd HH:mm:ss'),
      }).then(function (response) {
        console.debug('Copilot answer used:', response.data);

        // Update the Copilot item data
        self.threads[threadId].requestsHistory[requestIndex] = response.data;
      }).catch(function (error) {
        console.error(error);
      });

      this.close(true);
    },
    async setRating(rating, comment) {
      if (!this.visibleRequest) return;

      // If rating is the same, we'll remove it
      if (this.visibleRequest.rating === rating) rating = null;

      this.visibleRequest.rating = rating;
      this.visibleRequest.rating_comment = comment || null;

      await this.updateRating(this.visibleRequest.id, this.visibleRequest.rating, this.visibleRequest.rating_comment);
    },
    async updateRating(requestId, rating, comment) {
      const toast = useToast();
      const self = this;

      if (!requestId) return false;

      // Track answer usage via HF API
      axios.put('/api/v2/copilot/' + requestId + '/rating', {
        rating: rating,
        rating_comment: comment,
      }).then(function (response) {
        console.debug('Copilot rating updated:', response.data);

        // Don't show toast if rating comment is present,
        // because this means we're just updating the comment and the rating is already set
        if (comment) {
          toast.copilotAnswerCommentAdded(requestId);
        } else {
          if (rating === 1) {
            toast.copilotAnswerRatedAsGood(requestId);
          } else if (rating === 0) {
            toast.copilotAnswerRatedAsBad(requestId);
          } else {
            toast.copilotAnswerRatingRemoved(requestId);
          }
        }
      }).catch(function (error) {
        console.error(error);
      });
    },
    buildDefaultThreadDataStructureForThread(threadId) {
      this.objectPath.ensureExists(this.threads, threadId + '.id', threadId);
      this.objectPath.ensureExists(this.threads, threadId + '.show', false);
      this.objectPath.ensureExists(this.threads, threadId + '.isLoading', false);
      this.objectPath.ensureExists(this.threads, threadId + '.requestsHistory', []);
      this.objectPath.ensureExists(this.threads, threadId + '.visibleRequestIndex', null);
    },
    createOrUpdateFreshRequestForThread(threadId, question) {
      let request = {
        id: null,
        question: question,
        answer: null,
      };

      let index = this.findRequestIndex(threadId, null);

      // Create or update fresh (unsent) Copilot request
      if (index === -1) {
        this.objectPath.push(this.threads, threadId + '.requestsHistory', request);
      } else {
        this.objectPath.set(this.threads, threadId + '.requestsHistory.' + index + '.question', request.question);
        this.objectPath.set(this.threads, threadId + '.requestsHistory.' + index + '.answer', request.answer);
      }

      return this.findRequestIndex(threadId, request.id);
    },
    generateFreshRequest(question) {
      if (!this.currentThread) return;

      let event = this.currentThread.event;

      if (!question) question = event.text;

      let index = this.createOrUpdateFreshRequestForThread(this.currentThread.id, question);

      this.goToRequestIndex(index);
    },
    findRequestIndex(threadId, requestId) {
      let requests = this.getRequestsHistoryForThread(threadId);

      return requests.findIndex((request) => request.id === requestId);
    },
    goToRequestIndex(index) {
      if (!this.currentThread) return;

      if (typeof this.currentThread.requestsHistory[index] === 'undefined') return;

      this.currentThread.visibleRequestIndex = index;
    },
    goToLastRequest(threadId) {
      if (!this.threads[threadId]) return;

      let index = this.threads[threadId].requestsHistory.length - 1;

      return this.goToRequestIndex(index);
    },
    getLastRequestIndex(threadId) {
      if (this.threads[threadId]) {
        return this.threads[threadId].requestsHistory.length - 1;
      }

      return null;
    },
    getRequestsHistoryForThread(threadId) {
      return this.objectPath.get(this.threads, threadId + '.requestsHistory', []);
    },
    setRequestsHistoryForThread(threadId, data) {
      this.buildDefaultThreadDataStructureForThread(threadId);

      let lastRequestCopy = {};
      let lastAnswerCopy = null;

      // If the latest request is a fresh one we need to preserve it
      if (this.threads[threadId].requestsHistory.length && this.threads[threadId].requestsHistory[this.threads[threadId].requestsHistory.length - 1].id === null) {
        lastRequestCopy = this.threads[threadId].requestsHistory[this.threads[threadId].requestsHistory.length - 1];
      }

      // Agent could be editing the last answer right now, so we need to preserve it
      if (this.visibleRequestIsTheLastOne && this.visibleThread.id === threadId && this.visibleRequest.id !== null) {
        lastAnswerCopy = this.visibleRequest.answer;
      }

      // Overwrite all data with data from DB
      this.threads[threadId].requestsHistory = data;

      // If agent was editing the last answer, we need to restore it
      if (lastAnswerCopy !== null && this.visibleRequestIsTheLastOne && this.visibleThread.id === threadId && this.visibleRequest.id !== null) {
        this.visibleRequest.answer = lastAnswerCopy;
      }

      // We need to be careful not to remove current fresh request
      if (Object.keys(lastRequestCopy).length > 0) {
        this.threads[threadId].requestsHistory.push(lastRequestCopy);
      }
    },
    setLoadingStatusForThread(threadId, isLoading) {
      if (!this.threads[threadId]) return;

      return this.threads[threadId].isLoading = isLoading;
    },
    isOpenForThread(threadId) {
      if (this.threads[threadId] && this.threads[threadId].show === true) {
        return true;
      }

      return false;
    },
    isCurrentEvent(event) {
      if (!this.currentThread || !this.currentThread.event) return false;

      return event.id === this.currentThread.event.id;
    },
    isOpenForEvent(event) {
      return this.isOpenForThread(event.thread_id) && this.isCurrentEvent(event);
    },
  },

  // computed
  getters: {
    show(state) {
      const chats = useChatsStore();

      if (!chats.activeChat || chats.activeChat.is_deactivated) return false;

      if (!this.currentThread) return false;

      return this.currentThread.show === true;
    },
    currentThread(state) {
      const chats = useChatsStore();

      if (!chats.activeChatCurrentThreadId) return null;

      return this.threads[chats.activeChatCurrentThreadId];
    },
    visibleThread(state) {
      const chats = useChatsStore();

      if (!this.show) return null;

      return this.threads[chats.activeChatCurrentThreadId];
    },
    visibleRequest(state) {
      if (!this.show) return null;

      if (!this.visibleThread) return null;

      return this.visibleThread.requestsHistory[this.visibleThread.visibleRequestIndex];
    },
    visibleRequestRatedGood(state) {
      if (!this.visibleRequest) return null;

      return this.visibleRequest.rating === 1;
    },
    visibleRequestRatedBad(state) {
      if (!this.visibleRequest) return null;

      return this.visibleRequest.rating === 0;
    },
    visibleRequestUnrated(state) {
      if (!this.visibleRequest) return null;

      return this.visibleRequest.rating !== 0 && this.visibleRequest.rating !== 1;
    },
    visibleRequestIndex(state) {
      if (!this.show) return null;

      if (!this.visibleThread) return null;

      return this.visibleThread.visibleRequestIndex;
    },
    isLoading(state) {
      if (!this.currentThread) return false;

      return this.currentThread.isLoading;
    },
    visibleRequestIsTheLastOne(state) {
      if (!this.show) return null;

      if (!this.visibleThread) return null;

      let lastIndex = this.visibleThread.requestsHistory.length - 1;

      return lastIndex === this.visibleRequestIndex;
    },
    canViewPreviousRequest(state) {
      return this.visibleRequestIndex && this.visibleRequestIndex > 0 && !this.isLoading;
    },
    canViewNextRequest(state) {
      return !this.visibleRequestIsTheLastOne && !this.isLoading;
    },
  },
});

import { defineStore } from 'pinia';
import { useRoute, useRouter } from 'vue-router';
import { DateTime } from 'luxon';
import axios from 'axios';
import Autolinker from 'autolinker';
import Bugsnag from '@bugsnag/js';
import UAParser from 'ua-parser-js';
import { useAgentsStore } from '@/stores/agents';
import { useAppStore } from '@/stores/app';
import { useAudioStore } from '@/stores/audio';
import { useClientsStore } from '@/stores/clients';
import { useCopilot } from '@/stores/copilot';
import { useNotificationsStore } from '@/stores/notifications';
import { useTagsStore } from '@/stores/tags';
import { useToast } from '@/stores/toasts';
import { formatLuxonChatTimerDuration, convertCommaSeparatedStringToArray } from '@/helpers';

export const useChatsStore = defineStore('chats', {
  // data
  state: () => ({
    route: useRoute(),
    router: useRouter(),
    chats: [],
    // These system events signal that chat has been archived and thus we should update chat status to inactive
    chatArchivedEventKeys: [
      'archived_customer_disconnected', // Chat ended after Customer left the website
      'manual_archived_agent', // Agent closed chat via the Deactivate Chat request
      'manual_archived_customer', // Visitor closed chat via the Deactivate Chat request
      'routing.archived_inactive', // No new messages were posted for an extended amount of time
      'routing.archived_offline', // No Agent could be selected after chat was placed in the queue
      'system_archived', // License was moved to another lc_serv instance while there were still active chats
    ],
    // These system events signal that chat has been unassigned from all agents
    chatUnassignedEventKeys: [
      'routing.unassigned_disconnected', // Chat was queued after Agent unexpectedly lost connection
      'routing.unassigned_remotely_signed_out', // Chat was queued after Agent was logged out
      'routing.unassigned_signed_out', // Chat was queued after Agent logged out
      'routing.unassigned_deleted', // Chat was queued after Agent was removed from the license
      'routing.unassigned_other', // Chat was queued after Agent was removed from chat for other reasons
    ],
    isSyncingMissingChatsAndMessages: false, // Prevents checking for missing chats and messages more than once at the same time
    typingIndicatorSentAt: null,
  }),

  // methods
  actions: {
    updateUnreadChatsOnTabName() {
      const app = useAppStore();

      app.updateTabName(this.totalUnreadMessagesCount);
    },
    async markAllMessagesAsRead(chat) {
      if (this.getUnreadMessagesCount(chat)) {
        await this.livechatApi.markEventsAsSeen(chat.id, this.getLatestMessage(chat).created_at_original);
      }
    },
    getUnreadMessages(chat) {
      // We need to get all messages here in case we have multiple agents in the same chat
      let messages = this.getMessages(chat);

      // Filter messages to only include those that were sent after agent_events_seen_up_to
      messages = messages.filter(function(event) {
        return event.created_at > chat.agent_events_seen_up_to;
      });

      // Filter messages to only include those that were sent by other parties
      messages = messages.filter(function(event) {
        return !event.author_is_auth_agent;
      });

      return messages;
    },
    getFirstUnreadMessage(chat) {
      let messages = this.getUnreadMessages(chat);

      return messages[0] ? messages[0] : null;
    },
    getUnreadMessagesCount(chat) {
      return this.getUnreadMessages(chat).length;
    },
    getChat(id) {
      return this.chats.find(chat => chat.id == id) ?? null;
    },
    getChatByVisitorId(visitorId) {
      return this.chats.find(chat => chat.visitor.id === visitorId) ?? null;
    },
    getChatByCurrentThreadId(threadId) {
      return this.chats.find(chat => chat.current_thread_id === threadId) ?? null;
    },
    // Get an ordered list of chat tabs
    getChats() {
      /*
        Chats are sorted by their status, in this order:
        1. Supervised chats
        2. Incoming chats
        3. Ongoing chats
        4. Archived chats

        Chats that have the same status are sorted by created at desc
      */
      return this.chats.filter(function(chat) { return !chat.is_hidden; }).sort(function(a, b) {
        let aModifier = 1; // used for sorting, depends on status
        let bModifier = 1; // used for sorting, depends on status

        if (a.status === 'supervising') aModifier = 4;
        if (a.status === 'incoming') aModifier = 3;
        if (a.status === 'ongoing') aModifier = 2;

        if (b.status === 'supervising') bModifier = 4;
        if (b.status === 'incoming') bModifier = 3;
        if (b.status === 'ongoing') bModifier = 2;

        return (b.threads[b.current_thread_id].created_at.toMillis() * bModifier) - (a.threads[a.current_thread_id].created_at.toMillis() * aModifier);
      });
    },
    // Get a list of chats that are loading
    getLoadingChats() {
      return this.chats.filter(function(chat) { return !chat.is_loaded && !chat.is_hidden; });
    },
    // Get an ordered list of loaded chat tabs
    getLoadedChats() {
      return this.getChats().filter(function(chat) { return chat.is_loaded; });
    },
    getLoadedOngoingChats() {
      return this.getLoadedChats().filter(function(chat) { return chat.status !== 'inactive'; });
    },
    // Get a list active chat IDs for auth agent
    getActiveChatIds(includeSupervised) {
      return this.getLoadedChats().filter(function(chat) {
        if (!includeSupervised) return chat.status !== 'supervising';

        return true;
      }).map(chat => chat.id);
    },
    // Get all non-closed chats
    async fetchActiveChats(pages) {
      const agents = useAgentsStore();
      const self = this;

      pages = typeof pages === 'undefined' ? 1 : pages;

      // Get latest chat summaries of the chats auth agent has access to,
      // however, do note that agent may not be the one who handled the chat,
      // so we will need to determine chats that should be considered active for auth agent
      let chatsPageOne = await this.livechatApi.getLatestChats();
      let chatsPageTwo = { chats_summary: [] };
      let chatsPageThree = { chats_summary: [] };

      if (pages >= 2 && chatsPageOne.next_page_id) {
        chatsPageTwo = await this.livechatApi.getLatestChats(chatsPageOne.next_page_id);
      }

      if (pages >= 3 && chatsPageTwo.next_page_id) {
        chatsPageThree = await this.livechatApi.getLatestChats(chatsPageTwo.next_page_id);
      }

      let chatSummaries = chatsPageOne.chats_summary.concat(chatsPageTwo.chats_summary).concat(chatsPageThree.chats_summary);

      let latestThreadIds = [];

      chatSummaries.forEach((data) => {
        // We won't load queued chats
        if (this.objectPath.has(data, 'last_thread_summary.queue.position')) return;

        latestThreadIds.push(data.last_thread_summary.id);
      });

      // Load properties for all latest threads
      let response = await axios.post('/api/v2/threads/properties', { livechat_thread_ids: latestThreadIds }, { retry: 15 });

      if (!this.isProduction) console.debug('Fetched chat summaries and properties for their latest threads:', chatSummaries, response.data);

      let activeThreadIds = [];

      // Make a list of non-closed threads
      response.data.forEach((threadProperties) => {
        let chatSummary = chatSummaries.find(summary => summary.last_thread_summary.id === threadProperties.livechat_thread_id);

        // We won't display closed chats
        if (threadProperties.is_closed) return;

        // We won't display unassigned chats unless they are specifically assigned to agent
        if (threadProperties.assigned_to_agent_id !== agents.agent.id && this.objectPath.get(chatSummary, 'last_thread_summary.properties.routing.unassigned', false)) {
          return;
        }

        let authAgentSupervisesChat = self.objectPath.has(chatSummary, 'properties.supervising.agent_ids')
            && chatSummary.properties.supervising.agent_ids.split(',').includes(agents.agent.livechat_id);

        if (authAgentSupervisesChat) {
          // Auth agent supervises chat, so we should always load it
          activeThreadIds.push(threadProperties.livechat_thread_id);
        } else if (threadProperties.assigned_to_agent_id === null) {
          // No agent is assigned to a chat thread via HAS - so we'll need to check if auth user should see the chat

          // Determines if auth agent in included in the list of chat thread users
          let authAgentHasAccessToThread = chatSummary.last_thread_summary.user_ids.includes(agents.agent.livechat_id);

          // If any other agent is present that means that the other agent is handling the chat
          let presentAgents = chatSummary.users.filter(user => user.present === true && user.type === 'agent');
          let otherAgentsArePresentInChat = presentAgents.filter(user => user.id !== agents.agent.livechat_id).length > 0;

          // If no other agent is present we'll consider that chat belongs to us,
          // for example just after ending chat supervision by auth agent they can still be present in chat for some time
          if ((authAgentHasAccessToThread && !otherAgentsArePresentInChat)) {
            activeThreadIds.push(threadProperties.livechat_thread_id);
          }
        } else {
          // Some agent is assigned to a chat thread via HAS - so we need to make sure it's auth agent
          if (threadProperties.assigned_to_agent_id === agents.agent.id) {
            activeThreadIds.push(threadProperties.livechat_thread_id);
          }
        }
      });

      // Get only chat summaries with non-closed threads
      return chatSummaries.filter((chat) => activeThreadIds.includes(chat.last_thread_summary.id));
    },
    isProspectChat(chat) {
      const tags = useTagsStore();

      let tagList = tags.getTagIdsForChatThread(chat, chat.current_thread_id);

      return tagList.includes(tags.prospectTagId);
    },
    getLastMessageTime(chat) {
      // If chat is archived then no need to show this
      if (chat.is_deactivated) return null;

      let latestMessage = this.getLatestMessage(chat);

      if (latestMessage) {
        return latestMessage.created_at;
      }

      // We'll take chat start time by default because and assume that chat was started manually so it has no replies
      return chat.threads[chat.current_thread_id].created_at;
    },
    getOtherPartyStartedWaitingTime(chat) {
      // If chat is archived then nobody is waiting for reply
      if (chat.is_deactivated) return null;

      let latestAgentMessage = this.getLatestAgentMessage(chat);
      let latestVisitorMessage = this.getLatestVistiorMessage(chat, false);

      let oldestAgentMessage = this.getOldestAgentMessage(chat);
      let oldestVisitorMessage = this.getOldestVisitorMessage(chat, false);

      // Visitor is waiting, no response from agent given yet
      if (!latestAgentMessage && latestVisitorMessage) return oldestVisitorMessage.created_at;

      // Agent is waiting, no response from visitor given yet, this can happen if the chat was manually started
      if (!latestVisitorMessage && latestAgentMessage) return oldestAgentMessage.created_at;

      // The timer should not reset to 0 for consecutive messages from the same party while they are waiting for response
      if (latestVisitorMessage && latestAgentMessage) {
        let latestMessage = this.getLatestMessage(chat);

        // Get the party that is waiting for a response
        let waitingParty = latestMessage.author_is_visitor ? 'visitor' : 'agent';

        if (waitingParty === 'agent') {
          // Agent replied and is waiting for reply from visitor,
          // so we'll start counting from this agent's reply time
          return this.getNextMessage(chat, latestVisitorMessage.id, 'agent').created_at;
        }

        if (waitingParty === 'visitor') {
          // Visitor replied and is waiting for reply from agent,
          // so we'll start counting from this visitor's reply time
          return this.getNextMessage(chat, latestAgentMessage.id, 'visitor').created_at;
        }
      }

      // We'll take chat start time by default because and assume that chat was started manually so it has no replies
      return chat.threads[chat.current_thread_id].created_at;
    },
    secondsSinceLastAgentReply(chat, now) {
      var latestAgentMessage = this.getLatestAgentMessage(chat);

      if (latestAgentMessage) return DateTime.now().diff(latestAgentMessage.created_at).as('seconds');

      // In case agent did not reply at all, we'll take chat start time instead
      return DateTime.now().diff(chat.threads[chat.current_thread_id].created_at).as('seconds');
    },
    async loadActiveChats() { // runs once during app init
      const self = this;

      if (!this.isProduction) console.debug('Loading active chats from LiveChat...');

      // Get all non-closed chats
      let activeChats = await this.fetchActiveChats(1); // Load one page of latest chats (100 chats)

      console.debug(activeChats.length + ' active ' + (activeChats.length === 1 ? 'chat' : 'chats') + ' loaded from LiveChat:', activeChats);

      // We'll treat all chats as new incoming chats because we don't know what they are until we load them
      // Also agent will not see a UI until all chats are fully loaded
      await Promise.all(activeChats.map(async (chatData) => {
        await self.handleIncomingChat(chatData, true);
      }));
    },
    async loadChat(id) { // runs once when we need to load all data for a chat
      const clients = useClientsStore();
      const tags = useTagsStore();
      const toast = useToast();

      console.debug('Loading chat data for chat #' + id + '...');

      let chat = this.getChat(id);

      chat.loading_started_at = DateTime.now();
      chat.loading_step = 'chat_loading_started (1/7)';

      chat.loading_step = 'chat_data_loading (2/7)';

      let chatData = await this.livechatApi.getChat(id);

      chat.loading_step = 'chat_data_mapping (3/7)';

      await this.mapChat(chat, chatData);

      chat.loading_step = 'thread_loading (4/7)';

      await this.loadCurrentThread(chat);

      chat.loading_step = 'tag_syncing (5/7)';

      await tags.syncTagsForChatThread(chat.id, chat.current_thread_id);

      chat.loading_step = 'visitor_loading (6/7)';

      await this.loadVisitor(chat);

      chat.loading_step = 'chat_loaded (7/7)';

      chat.loading_step = null;
      chat.loading_started_at = null;
      chat.is_loaded = true;
      chat.loaded_at = DateTime.now();

      console.debug('Loaded chat data for chat #' + id + ':', chat);
    },
    async loadCurrentThread(chat) { // runs once on incoming_chat event
      const self = this;

      if (!chat) return;

      console.debug('Loading thread #' + chat.current_thread_id + ' data for chat #' + chat.id + '...');

      // We'll load current thread with events to get fresh data
      // because when chat is transferred back these events will be missing
      await this.livechatApi.getLatestChatThreads(chat.id).then(function (data) {
        self.mapThreads(chat, data);
      });

      await this.syncThreadProperties(chat, chat.current_thread_id);

      let messages = this.getMessages(chat);
      let latestAgentMessage = this.getLatestAgentMessage(chat);
      let latestVisitorMessage = this.getLatestVistiorMessage(chat);

      // At the very least agent has seen events up to their latest reply
      if (!chat.agent_events_seen_up_to && latestAgentMessage) {
        chat.agent_events_seen_up_to = latestAgentMessage.created_at;
      } else {
        chat.agent_events_seen_up_to = null;
      }

      if (!chat.visitor_events_seen_up_to && latestVisitorMessage) {
        // At the very least visitor has seen events up to their latest reply
        chat.visitor_events_seen_up_to = latestVisitorMessage.created_at;
      } else {
        chat.visitor_events_seen_up_to = null;
      }

      console.debug('Loaded thread #' + chat.current_thread_id + ' data for chat #' + chat.id);
    },
    // Runs once on incoming_chat event and periodically for active chats
    async loadVisitor(chat, isReloading) {
      const self = this;
      const tags = useTagsStore();
      const toast = useToast();

      if (!chat) return;

      isReloading = isReloading === true ? true : false;

      if (isReloading && chat.visitor.loaded_at) {
        let lastLoadedAtDiffInSeconds = DateTime.now().diff(chat.visitor.loaded_at).as('seconds');

        // We should reload visitor info every ~50 seconds
        if (lastLoadedAtDiffInSeconds < 50) return false;

        chat.visitor.loaded_at = null;
      }

      if (isReloading) {
        console.debug('Reloading visitor data for chat #' + chat.id + ' thread #' + chat.current_thread_id + ':', chat.visitor);
      } else {
        console.debug('Loading visitor data for chat #' + chat.id + ' thread #' + chat.current_thread_id + ':', chat.visitor);
      }

      // If we've previously loaded a visitor we do not want show "Loading..." text
      // we'll simply load the data and update the UI
      if (!chat.visitor.is_loaded) {
        chat.visitor.is_loaded = null;
      }

      await this.livechatApi.getVisitor(chat.visitor.id).then(async function (visitorData) {
        chat.visitor = {...chat.visitor, ...visitorData};

        // Try to detect first and last name
        chat.visitor.first_name = chat.visitor.name.split(' ').slice(0, 1).join(' ');
        chat.visitor.last_name = chat.visitor.name.split(' ').slice(1).join(' ');

        chat.visitor.created_at = DateTime.fromISO(chat.visitor.created_at);
        chat.visitor.timezone = chat.visitor.timezone ? chat.visitor.timezone : null;

        if (chat.visitor.agent_last_event_created_at) {
          chat.visitor.agent_last_event_created_at = DateTime.fromISO(chat.visitor.agent_last_event_created_at);
        }

        if (chat.visitor.customer_last_event_created_at) {
          chat.visitor.customer_last_event_created_at = DateTime.fromISO(chat.visitor.customer_last_event_created_at);
        }

        if (chat.visitor.last_visit && chat.visitor.last_visit.started_at) {
          chat.visitor.last_visit.started_at = DateTime.fromISO(chat.visitor.last_visit.started_at);
        }

        if (chat.visitor.last_visit && chat.visitor.last_visit.ended_at) {
          chat.visitor.last_visit.ended_at = DateTime.fromISO(chat.visitor.last_visit.ended_at);
        }

        self.objectPath.ensureExists(chat, 'visitor.last_visit.last_pages', []);

        if (chat.visitor.last_visit.last_pages.length) {
          chat.visitor.last_visit.last_pages.map(function (page, index) {
            let nextPage = chat.visitor.last_visit.last_pages[index + 1];

            page.opened_at = DateTime.fromISO(page.opened_at);

            if (nextPage) {
              page.closed_at = DateTime.fromISO(nextPage.opened_at);
            }
          });
        }

        chat.visitor.user_agent = null;

        if (chat.visitor.last_visit.user_agent) {
          // Parse visitor's User Agent string
          let userAgentParser = new UAParser();
          userAgentParser.setUA(chat.visitor.last_visit.user_agent);
          chat.visitor.user_agent = userAgentParser.getResult();
        }

        if (!isReloading) {
          // Sync visitor properties with our backend
          await axios.get('/api/v2/visitors/' + chat.visitor.id + '/properties').then(function (response) {
            chat.visitor.banned_until = response.data.banned_until ? DateTime.fromISO(response.data.banned_until) : null;
            chat.visitor.rto_count = response.data.rto_count ? response.data.rto_count : 0;
          });
        }

        chat.visitor.is_loaded = true;
        chat.visitor.loaded_at = DateTime.now();

        if (!self.isProduction) console.debug('Loaded visitor data for chat #' + chat.id + ' thread #' + chat.current_thread_id + ':', chat.visitor);
      }).catch(function (error) {
        console.error(error);

        Bugsnag.notify(error);

        // When we are reloading already loaded visitor and have an error,
        // we shouldn't show an error to agent in UI, instead we'll simply retry again in a few seconds
        if (isReloading) {
          chat.visitor.is_loaded = false;

          toast.failedToLoadVisitor(chat.current_thread_id);
        }
      });

      // Get visitor's timezone based on their location
      if (
        !chat.visitor.timezone
        && chat.visitor.last_visit
        && chat.visitor.last_visit.geolocation
        && chat.visitor.last_visit.geolocation.latitude
        && chat.visitor.last_visit.geolocation.longitude
      ) {
        axios.post('/api/v2/location-to-timezone', {
          coordinates: chat.visitor.last_visit.geolocation.latitude + ',' + chat.visitor.last_visit.geolocation.longitude,
        }).then(function (response) {
          chat.visitor.timezone = response.data.timezone;

          if (!self.isProduction) console.debug('Visitor #' + chat.visitor.id + ' timezone detected:', chat.visitor.timezone);
        }).catch(function (error) {
          console.error(error);
        });
      }

      // Check if visitor's IP indicates that they are a prospect,
      // do note that visitors from Philippines cannot be prospects
      if (
        chat.visitor.last_visit
        && chat.visitor.last_visit.ip
        && chat.visitor.last_visit.geolocation.country_code
        && chat.visitor.last_visit.geolocation.country_code.toUpperCase() !== 'PH'
      ) {
        axios.get('/api/prospect-testing-ips/has', {
          params: { ip: chat.visitor.last_visit.ip }
        }).then(function (response) {
          if (response.data.status) {
            tags.addTagToChatThread(chat, chat.current_thread_id, tags.prospectTagId);

            console.debug('Visitor marked as prospect.');
          }
        }).catch(function (error) {
          console.error(error);
        });
      }
    },
    async reloadVisitors() {
      const self = this;

      let chats = this.getLoadedOngoingChats();

      await Promise.all(chats.map(async (chat) => {
        await self.loadVisitor(chat, true);
      }));
    },
    async openChat(id) { // runs every time agent clicks on a different chat tab
      let chat = this.getChat(id);

      if (!chat) throw 'Chat not found.';

      if (chat.status === 'incoming') {
        this.setChatStatus(chat, 'ongoing');
      }

      // If chat is archived or queued, we can't read the usual way by focusing on the input
      // so we'll simply consider all events as read once we open the chat tab
      if (chat.is_deactivated || (chat.is_unassigned && this.getUnreadMessagesCount(chat))) {
        this.markAllMessagesAsRead(chat);
      }

      this.broadcastChatSwitchedMessage(chat);

      return chat;
    },
    markChatAsDeactivated(chat, isTransferred) {
      if (chat.status === 'supervising') {
        return this.stopAndCloseSupervisedChat(chat);
      }

      this.cancelHold(chat);

      chat.is_deactivated = true;

      if (isTransferred === true) chat.is_transferred = true;

      this.setChatStatus(chat, 'inactive');
    },
    async openNewChatThread(chat) {
      const clients = useClientsStore();
      const copilot = useCopilot();
      const toast = useToast();
      const self = this;

      copilot.close();

      if (!chat.is_deactivated) return false;

      await this.livechatApi.resumeChat(chat.id, clients.getClientByCode(chat.client_code).livechat_id).catch(function (error) {
        // This is likely a fake error caused by LiveChat ChatSDK, let's check if it's a real error
        if (self.objectPath.has(error, 'payload.error.message')) {
          console.error(error);

          toast.error(error.payload.error.message);

          Bugsnag.notify(error);
        }
      });
    },
    showFileUploadModal(chat) {
      chat.show_file_upload_modal = true;
    },
    showCloseChatModal(chat) {
      chat.show_close_chat_confirmation_modal = true;
    },
    // Close the chat when chat is unassigned or is transferred away (without confirmation)
    async closeChat(chat, showToast) {
      const agents = useAgentsStore();
      const toast = useToast();

      let chatId = chat.id;
      let threadId = chat.current_thread_id;

      this.removeChat(chatId);

      if (showToast) toast.chatClosed(threadId);

      this.livechatApi.unfollowChat(chatId);
    },
    // Stop and archive chat
    async stopChat(chat) {
      const toast = useToast();

      await this.deactivateChat(chat.id);

      toast.chatStopped(chat.current_thread_id);
    },
    async stopAndCloseChat(chat) {
      const app = useAppStore();
      const toast = useToast();
      const self = this;

      if (!app.online || !app.livechatOnline) {
        toast.cannotDoWhileOffline('close chat');

        return false;
      }

      // Supervised chats have their own handling
      if (chat.status === 'supervising') {
        return this.stopAndCloseSupervisedChat(chat);
      }

      // If chat was transferred to other agent we'll simply remove the chat tab
      if (chat.is_transferred) return this.closeChat(chat);

      let chatId = chat.id;
      let threadId = chat.current_thread_id;
      let chatIsDeactivated = chat.is_deactivated;

      // Remove chat from UI, but don't remove it from this Pinia storage yet because it will be considered "missing"
      chat.is_hidden = true;

      // Mark chat thread as closed on HF side
      await axios.patch('/api/v2/threads/' + threadId + '/mark-closed', {}, { retry: 15 }).then(function (response) {
        // Show the toast as soon as chat is hidden from UI
        if (chatIsDeactivated) {
          toast.chatClosed(threadId);
        } else {
          toast.chatClosedAndArchived(threadId);
        }

        // Mark chat thread as closed on LiveChat side
        if (!chatIsDeactivated) self.deactivateChat(chatId);
      }).catch(function (error) {
        console.error(error);

        Bugsnag.notify(error);

        toast.failedToCloseChat(threadId);
      }).finally(() => {
        // Remove chat, in case there's an error we'll load it again in a few seconds
        self.removeChat(chatId);
      });
    },
    async stopAndCloseSupervisedChat(chat) {
      const agents = useAgentsStore();
      const toast = useToast();

      // We can only close supervised chats using this method
      if (chat.status !== 'supervising') return;

      let chatId = chat.id;
      let threadId = chat.current_thread_id;

      if (!this.isProduction) console.debug('Ending chat #' + chatId + ' supervision...');

      toast.chatSupervisionStopped(threadId);

      // Remove chat from UI, but don't remove it from this Pinia storage yet because it will be considered "missing"
      chat.is_hidden = true;

      try {
        // We need to re-load chat properties and find if other agents are supervising the chat
        let supervisedByAgentIds = await this.getChatSupervisingAgentIds(chatId);

        // Remove auth agent from this list
        let updatedSupervisingAgentIds = supervisedByAgentIds.filter(function(livechatId) { return livechatId !== agents.agent.livechat_id; });

        updatedSupervisingAgentIds = updatedSupervisingAgentIds.join(',');

        await this.livechatApi.updateChatSupervisors(chatId, updatedSupervisingAgentIds);
      } catch (error) {
        // This is likely a fake error caused by LiveChat ChatSDK
        console.error(error);
      } finally {
        this.removeChat(chat.id);
      }
    },
    async deactivateChat(chatId) {
      const toast = useToast();
      const self = this;

      await this.livechatApi.deactivateChat(chatId).catch(function (error) {
        // This is likely a fake error caused by LiveChat ChatSDK, let's check if it's a real error
        if (self.objectPath.has(error, 'payload.error.message')) {
          console.error(error);

          toast.error(error.payload.error.message);

          Bugsnag.notify(error);
        }
      });
    },
    // Runs once for each chat during app loading
    // and every time there's a new incoming_chat event
    async handleIncomingChat(data, canViewChat) {
      console.debug('Handling incoming chat...', data);

      const agents = useAgentsStore();
      const clients = useClientsStore();

      let chatData;
      let threadId;
      let threadCreatedAt;
      let clientCode;

      // Listing all chats provides different data so we need to account for that
      if (data.last_thread_summary && data.last_thread_summary.created_at) {
        chatData = data;
        threadId = data.last_thread_summary.id;
        threadCreatedAt = DateTime.fromISO(data.last_thread_summary.created_at);
      } else {
        chatData = data.payload.chat;
        threadId = chatData.thread.id;
        threadCreatedAt = DateTime.fromISO(chatData.thread.created_at);
      }

      // Check if we have overridden the permission to view chat (in some cases we know that agent should be able to view chat)
      if (typeof canViewChat === 'undefined') {
        // Find auth agent user data in a list of chat users
        let chatUser = chatData.users.find(user => user.id === agents.agent.livechat_id);

        // By default agent can view chat only if he's handling it
        canViewChat = chatUser && chatUser.present === true;
      }

      // Auth agent can always view supervised chat
      if (this.objectPath.has(chatData, 'properties.supervising.agent_ids') && chatData.properties.supervising.agent_ids.split(',').includes(agents.agent.livechat_id)) {
        canViewChat = true;
      }

      // Check if the chat is assigned to auth agent
      if (!canViewChat) return false;

      clientCode = clients.getClientByLiveChatId(chatData.access.group_ids[0]).code;

      let chat = this.getChat(chatData.id);

      if (chat) {
        // Existing chat tab has a new thread incoming
        await this.handleNewThread(chat, chatData, threadId, threadCreatedAt);
      } else {
        // New chat tab opened (or we're initializing the application)
        await this.handleNewChat(chatData, threadId, threadCreatedAt, clientCode);
      }
    },
    async handleNewChat(chatData, threadId, threadCreatedAt, clientCode) { // create new chat tab
      const agents = useAgentsStore();
      const notifications = useNotificationsStore();
      const toast = useToast();

      let chat = {
        id: chatData.id,
        status: 'incoming',
        client_code: clientCode,
        current_thread_id: threadId,
        agent_events_seen_up_to: null,
        visitor_events_seen_up_to: null,
        message_draft: '',
        threads: {},
        visitor: { is_loaded: null, name: 'Visitor' },
        is_hidden: false,
        is_loaded: false,
        is_deactivated: false,
        is_transferred: false,
        is_unassigned: false,
        is_private_message_mode: false,
        show_rto_modal: false,
        show_file_upload_modal: false,
        show_close_chat_confirmation_modal: false,
        loaded_at: null,
      };

      // This is needed so that chat times would start working right away
      this.setChatThreadCreatedAt(chat, threadId, threadCreatedAt);

      // Add chat to chats array, however, we won't show the chat in UI until it's fully loaded
      this.chats.push(chat);

      // Note: it's NOT guaranteed that this data is accurate at this point due to LiveChat issues
      if (this.objectPath.has(chatData, 'properties.supervising.agent_ids') && chatData.properties.supervising.agent_ids.includes(agents.agent.livechat_id)) {
        chat.status = 'supervising';
        chat.is_private_message_mode = true;

        this.handleChatSupervisingStartedOnLiveChat(chat.id);
      }

      if (chat.status !== 'supervising') {
        let onlyIfUnassigned = true; // Sometimes LiveChat can have incorrect data about chat supervisors

        await this.markChatThreadAsAssignedToAgent(threadId, agents.agent.id, onlyIfUnassigned);
      }

      try {
        // We need to load entire chat data including visitor, threads, tags, etc
        await this.loadChat(chatData.id);

        // Send a browser notification after chat loads
        notifications.notify({
          title: 'Incoming chat',
          body: chat.visitor.name + ' has started chat',
          sound: 'new-chat',
          data: {
            router_path: this.router.resolve({ name: 'chat', params: { id: chat.id }}).path,
          }
        });
      } catch (error) {
        console.error(error);

        toast.failedToLoadChat(threadId);

        // Remove chat to make it come back in a few seconds
        this.chats = this.chats.filter(function(chat) { return chat.id !== chatData.id; });

        Bugsnag.notify(
          error,
          function (event) {
            event.severity = 'warning';
          }
        );
      }
    },
    async handleNewThread(chat, chatData, threadId, threadCreatedAt) { // update existing chat tab
      const agents = useAgentsStore();
      const notifications = useNotificationsStore();

      chat.is_hidden = false; // It's a new thread that makes chat active again
      chat.is_deactivated = false; // It's a new thread that makes chat active again
      chat.is_unassigned = false; // It's a new thread that is assigned to auth agent
      chat.is_transferred = false; // It's a new thread that was not transferred to somebody else
      chat.current_thread_id = threadId; // We need set the current thread ID immediately to re-render chat history
      chat.visitor.is_loaded = null; // We'll set visitor state as loading
      chat.loaded_at = null;
      chat.loading_step = 'thread_loading (4/7)';

      this.clearSneakPeek(chat); // Clear visitor message sneak peek

      // This is needed so that chat times would start working right away
      this.setChatThreadCreatedAt(chat, threadId, threadCreatedAt);

      if (this.activeChatId === chat.id) {
        this.setChatStatus(chat, 'ongoing');
      } else if (chat.status !== 'incoming') {
        // Even if chat is transferred back to auth agent we'd consider this as an incoming chat
        this.setChatStatus(chat, 'incoming');
      }

      await this.markChatThreadAsAssignedToAgent(threadId, agents.agent.id);

      await this.loadCurrentThread(chat);

      // No need to actually sync tags since there cannot be any because it's a new thread
      chat.loading_step = 'tag_syncing (5/7)';

      chat.loading_step = 'visitor_loading (6/7)';

      // We need to reload visitor data because it has changed
      await this.loadVisitor(chat);

      chat.loading_step = 'chat_loaded (7/7)';

      // Update loaded time since we base some other logic on this timestamp
      chat.loaded_at = DateTime.now();

      // Send a browser notification after new chat thread loads
      notifications.notify({
        title: 'Incoming chat',
        body: chat.visitor.name + ' has reconnected',
        sound: 'new-chat',
        data: {
          router_path: this.router.resolve({ name: 'chat', params: { id: chat.id }}).path,
        }
      });
    },
    handleIncomingEvent(data) {
      const notifications = useNotificationsStore();

      let chat = this.getChat(data.payload.chat_id);
      let threadId = data.payload.thread_id;

      if (!chat) return false;

      let event = data.payload.event;

      event = this.mapEvent(chat, event, threadId);

      if (event.form_type === 'postchat') {
        // Chat is already archived, nothing to do here
      } else if (event.system_message_type && this.chatArchivedEventKeys.includes(event.system_message_type)) {
        // Chat was archived
        this.setChatStatus(chat, 'inactive');
      } else if (event.system_message_type && this.chatUnassignedEventKeys.includes(event.system_message_type)) {
        // Chat was unassigned from agents
        // possibly due to agents being transferred from one group to the other
        this.setChatStatus(chat, 'inactive');
        chat.is_unassigned = true;
      } else if (!event.system_message_type && chat.status !== 'incoming') {
        // It's a reply from either party so chat continues (or restarts)
        this.setChatStatus(chat, 'ongoing');
        chat.is_deactivated = false;
      } else if (event.author_is_auth_agent && chat.status === 'incoming') {
        // It's a reply from auth agent so we'll mark the chat as ongoing
        // maybe message was sent from LiveChat website during testing or it's an automatic greeting
        this.setChatStatus(chat, 'ongoing');
      }

      this.objectPath.push(chat, 'threads.' + threadId + '.events', event);

      this.detectAndHandleChatRatedEvent(chat, threadId);

      if (event.author_is_visitor) {
        // Clear visitor message sneak peek
        this.clearSneakPeek(chat);

        // Send a browser notification
        notifications.notify({
          title: `${chat.visitor.name} says...`,
          body: data.payload.event.type === 'file' ? data.payload.event.name : data.payload.event.text,
          sound: 'new-message',
          data: {
            router_path: this.router.resolve({ name: 'chat', params: { id: chat.id }}).path,
          }
        });
      }

      this.emitter.emit('incomingEvent', {
        chat: chat,
        event: event,
      });
    },
    // Runs when visitor data gets updated
    async handleIncomingCustomer(data) {
      let chat = this.getChatByVisitorId(data.payload.id);

      // If we have already removed chat or in the process of removing it,
      // then there's no need to load the visitor info anymore

      if (data.payload.state === 'chat closed') return false;

      if (!chat) return false;

      if (chat.is_hidden) return false;

      // We need to reload visitor data because it has changed
      await this.loadVisitor(chat);
    },
    handleEventsMarkedAsSeen(data) {
      const agents = useAgentsStore();

      let chat = this.getChat(data.payload.chat_id);

      if (!chat) return false;

      // Mark chat events as seen up to a certain timestamp
      if (data.payload.user_id === agents.agent.livechat_id) {
        chat.agent_events_seen_up_to = DateTime.fromISO(data.payload.seen_up_to);
      } else if (data.payload.user_id === chat.visitor.id) {
        chat.visitor_events_seen_up_to = DateTime.fromISO(data.payload.seen_up_to);
      }
    },
    handleChatTransferred(data) {
      const agents = useAgentsStore();

      // We need to update our backend to let it know that the newly assigned agent is auth agent
      if (this.objectPath.has(data.payload, 'transferred_to.agent_ids') && data.payload.transferred_to.agent_ids.includes(agents.agent.livechat_id)) {
        this.markChatThreadAsAssignedToAgent(data.payload.thread_id, agents.agent.id);

        this.removeAuthAgentFromSupervisors(data.payload.chat_id);
      }

      let chat = this.getChat(data.payload.chat_id);

      // If chat tab is missing, then this is a new chat for auth agent,
      // so we'll use default handling for incoming chats in another method
      if (!chat) return false;

      if (this.objectPath.has(data.payload, 'transferred_to.agent_ids')) {
        if (data.payload.transferred_to.agent_ids.includes(agents.agent.livechat_id)) {
          // Auth agent was added to the chat (e.g. manually assigned chat to himself or other agent lost connection)
          chat.is_unassigned = false;

          // In case chat was supervised, we need to make sure it no longer is
          chat.status = 'incoming';
          chat.is_private_message_mode = false;
        } else if (chat.status === 'supervising') {
          // No need to do anything, auth agent can continue chat supervision
        } else if (!data.payload.transferred_to.agent_ids.includes(agents.agent.livechat_id)) {
          // Chat was transferred from auth agent to somebody else
          this.markChatAsDeactivated(chat, true);
        }
      } else {
        // Chat was transferred from an agent to a group, and thus is now unassigned
        chat.is_unassigned = true;
      }
    },
    async removeAuthAgentFromSupervisors(chatId) {
      const agents = useAgentsStore();

      // We need to re-load chat properties and find if other agents are supervising the chat
      let supervisedByAgentIds = await this.getChatSupervisingAgentIds(chatId);

      // Remove auth agent from the list of supervisors
      supervisedByAgentIds = supervisedByAgentIds.filter(function(livechatAgentId) { return livechatAgentId !== agents.agent.livechat_id; });

      this.livechatApi.updateChatSupervisors(chatId, supervisedByAgentIds.join(','));
    },
    handleChatPropertiesUpdated(data) {
      const agents = useAgentsStore();

      // Handle changes to chat supervision
      if (this.objectPath.has(data, 'payload.properties.supervising')) {
        let authAgentSupervisesChat = data.payload.properties.supervising.agent_ids.split(',').includes(agents.agent.livechat_id);

        if (authAgentSupervisesChat) {
          console.debug('Started supervising chat #' + data.payload.chat_id);

          // Find and load the supervised chat
          setTimeout(() => {
            this.syncMissingChatsAndMessages();
          }, 500);
        } else {
          let chat = this.getChat(data.payload.chat_id);

          // Auth agent no longer supervises the chat, but it's still visible in UI, so we need to force close it
          if (chat && chat.status === 'supervising' && !chat.is_deactivated) {
            console.debug('Ended supervising chat #' + data.payload.chat_id);
            this.stopAndCloseSupervisedChat(chat);
          }
        }
      }
    },
    handleEventPropertiesUpdated(data) {
      let chat = this.getChat(data.payload.chat_id);

      if (!chat) return false;

      if (chat && chat.threads && chat.threads[data.payload.thread_id] && chat.threads[data.payload.thread_id].events) {
        let eventIndex = chat.threads[data.payload.thread_id].events.findIndex((event => event.id === data.payload.event_id));

        // Update event properties
        chat.threads[data.payload.thread_id].events[eventIndex].properties = data.payload.properties;
      }
    },
    handleChatDeactivated(data) {
      let chat = this.getChat(data.payload.chat_id);

      if (!chat) return false;

      this.markChatAsDeactivated(chat);
    },
    handleVisitorPageChange(data) {
      let chat = this.getChatByVisitorId(data.payload.customer_id);

      if (!chat) return false;

      // if visitor is not loaded we cannot handle this
      if (!chat.visitor.is_loaded) return false;

      this.objectPath.ensureExists(chat, 'visitor.last_visit.last_pages', []);

      // Set previous page closed at time
      if (chat.visitor.last_visit.last_pages.length) {
        chat.visitor.last_visit.last_pages[chat.visitor.last_visit.last_pages.length - 1].closed_at = DateTime.fromISO(data.payload.opened_at);
      }

      chat.visitor.last_visit.last_pages.push({
        title: data.payload.title ?? null,
        opened_at: DateTime.fromISO(data.payload.opened_at),
        url: data.payload.url,
      });
    },
    handleIncomingSneakPeek(data) {
      let chat = this.getChat(data.payload.chat_id);

      if (!chat) return false;

      if (data.payload.sneak_peek.author_id !== chat.visitor.id) return false;

      chat.visitor_message_sneak_peek = data.payload.sneak_peek.text;
      chat.visitor_message_sneak_peek_time = DateTime.fromSeconds(data.payload.sneak_peek.timestamp);

      this.emitter.emit('incomingSneakPeek', { chat: chat });
    },
    handleVisitorBanned(data) {
      const clients = useClientsStore();

      let chat = this.getChatByVisitorId(data.payload.customer_id);

      if (!chat) return false;

      let client = clients.getClientByCode(chat.client_code);

      let banDuration = data.payload.ban.days;

      // This is an approximate timestamp, the accurate one is stored on the LiveChat backend
      chat.visitor.banned_until = DateTime.now().plus({ days: banDuration });

      // Chat will be automatically deactivated but the push won't be sent
      this.markChatAsDeactivated(chat);
    },
    mapEvent(chat, event, threadId) {
      const agents = useAgentsStore();

      event.thread_id = threadId;
      event.created_at_original = event.created_at;
      event.created_at = DateTime.fromISO(event.created_at);

      // Replace plain-text URLs with anchor tags
      event.text = Autolinker.link(event.text, {
        phone: false,
      });

      let agent = agents.getAgentByLivechatId(event.author_id);

      if (event.system_message_type) {
        event.author_is_system = true;
      } else if (event.author_id === chat.visitor.id) {
        event.author_is_visitor = true;
      } else if (agent) {
        event.author_is_agent = true;

        if (event.author_id === agents.agent.livechat_id) {
          event.author_is_auth_agent = true;
        }
      } else {
        // The issue here is that the visitor is likely not yet loaded, so we don't have their ID

        // Almost certainly this is visitor's message, however, we can't be 100% sure,
        // because sometimes LiveChat wouldn't send visitor ID for some reason
        event.author_is_visitor = true;

        console.warn('Visitor information may be incorrect:', chat.visitor);
        console.warn('Visitor ID is missing in the event:', event);

        // We need to collect more data so we can resolve this issue
        Bugsnag.notify(
          new Error('Failed to determine event author with 100% accuracy (author_id: ' + event.author_id + ' / visitor_id: ' + chat.visitor.id + ').'),
          function (event) {
            event.severity = 'warning';
            event.unhandled = true;
          }
        );
      }

      if (event.type === 'file' && event.content_type) {
        // Sometimes LC includes unnecessary data after MIME type (e.g. "text/plain; charset=utf-8")
        event.mime_type = event.content_type ? event.content_type.split(';').shift() : null;
      }

      return event;
    },
    async mapChat(chat, data) {
      if (!chat) return;

      console.debug('Mapping chat data for chat #' + chat.id + '...', data);

      let visitor = data.users.find(user => user.type.toLowerCase() === 'customer');

      if (!visitor) console.error('Visitor was not found in chat users!', data);

      chat.visitor.id = visitor.id;

      if (!data.thread.active) {
        this.markChatAsDeactivated(chat);
      } else {
        let lastEvent = data.thread.events[data.thread.events.length - 1];

        if (lastEvent && lastEvent.system_message_type && this.chatArchivedEventKeys.includes(lastEvent.system_message_type)) {
          this.setChatStatus(chat, 'inactive');
        } else if (this.checkIfChatIsIncoming(chat, data.thread)) {
          this.setChatStatus(chat, 'incoming');
        } else if (data.thread.active) {
          this.setChatStatus(chat, 'ongoing');
        } else {
          this.setChatStatus(chat, 'inactive');
        }
      }
    },
    mapThreads(chat, data) {
      data.threads.forEach((threadData, index) => {
        this.mapThread(chat, threadData, index);
      });
    },
    mapThread(chat, threadData, index) {
      index = typeof index === 'undefined' ? 0 : index;

      let threadId = threadData.id;

      this.objectPath.ensureExists(chat, 'threads.' + threadId, {});

      // Set chat "unassigned" status for current thread
      if (chat.current_thread_id === threadId) {
        chat.is_unassigned = threadData.properties.routing.unassigned;
      }

      // This means we're mapping the previous thread right now
      if (index === 1) chat.previous_thread_id = threadId;

      this.setChatThreadCreatedAt(chat, threadId, DateTime.fromISO(threadData.created_at));

      threadData.events.forEach((event) => {
        let mappedEvent = this.mapEvent(chat, event, threadId);

        this.addEventToChatThreadIfMissing(chat, threadId, mappedEvent);
      });

      // Sort events (in case missing ones were added)
      this.sortEventsForChatThread(chat, threadId);

      // Find the last chat_rated event (if exists) and update the UI
      this.detectAndHandleChatRatedEvent(chat, threadId);

      // Find the last chat deactivated event (if exists) for current thread and update the UI
      this.detectAndHandleCurrentChatThreadDeactivatedEvent(chat);
    },
    addEventToChatThreadIfMissing(chat, threadId, mappedEvent) {
      // Get current events for specific chat thread
      let chatEvents = this.getEvents(chat, threadId);

      // Find an existing event
      let existingEvent = chatEvents.find(target => mappedEvent.id === target.id);

      if (existingEvent) return;

      // Add an event only if it's missing (e.g. chat was transferred back)
      this.objectPath.push(chat, 'threads.' + threadId + '.events', mappedEvent);

      // Sort events (in case missing ones were added)
      this.sortEventsForChatThread(chat, threadId);
    },
    detectAndHandleChatRatedEvent(chat, threadId) {
      let events = this.getEvents(chat, threadId);

      // Find the last chat_rated event (visitor may rate the chat multiple times, we need only the last one)
      let event = events.findLast((event) => event.system_message_type === 'rating.chat_rated')

      if (!event) return;

      // Update UI with a new chat rating
      this.objectPath.set(chat, 'threads.' + threadId + '.rating', event.text_vars.score);
    },
    detectAndHandleCurrentChatThreadDeactivatedEvent(chat) {
      if (chat.is_deactivated) return;

      // We want to do this check only for current thread
      let threadId = chat.current_thread_id;

      let events = this.getEvents(chat, threadId);

      // Find the last event that shows that current chat thread is archived
      let event = events.findLast((event) => event.system_message_type && this.chatArchivedEventKeys.includes(event.system_message_type))

      if (!event) return;

      // If chat is archived then we'll mark it as archived
      this.markChatAsDeactivated(chat);

      console.debug('Detected that chat #' + chat.id + ' thread #' + threadId + ' is now archived.');
    },
    async syncMissingChatsAndMessages() {
      const app = useAppStore();
      const agents = useAgentsStore();
      const self = this;

      // No need to try to sync when we're offline
      if (!app.online || !app.livechatOnline) return;

      if (this.isSyncingMissingChatsAndMessages) return;

      this.isSyncingMissingChatsAndMessages = true;

      if (!this.isProduction) console.debug('Syncing missing chats and messages from LiveChat...');

      try {
        // We want to check for missing messages only for fully loaded chats
        this.chats.filter(function(chat) { return chat.is_loaded; }).forEach(this.syncMissingChatMessages);

        // Get all non-closed chats, we'll load only 100 latest chats for optimal performance
        let activeChats = await this.fetchActiveChats(1);

        activeChats.forEach((chatSummary) => {
          let chat = this.getChat(chatSummary.id);

          if (!chat) return;

          if (this.objectPath.has(chatSummary, 'properties.supervising.agent_ids') && chatSummary.properties.supervising.agent_ids.includes(agents.agent.livechat_id)) {
            // Chat could've been incorrectly marked as transferred or deactivated, so we need to reverse that
            chat.is_transferred = false;
            chat.is_deactivated = false;

            chat.status = 'supervising';
            chat.is_private_message_mode = true;

            console.debug('Detected that supervised chat #' + chat.id + ' is not marked as supervised.');
          }
        });

        // Check if we have missing chats
        let missingChats = activeChats.filter(activeChat => this.chats.filter(function(chat) { return chat.id === activeChat.id; }).length === 0);

        // If we do have missing chat then we'll load and tread each chat as incoming
        await Promise.all(missingChats.map(async (chatData) => {
          if (!self.isProduction) console.debug('Found missing chat:', chatData);

          await self.handleIncomingChat(chatData, true);
        }));
      } catch (e) {
        // Likely LiveChat API request failed because auth agent is offline
      } finally {
        this.isSyncingMissingChatsAndMessages = false;

        if (!this.isProduction) console.debug('Finished syncing missing chats and messages from LiveChat.');
      }
    },
    async syncMissingChatMessages(chat) {
      // This is not very efficient, but we need to load all thread messages
      let threadData = await this.livechatApi.getLatestChatThread(chat.id);

      // Chat has likely been transferred
      if (threadData.restricted_access) return;

      // Check if we have missing events
      let currentEventIds = this.getEvents(chat, chat.current_thread_id).map(event => event.id);
      let fetchedEventIds = threadData.events.map(event => event.id);
      let missingEventIds = fetchedEventIds.filter(id => !currentEventIds.includes(id));

      missingEventIds.forEach((missingEventId) => {
        console.debug('Detected missing event #' + missingEventId + ' for chat #' + chat.id);
      });

      // We need to use mapThread because some missing events require special handling
      this.mapThread(chat, threadData);

      // To fully sync the chat, we also need to sync its properties
      this.syncThreadProperties(chat, chat.current_thread_id, true);
    },
    getEvents(chat, threadId) {
      // Get all events sorted by their created_at date ASC
      if (chat && chat.threads && chat.threads[threadId] && chat.threads[threadId].events) {
        return chat.threads[threadId].events.sort(function(a, b) {
          return a.created_at - b.created_at;
        });
      }

      return [];
    },
    async getChatSupervisingAgentIds(chatId) {
      let chatData = await this.livechatApi.getChat(chatId);

      // Get comma-separated string of LC agent IDs and convert that to array
      return convertCommaSeparatedStringToArray(this.objectPath.get(chatData, 'properties.supervising.agent_ids', ''));
    },
    getEvent(chat, threadId, eventId) {
      if (!this.objectPath.has(chat, 'threads.' + threadId + '.events')) return null;

      // Find the event with given ID
      let events = chat.threads[threadId].events.filter(function(event) {
        return event.id !== eventId;
      });

      return events.length === 1 ? events[0] : null;
    },
    sortEventsForChatThread(chat, threadId) {
      // Sort events (in case missing ones were added)
      chat.threads[threadId].events = this.getEvents(chat, threadId);
    },
    getCurrentThreadEvents(chat) {
      return this.getEvents(chat, chat.current_thread_id);
    },
    getMessages(chat) {
      return this.getCurrentThreadEvents(chat).filter(function(event) {
        // We exclude system messages because we want to get only the messages from agents and visitors
        return !event.author_is_system;
      });
    },
    getFileMessages(chat) {
      // We'll exclude system messages because they can't contain files
      return this.getMessages(chat).filter(function(event) {
        return event.type === 'file';
      });
    },
    getAgentMessages(chat) {
      return this.getCurrentThreadEvents(chat).filter(function(event) {
        return event.author_is_agent === true;
      });
    },
    getVisitorMessages(chat, excludeForms) {
      return this.getCurrentThreadEvents(chat).filter(function(event) {
        if (excludeForms) {
          if (event.type === 'filled_form') return false;
        }

        return event.author_is_visitor === true;
      });
    },
    getSystemMessages(chat) {
      return this.getCurrentThreadEvents(chat).filter(function(event) {
        return event.author_is_system === true;
      });
    },
    getNextMessage(chat, eventId, authorType) {
      let messages = this.getMessages(chat);

      let eventIndex = messages.findIndex(event => event.id === eventId);

      messages = messages.slice(eventIndex + 1);

      for (var i = 0; i < messages.length; i++) {
        if (authorType === 'visitor' && messages[i].author_is_visitor) {
          return messages[i];
        } else if (authorType === 'agent' && messages[i].author_is_agent) {
          return messages[i];
        }
      }

      return null;
    },
    getLatestEvent(chat) {
      let messages = this.getCurrentThreadEvents(chat);

      return messages[messages.length - 1] ?? null;
    },
    getLatestMessage(chat) {
      let messages = this.getMessages(chat);

      return messages[messages.length - 1] ?? null;
    },
    getLatestAgentMessage(chat) {
      let messages = this.getAgentMessages(chat);

      return messages[messages.length - 1] ?? null;
    },
    getLatestVistiorMessage(chat, excludeForms) {
      let messages = this.getVisitorMessages(chat, excludeForms);

      return messages[messages.length - 1] ?? null;
    },
    getOldestMessage(chat) {
      return this.getMessages(chat)[0] ?? null;
    },
    getOldestAgentMessage(chat) {
      return this.getAgentMessages(chat)[0] ?? null;
    },
    getOldestVisitorMessage(chat, excludeForms) {
      return this.getVisitorMessages(chat, excludeForms)[0] ?? null;
    },
    checkIfChatIsIncoming(chat, threadData) {
      const agents = useAgentsStore();

      let messages = threadData.events;

      // We'll map only what we need
      messages.forEach((event, index) => {
        event.created_at = DateTime.fromISO(event.created_at);

        // Check if message author is any of our agents
        let agent = agents.getAgentByLivechatId(event.author_id);

        event.author_is_agent = agent ? true : false;
      });

      let hasAgentReply = messages.filter(function(event) {
        return event.author_is_agent;
      }).length > 0;

      // If agent message is the only message sent then it could a greeting message
      if (messages.length === 1 && hasAgentReply) return true;

      let firstMessage = messages[0];
      let secondMessage = messages[1];

      // If the first and second message was sent at the same time then this was likely an automatic greeting
      // and we still cound the chat as incoming because an agent doesn't know that they've sent a greeting message
      if (firstMessage && secondMessage && secondMessage.created_at.diff(firstMessage.created_at).as('milliseconds') < 50) {
        // If the first and second messages were from different parties then it's an automatic greeting for sure
        if (
          (firstMessage.author_is_agent && !secondMessage.author_is_agent)
          || (!firstMessage.author_is_agent && secondMessage.author_is_agent)
        ) {
          return true;
        }
      }

      // Check no agent has replied then the chat is considered incoming
      return !hasAgentReply;
    },
    async sendGoogleAnalyticsEvent(chat, client) {
      const toast = useToast();

      if (!client.ga_event_tracking_enabled) return false;

      var livechatVisitorId = chat.visitor.id;
      var trackerName = 'helpflow_' + livechatVisitorId;

      try {
        ga('create', {
          trackingId: client.ga_property_id,
          cookieDomain: 'auto',
          name: trackerName,
          userId: livechatVisitorId,
        });

        ga(trackerName + '.send', {
          hitType: 'event',
          eventCategory: client.ga_event_category,
          eventAction: client.ga_event_action,
          eventLabel: client.ga_event_label,
          eventValue: client.ga_event_value,
        });

        await axios.patch('/api/v2/chats/' + chat.id + '/mark-ga-event-sent').then(function (response) {
          chat.ga_event_sent = response.data.ga_event_sent;

          toast.googleAnalyticsEventLogged(client.ga_event_label);
        });
      } catch (error) {
        toast.googleAnalyticsEventLogFailed(client.ga_event_label);

        console.error(error);
      }
    },
    sendTypingIndicator(chatId) {
      // We should treat chatId as an optional parameter
      if (!chatId) return false;

      // Send typing indicators no more than once per second
      if (this.typingIndicatorSentAt && DateTime.now().diff(this.typingIndicatorSentAt).as('milliseconds') < 1000) {
        return false;
      }

      this.livechatApi.sendTypingIndicator(chatId);

      this.typingIndicatorSentAt = DateTime.now();
    },
    async sendMessage(chat, data) {
      const agents = useAgentsStore();
      const toast = useToast();
      const self = this;

      if (data.livechat_file_url) {
        // Send as LiveChat file message
        await this.livechatApi.sendFileMessage(data).catch(function (error) {
          // Check if it's a real error
          if (self.objectPath.has(error, 'payload.error.message')) {
            toast.failedToSendMessage(error.payload.error.message);
          }
        });

        return true;
      }

      // Prevent sending empty messages
      if (data.message === '' || data.message === null) return false;

      // Send a regular text message
      await this.livechatApi.sendPlainTextMessage(data).catch(async function (error) {
        // Check if it's a real error
        if (self.objectPath.has(error, 'payload.error.message')) {
          // Bring back the message that failed to send
          self.setMessageDraft(chat, data.message);

          toast.failedToSendMessage(error.payload.error.message);
        }
      });
    },
    // Set auth agent's reaction to the visitor's message
    async setMessageReaction(chat, event, messageReaction) {
      const agents = useAgentsStore();

      let agentId = agents.agent.livechat_id;

      await this
        .livechatApi
        .updateAgentReactionToEvent(chat.id, event.thread_id, event.id, agentId, messageReaction)
        .catch(function (error) {
          console.error(error);
        });
    },
    async getAgentsForChatTransfer(chat) {
      console.debug('Listing agents for chat transfer...');

      const agents = useAgentsStore();

      let availableAgents;

      await this.livechatApi.getAgentsForChatTransfer(chat.id).then(function (response) {
        availableAgents = response;
      });

      // We'll remove auth agent because we cannot transfer chats to ourselves
      availableAgents = availableAgents.filter(function(item) {
        return item.agent_id !== agents.agent.livechat_id;
      });

      return availableAgents;
    },
    async transferChat(chat, toAgentLivechatId) {
      const agents = useAgentsStore();
      const toast = useToast();
      const self = this;

      let chatTransferFailed = false;

      // Transfer chat via LiveChat API
      await this.livechatApi.transferChat(chat.id, toAgentLivechatId).catch(function (error) {
        // This is likely a fake error caused by LiveChat ChatSDK, let's check if it's a real error
        if (self.objectPath.has(error, 'payload.error.message')) {
          chatTransferFailed = true;

          console.error(error);

          Bugsnag.notify(error);
        }
      });

      if (chatTransferFailed) {
        toast.failedToTransferChat(chat.current_thread_id);
        return false;
      }

      toast.chatTransferred(chat.current_thread_id, toAgentLivechatId);

      // Remove the chat tab
      self.closeChat(chat);

      let newAgent = agents.getAgentByLivechatId(toAgentLivechatId);

      // Mark chat as assigned to new agent on HF backend (in case agent doesn't use HAS for some reason)
      if (newAgent) this.markChatThreadAsAssignedToAgent(chat.current_thread_id, newAgent.id);
    },
    setChatStatus(chat, status) {
      if (chat.status === 'supervising') return false;

      if (chat.status !== status) {
        chat.status = status;

        if (!this.isProduction) console.debug('Marked chat #' +  chat.id + ' as ' + status);
      }
    },
    // Remove chats that are loading for longer than 25 seconds and reload them
    killHangingLoadingChats() {
      let chats = this.getLoadingChats();

      let killedChatsCount = 0;

      chats.forEach((chat) => {
        let loadingTime = chat.loading_started_at ? DateTime.now().diff(chat.loading_started_at).as('seconds') : 0;

        if (loadingTime >= 25) {
          console.debug('Chat failed to load for some reason (loading step: ' + chat.loading_step + ' / took ' + loadingTime.toFixed(1) + 's).');

          Bugsnag.notify(
            new Error('Chat failed to load for some reason (loading step: ' + chat.loading_step + ' / took ' + loadingTime.toFixed(1) + 's).'),
            function (event) {
              event.severity = 'warning';
            }
          );

          this.removeChat(chat.id);

          killedChatsCount++;
        }
      });

      if (killedChatsCount) this.syncMissingChatsAndMessages();
    },
    setMessageDraft(chat, message) {
      chat.message_draft = message === null || typeof message === 'undefined' ? '' : message;
    },
    setChatThreadCreatedAt(chat, threadId, threadCreatedAt) {
      this.objectPath.set(chat, 'threads.' + threadId + '.created_at', threadCreatedAt);
    },
    clearSneakPeek(chat) {
      chat.visitor_message_sneak_peek = null;
      chat.visitor_message_sneak_peek_time = null;
    },
    toggleImportantStatus(id) {
      const toast = useToast();

      let chat = this.getChat(id);

      if (!chat) return false;

      if (chat.is_important) {
        // Mark as not important
        axios.patch('/api/v2/threads/' + chat.current_thread_id + '/mark-not-important').then(function (response) {
          chat.is_important = response.data.is_important;

          toast.chatMarkedAsNotImportant();
        });
      } else {
        // Mark as important
        axios.patch('/api/v2/threads/' + chat.current_thread_id + '/mark-important').then(function (response) {
          chat.is_important = response.data.is_important;

          toast.chatMarkedAsImportant();
        });
      }
    },
    async banVisitor(chat, duration, reason) {
      const clients = useClientsStore();
      const toast = useToast();

      let client = clients.getClientByCode(chat.client_code);

      if (!client) {
        toast.failedToBanVisitor(chat.client_code + ' client not found.');
      }

      await axios.post('/api/v2/visitors/' + chat.visitor.id + '/ban', {
        livechat_thread_id: chat.current_thread_id,
        client_id: client.id,
        reason: reason,
        ip: chat.visitor.last_visit.ip,
        days: duration,
      }).then(function (response) {
        toast.visitorBanned();
      }).catch(function (error) {
        console.error(error);

        toast.failedToBanVisitor();
      });
    },
    async syncThreadProperties(chat, threadId, skipCopilot) {
      const agents = useAgentsStore();
      const copilot = useCopilot();
      const self = this;

      console.debug('Syncing thread properties and Copilot history for chat #' + chat.id + ' thread #' + threadId + '...');

      // Sync chat properties
      await axios.get('/api/v2/threads/' + threadId + '/properties').then(function (response) {
        chat.is_important = response.data.is_important;
        chat.ga_event_sent = response.data.ga_event_sent;
        chat.rto_sent = response.data.rto_sent;

        // If some other agent is currently assigned to the chat then it means that the chat was transferred away,
        // likely due to auth agent being offline for some time, so we need to mark chat as transferred away
        if (
          chat.current_thread_id === threadId
          && !chat.is_transferred
          && chat.status !== 'supervising'
          && response.data.assigned_to_agent_id !== null
          && response.data.assigned_to_agent_id !== agents.agent.id
        ) {
          self.markChatAsDeactivated(chat, true);

          // We need to collect more data so we can resolve this issue
          Bugsnag.notify(
            new Error('Chat thread for some reason is not assigned to the agent (agent_id: ' + agents.agent.id + ' / assigned_agent_id: ' + response.data.assigned_to_agent_id + ' / thread_id: ' + threadId + ').'),
            function (event) {
              event.severity = 'warning';
              event.unhandled = true;
            }
          );
        }

        console.debug('Thread properties for chat #' + chat.id + ' thread #' + threadId + ' have been synced.');
      });

      if (!skipCopilot) {
        // Sync Copilot requests history
        await axios.get('/api/v2/copilot/history/' + threadId).then(function (response) {
          copilot.setRequestsHistoryForThread(threadId, response.data);

          console.debug('Copilot history for chat #' + chat.id + ' thread #' + threadId + ' has been synced.');
        });
      }
    },
    // Mark chat thread as assigned to the specified agent for HF backend
    async markChatThreadAsAssignedToAgent(threadId, agentId, onlyIfUnassigned) {
      const agents = useAgentsStore();
      const self = this;

      let agent = agents.getAgent(agentId);
      let chat = this.getChatByCurrentThreadId(threadId);

      // We cannot assign a chat to auth agent that's supervised by auth agent
      if (chat && chat.status === 'supervising' && agents.agent.livechat_id === agentId) {
        console.debug('Cannot mark thread #' + threadId + ' as assigned to self because chat is being supervised');

        return false;
      }

      await axios.patch('/api/v2/threads/' + threadId + '/mark-assigned-to-agent/' + agentId, {
        'only_if_unassigned': onlyIfUnassigned === true,
      }, { retry: 15 }).then(function (response) {
        if (agent) {
          if (onlyIfUnassigned === true) {
            console.debug('Marked thread #' + threadId + ' as assigned to ' + agent.livechat_id + ' (only if it was unassigned)');
          } else {
            console.debug('Marked thread #' + threadId + ' as assigned to ' + agent.livechat_id);
          }
        }
      }).catch(function (error) {
        console.error(error);

        Bugsnag.notify(error);
      });
    },
    async assignToSelf(chat) {
      const agents = useAgentsStore();
      const self = this;
      const toast = useToast();

      await this.livechatApi.addAgentToChat(chat.id, agents.agent.livechat_id).catch(function (error) {
        // This is likely a fake error caused by LiveChat ChatSDK, let's check if it's a real error
        if (self.objectPath.has(error, 'payload.error.message')) {
          console.error(error);

          toast.error(error.payload.error.message);
        }
      });

      await this.markChatThreadAsAssignedToAgent(chat.current_thread_id, agents.agent.id);
    },
    async handleChatSupervisingStartedOnLiveChat(chatId) {
      const agents = useAgentsStore();

      await this.livechatApi.addAgentToChat(chatId, agents.agent.livechat_id, true);

      setTimeout(async() => {
        // We need to re-load chat properties and find if other agents are supervising the chat
        let supervisedByAgentIds = await this.getChatSupervisingAgentIds(chatId);

        // Add auth agent to list of supervisors
        if (!supervisedByAgentIds.includes(agents.agent.livechat_id)) supervisedByAgentIds.push(agents.agent.livechat_id);

        await this.livechatApi.updateChatSupervisors(chatId, supervisedByAgentIds.join(','));
      }, 3000);
    },
    async superviseChat(chatId) {
      console.debug('Trying to start supervising chat #' + chatId);

      const agents = useAgentsStore();
      const toast = useToast();

      let chatData = await this.livechatApi.getChat(chatId);

      if (this.objectPath.get(chatData, 'thread.active', false) === false) {
        toast.error('Cannot supervise chat because it has been archived.');

        throw new Error('Cannot supervise chat because it has been archived.');
      }

      // We need to load fresh chat properties and find if other agents are supervising the chat
      let supervisedByAgentIds = convertCommaSeparatedStringToArray(this.objectPath.get(chatData, 'properties.supervising.agent_ids', ''));

      if (!supervisedByAgentIds.includes(agents.agent.livechat_id)) supervisedByAgentIds.push(agents.agent.livechat_id);

      // Add auth agent to list of supervisors to make chat supervised
      await this.livechatApi.updateChatSupervisors(chatId, supervisedByAgentIds.join(','));

      console.debug('Added self to list of supervisors for chat #' + chatId);

      // Add auth agent as a chat user to allow sending private messages in the chat
      await this.livechatApi.addAgentToChat(chatId, agents.agent.livechat_id, true);

      console.debug('Added self to list of chat users for chat #' + chatId);
    },
    removeChat(chatId) {
      this.chats = this.chats.filter(function(chat) {
        return chat.id != chatId;
      });
    },
    getChatDeactivatedAt(chat) {
      if (chat && chat.is_deactivated) {
        let latestEvent = this.getLatestEvent(chat);

        // We need to stop the total chat timer for deactivated chats
        if (latestEvent) return latestEvent.created_at;
      }

      return null;
    },
    chatTimerDiffFormatted(chat, from, to, now) {
      // If "to" is empty it means we want to know total chat time
      if (!to) {
        to = DateTime.now();

        let deactivatedAt = this.getChatDeactivatedAt(chat);

        // We need to stop the total chat timer for deactivated chats
        if (deactivatedAt) to = deactivatedAt;
      }

      // We should not allow negative values because
      // in some cases agent's clock on local machine can be off by a few seconds
      if (from && to && DateTime.now().diff(from).as('seconds') >= 0) {
        return formatLuxonChatTimerDuration(to.diff(from));
      }

      return '00:00:00';
    },
    chatHoldTimerDiffFormatted(chat, now) {
      if (!chat || !this.isOnHold(chat)) return '00:00';

      // We need to display the timer in UI in multiple places so we need to make sure the time is the same everywhere
      now = DateTime.fromMillis(now);

      return formatLuxonChatTimerDuration(chat.on_hold_until.diff(now), true);
    },
    flagForHelp(chat) {
      const toast = useToast();

      axios.post(`/api/chat-alerts/${chat.client_code}/manual`, {
        chat_id: chat.current_thread_id
      }).then(function (response) {
        toast.chatFlaggedForHelp();
      }).catch(function (error) {
        console.error(error);
      });
    },
    sendChatTranscript(chat, threadId, email, excludeFullDetails) {
      const toast = useToast();

      axios.post(`/api/v2/send-chat-transcript/${threadId}`, {
        email: email,
        exclude_full_details: excludeFullDetails,
        timezone: chat.visitor.timezone,
      }).then(function (response) {
        toast.chatTranscriptSent();
      }).catch(function (error) {
        toast.failedToSendChatTranscript();

        console.error(error);
      });
    },
    async getSupervisableChats() {
      const agents = useAgentsStore();

      // Amount of chat pages to load, we need the most amount of chats here
      let pages = this.isProduction ? 3 : 1;

      // Get up to 300 latest chat summaries of the chats auth agent has access to,
      // however, do note that agent may not be the one who handled the chat,
      // so we will need to determine chats that should be considered active for auth agent
      let chatsPageOne = await this.livechatApi.getSupervisableChats();
      let chatsPageTwo = { chats_summary: [] };
      let chatsPageThree = { chats_summary: [] };

      if (pages >= 2 && chatsPageOne.next_page_id) {
        chatsPageTwo = await this.livechatApi.getSupervisableChats(chatsPageOne.next_page_id);
      }

      if (pages >= 3 && chatsPageTwo.next_page_id) {
        chatsPageThree = await this.livechatApi.getSupervisableChats(chatsPageTwo.next_page_id);
      }

      let chatSummaries = chatsPageOne.chats_summary.concat(chatsPageTwo.chats_summary).concat(chatsPageThree.chats_summary);

      let activeThreadIds = [];

      let activeChatIds = this.getActiveChatIds(false);

      chatSummaries.forEach((data) => {
        // We won't load currently active chats assigned to auth agent
        if (activeChatIds.includes(data.id)) return;

        // We won't load inactive chats
        if (this.objectPath.get(data, 'last_thread_summary.active', false) === false) return;

        // We won't load queued chats
        if (this.objectPath.has(data, 'last_thread_summary.queue.position')) return;

        // We won't load unassigned chats
        if (this.objectPath.get(data, 'last_thread_summary.properties.routing.unassigned', false)) return;

        let chattingAgent = this.getChattingAgentFromChatSummary(data);

        // We won't load chats where no agent is chatting currently
        if (!chattingAgent) return;

        activeThreadIds.push(data.last_thread_summary.id);
      });

      // Get only chat summaries with active chat threads
      return chatSummaries.filter((chat) => activeThreadIds.includes(chat.last_thread_summary.id));
    },
    putOnHold(chat, minutes) {
      if (!chat) return false;

      // By default we'll put chat on hold for 3 minutes
      minutes = typeof minutes === 'undefined' ? 3 : minutes;

      // If the chat is already on hold, we'll reset the timer and set a new one
      chat.on_hold_until = DateTime.now().plus({ minutes: minutes });
    },
    cancelHold(chat) {
      if (chat) delete chat.on_hold_until;
    },
    isOnHold(chat) {
      if (!chat) return false;

      let diff = this.holdTimeLeftInSeconds(chat);

      // If chat was on hold and now it no longer is then we need to cancel hold timer
      if (diff <= 0) this.cancelHold(chat);

      return diff > 0;
    },
    holdTimeLeftInSeconds(chat, now) {
      if (chat && chat.on_hold_until) {
        let diff = parseInt(chat.on_hold_until.diff(DateTime.now()).as('seconds').toFixed());

        if (diff >= 1) return diff;
      }

      return 0;
    },
    // Runs every second
    handlePendingNotificationsTick() {
      const audio = useAudioStore();
      const self = this;

      let now = DateTime.now();

      // This can include supervised and incoming chats, so we'll need to apply filters later on
      let loadedOngoingChats = this.getLoadedOngoingChats();

      // We'll also save chat IDs in order to not send duplicate notifications,
      // e.g. when incoming chat also has a new unread messages

      // We'll send out a sound notification if chat is incoming every 10 seconds until agent opens the chat tab
      let incomingChatsToBeNotified = loadedOngoingChats.filter(function(chat) {
        if (chat.status !== 'incoming') return false;
        if (!chat.loaded_at) return false;

        // Must be an integer value
        let currentThreadCreatedAtDiffInSeconds = parseInt(now.diff(chat.loaded_at).as('seconds').toFixed());

        // We need to play the audio notification every 10 seconds starting on 20th second
        return currentThreadCreatedAtDiffInSeconds > 10 && currentThreadCreatedAtDiffInSeconds % 10 === 0;
      });

      // We'll send out a sound notification if the total time since the last unread message from the visitor
      // is more than 15 seconds, every 15 seconds until agent reads that message
      let chatsWithUnreadMessagesToBeNotified = loadedOngoingChats.filter(function(chat) {
        if (chat.status !== 'ongoing') return false;

        let unreadMessages = self.getUnreadMessages(chat);

        if (unreadMessages.length === 0) return false;

        // Must be an integer value
        let firstUnreadMessageCreatedAtDiffInSeconds = parseInt(now.diff(unreadMessages[0].created_at).as('seconds').toFixed());

        // We need to play the audio notification every 15 seconds starting on 30th second
        return firstUnreadMessageCreatedAtDiffInSeconds > 15 && firstUnreadMessageCreatedAtDiffInSeconds % 15 === 0;
      });

      // We'll send out a sound notification if chat hold timer has exactly 30s left
      let chatsOnHoldToBeNotified = loadedOngoingChats.filter(function(chat) {
        return self.holdTimeLeftInSeconds(chat) === 30;
      });

      // We don't want to play multiple sounds at the same time,
      // so we'll track how many sounds we need to play during this tick (1 tick = 1 second)

      // Play a sound notification, but only once, even if there are multiple chats on hold
      if (chatsOnHoldToBeNotified.length) audio.play('bell-notification');

      // Play a sound notification, but only once, even if there are multiple incoming chats
      if (incomingChatsToBeNotified.length) audio.play('new-chat');

      // Play a sound notification, but only once, even if there are multiple chats with unread messages
      if (chatsWithUnreadMessagesToBeNotified.length) audio.play('new-message');
    },
    checkIfAgentHasToSendRTO(chat) {
      const tags = useTagsStore();

      // Don't need to check if RTO has been sent already
      if (chat.rto_sent) return false;

      let tagList = tags.getTagsForChatThread(chat, chat.current_thread_id);

      // One of these tags must be already present in chat in order for us to determine that chat must be sent via RTO
      return tagList.find(tag => tag.title === tags.rtoSalesTag || tag.title === tags.rtoSupportTag);
    },
    getChattingAgentFromChatSummary(chatData) {
      const agents = useAgentsStore();

      let presentAgents = this.objectPath.get(chatData, 'users', []).filter((user) => user.type === 'agent' && user.present === true);
      let supervisedByAgentIds = convertCommaSeparatedStringToArray(this.objectPath.get(chatData, 'properties.supervising.agent_ids', ''));
      let chattingAgents = presentAgents.filter((user) => user.visibility === 'all' && !supervisedByAgentIds.includes(user.id));

      return chattingAgents.length ? agents.getAgentByLivechatId(chattingAgents[0].id) : null;
    },
    getVisitorUserFromChatSummary(chatData) {
      let visitors = this.objectPath.get(chatData, 'users', []).filter((user) => user.type === 'customer');

      return visitors.length ? visitors[0] : null;
    },
    getVisitorGeolocation(chat) {
      if (chat.visitor && chat.visitor.is_loaded && chat.visitor.last_visit && chat.visitor.last_visit.geolocation) {
        return chat.visitor.last_visit.geolocation;
      }

      return {};
    },
    visitorIsFromGDPRCountry(chat) {
      const GDPR_COUNTRY_CODE_LIST = [
        'AT', // Austria
        'BE', // Belgium
        'BG', // Bulgaria
        'CH', // Switzerland
        'CY', // Cyprus
        'CZ', // Czechia
        'DE', // Germany
        'DK', // Denmark
        'EE', // Estonia
        'ES', // Spain
        'FI', // Finland
        'FR', // France
        'GB', // United Kingdom of Great Britain and Northern Ireland
        'GR', // Greece
        'HR', // Croatia
        'HU', // Hungary
        'IE', // Ireland
        'IS', // Iceland
        'IT', // Italy
        'LI', // Liechtenstein
        'LT', // Lithuania
        'LU', // Luxembourg
        'LV', // Latvia
        'MT', // Malta
        'NL', // Netherlands
        'NO', // Norway
        'PL', // Poland
        'PT', // Portugal
        'RO', // Romania
        'SE', // Sweden
        'SI', // Slovenia
        'SK', // Slovakia
      ];

      let visitorGeolocation = this.getVisitorGeolocation(chat);

      if (visitorGeolocation && visitorGeolocation.country_code) {
        let visitorCountryCode = visitorGeolocation.country_code.toUpperCase();

        return GDPR_COUNTRY_CODE_LIST.includes(visitorCountryCode);
      }

      return false;
    },
    getVisitorLocationFormatted(chat, showGDPRLabel) {
      let visitorGeolocation = this.getVisitorGeolocation(chat);

      if (!visitorGeolocation) return 'N/A';

      let location = '';

      if (visitorGeolocation.city) location += visitorGeolocation.city + ', ';

      if (visitorGeolocation.region) location += visitorGeolocation.region + ', ';

      if (visitorGeolocation.country) location += visitorGeolocation.country + ', ';

      // Remove ", " from the end (if present)
      location = location.replace(/\,\ $/, '');

      if (!location) return 'N/A';

      if (showGDPRLabel && this.visitorIsFromGDPRCountry(chat)) location += ' (GDPR)';

      return location;
    },
    getVisitorCountryName(chat) {
      let visitorGeolocation = this.getVisitorGeolocation(chat);

      if (visitorGeolocation && visitorGeolocation.country) return visitorGeolocation.country;

      return 'Unknown';
    },
    getVisitorCountryCode(chat) {
      let visitorGeolocation = this.getVisitorGeolocation(chat);

      if (visitorGeolocation && visitorGeolocation.country_code) return visitorGeolocation.country_code;

      return null;
    },
    broadcastChatSwitchedMessage(chat) {
      let chatSwitchedMessage = {
        client_code: chat.client_code,
        current_thread_id: chat.current_thread_id,
      };

      new BroadcastChannel('faq_search_switch_chat').postMessage(chatSwitchedMessage);

      if (!this.isProduction) console.debug('[BroadcastChannel:faq_search_switch_chat]', chatSwitchedMessage);
    }
  },

  // computed
  getters: {
    chatIds(state) {
      return state.chats.map(chat => chat.id);
    },
    activeChatIds(state) {
      return state.chats.filter(function(chat) {
        return chat.is_loaded;
      }).map(chat => chat.id);
    },
    activeChat(state) {
      let chat = state.chats.find(chat => state.route.name === 'chat' && state.route.params.id == chat.id);

      if (!chat) return null;

      return chat;
    },
    activeChatId(state) {
      return this.activeChat ? this.activeChat.id : null;
    },
    activeChatVisitor(state) {
      return this.activeChat ? this.activeChat.visitor : null;
    },
    activeChatVisitorIsLoaded(state) {
      return this.activeChatVisitor ? this.activeChatVisitor.is_loaded : null;
    },
    activeChatCurrentThreadId(state) {
      return this.activeChat ? this.activeChat.current_thread_id : null;
    },
    activeChatMessageDraft(state) {
      return this.activeChat ? this.activeChat.message_draft : null;
    },
    activeChatSelectedFilesCount(state) {
      return this.activeChat && this.activeChat.selected_files_count ? this.activeChat.selected_files_count : 0;
    },
    activeChatCurrentThread(state) {
      if (this.activeChat && this.activeChat.threads[this.activeChat.current_thread_id]) {
        return this.activeChat.threads[this.activeChatCurrentThreadId];
      }

      return null;
    },
    activeChatIsLoaded(state) {
      return this.activeChat ? this.activeChat.is_loaded === true : false;
    },
    totalUnreadMessagesCount(state) {
      return this.chats.reduce((accumulator, chat) => {
        return accumulator + this.getUnreadMessagesCount(chat);
      }, 0);
    },
  },
});

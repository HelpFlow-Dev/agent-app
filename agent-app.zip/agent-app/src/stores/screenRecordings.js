import { defineStore } from 'pinia';
import { DateTime } from 'luxon';
import { useAgentsStore } from '@/stores/agents';
import { useAudioStore } from '@/stores/audio';
import { useToast } from '@/stores/toasts';
import { downloadBlob } from '@/helpers';
import axios from 'axios';
import Bugsnag from '@bugsnag/js';

export const useScreenRecordingsStore = defineStore('screenRecordings', {
  // data
  state: () => ({
    recordings: [], // All queued recordings are stored here
    uploadedRecordingsCount: 0,

    // Shows if any of the screens are currently being recorded
    recordingInProgress: false,

    // Shows when we started recording any screen
    recordingStartedAt: null,

    // Shows when we've sent the last notification to Slack about agent not recording their screen
    screenNotRecordingNotificationSentAt: null,

    // Minimum valid recording duration for uploading (in seconds), otherwise it will be discarded
    minDuration: 8, // smaller duration can result in a black screen

    // Options for getDisplayMedia() method — HD+ resolution at 3 FPS (takes up to ~3.5MB per minute)
    displayMediaOptions: {
      video: {
        cursor: 'always',
        displaySurface: 'monitor',
        frameRate: 3,
        height: 900, // Browser will always try to set this this specific height for the video
        resizeMode: 'crop-and-scale',
      },
      audio: false,
    },
    // Options for MediaRecorder
    recorderOptions: {
      mimeType: 'video/webm;codecs=vp9',
      videoBitsPerSecond: 1200000, // 1.2 Mbps
    },
  }),

  // methods
  actions: {
    queue(recording) {
      this.recordings.push(recording);
    },
    uploadRecordings() {
      this.queuedRecordings.forEach(async (recording) => {
        await this.uploadRecording(recording);
      });
    },
    removeRecording(recordingId) {
      this.recordings = this.recordings.filter((item) => item.id !== recordingId);
    },
    async uploadRecording(recording) {
      const toast = useToast();
      const self = this;

      if (recording.uploaded || recording.uploading) return;

      recording.uploading = true;

      // Convert to UTC and format to SQL DATETIME
      let startedAtFormatted = recording.startedAt.setZone('UTC').toFormat('yyyy-MM-dd HH:mm:ss');
      let enededAtFormatted = recording.endedAt.setZone('UTC').toFormat('yyyy-MM-dd HH:mm:ss');

      let formData = new FormData();

      formData.append('file', recording.file);
      formData.append('screen_id', recording.screenId);
      formData.append('started_at', startedAtFormatted);
      formData.append('ended_at', enededAtFormatted);

      await axios
        .post('/api/v2/screen-recordings', formData, {
          headers: { 'Content-Type': 'multipart/form-data' },
        })
        .then(function (response) {
          // Mark recording as uploaded
          recording.uploading = false;
          recording.uploaded = true;

          // Remove recording from upload queue
          self.removeRecording(recording.id);

          // Increase total uploaded recordings count
          self.uploadedRecordingsCount++;

          console.debug('Screen recording uploaded:', response.data);
        })
        .catch(function (error) {
          // Release recording back to the upload queue
          recording.uploading = false;

          if (self.objectPath.has(error, 'response.data')) console.error(error.response.data);

          // If it's a Laravel validation error, we'll get the first validation message
          if (self.objectPath.has(error, 'response.data.errors') && self.objectPath.has(error, 'response.data.message')) {
            toast.screenRecordingUploadFailed(recording.id, error.response.data.message);
          }

          Bugsnag.notify(error);
        });
    },
    downloadRecording(recordingId) {
      let recording = this.recordings.find(recording => recording.id == recordingId) ?? null;

      if (!recording) return false;

      // Convert to UTC and format to SQL DATETIME
      let startedAtFormatted = recording.startedAt.setZone('UTC').toFormat('yyyy_MM_dd_HH_mm_ss');
      let enededAtFormatted = recording.endedAt.setZone('UTC').toFormat('yyyy_MM_dd_HH_mm_ss');

      let filename = startedAtFormatted + '-' + enededAtFormatted + '-screen_' + recording.screenId + '.webm';

      downloadBlob(recording.file, filename);
    },
    checkIfRecordingInProgressWhenAcceptingChats() {
      const agents = useAgentsStore();
      const audio = useAudioStore();

      // If auth agent's status is not accepting then all is OK
      if (agents.currentStatusId !== agents.acceptingStatusId) return;

      // If auth agent is already recording any screen then all is OK
      if (this.recordingInProgress) return;

      // Notify agent to start screen recording
      audio.play('start-screen-recording');

      // We don't want to actually notify the managers until after at least 2 minutes of agent not recording the screen have passed
      if (agents.acceptingStatusSetAt && DateTime.now().diff(agents.acceptingStatusSetAt).as('seconds') >= 119) {
        // We have to check that notification was sent at least one minute ago
        if (!this.screenNotRecordingNotificationSentAt || DateTime.now().diff(this.screenNotRecordingNotificationSentAt).as('seconds') >= 59) {
          this.sendScreenNotRecordingNotificationToManagers();
        }
      }
    },
    async sendScreenNotRecordingNotificationToManagers() {
      const self = this;

      // We'll mark notification as sent, even if the following request fails,
      // because if agent is offline and comes back online we can have a situation where this notification would be sent,
      // even though agent has been recording the screen for a few minutes already
      self.screenNotRecordingNotificationSentAt = DateTime.now();

      await axios.get('/api/v2/screen-recording-not-used', { timeout: 20000 });
    },
  },

  // computed
  getters: {
    queuedRecordings(state) {
      return state.recordings.filter(function(recording) {
        return !recording.uploaded;
      });
    },
    queuedRecordingsCount(state) {
      return this.queuedRecordings.length;
    },
    recordingsCount(state) {
      return this.queuedRecordingsCount + state.uploadedRecordingsCount;
    },
  },
});

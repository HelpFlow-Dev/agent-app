import { defineStore } from 'pinia';
import { useToast } from '@/stores/toasts';
import axios from 'axios';

export const useCannedResponsesStore = defineStore('cannedResponses', {
  // data
  state: () => ({
    cannedResponses: {},
  }),

  // methods
  actions: {
    async load() {
      const self = this;

      if (!this.isProduction) console.debug('Loading canned responses...');

      await axios.get('/api/v2/canned-responses').then(function (response) {
        self.cannedResponses = response.data;

        if (!self.isProduction) console.debug('Canned responses loaded:', response.data);
      });
    },
    async store(data) {
      if (!this.isProduction) console.debug('Saving canned response...', data);

      const self = this;
      const toast = useToast();

      await axios.post('/api/v2/canned-responses', data).then(function (response) {
        toast.cannedResponseSaved();
      }).catch(function (error) {
        toast.failedToSaveCannedResponse();

        console.error(error);
      });

      // Reload canned responses
      await self.load();
    },
    getCannedResponse(id) {
      return this.cannedResponses.find(cannedResponse => cannedResponse.id == id) ?? null;
    },
    getFilteredShortcuts(searchTerm, clientId) {
      let cannedResponses = this.filterCannedResponsesForClient(this.cannedResponses, clientId);

      cannedResponses = this.transformCannedResponses(cannedResponses);

      if (searchTerm) {
        return Object.fromEntries(
          Object.entries(cannedResponses).filter(
            ([key]) => key.toLowerCase().includes(searchTerm.toLowerCase())
          )
        );
      }

      return cannedResponses;
    },
    getCannedResponsesForShortcut(shortcut, clientId) {
      let cannedResponses = this.cannedResponses;

      if (clientId) {
        cannedResponses = cannedResponses.filter((cannedResponse) => cannedResponse.client_id === null || cannedResponse.client_id === clientId);
      }

      cannedResponses = this.transformCannedResponses(cannedResponses);

      return cannedResponses[shortcut] ?? [];
    },
    transformCannedResponses(cannedResponses) {
      let results = {};

      for (let i = 0; i < cannedResponses.length; i++) {
        let cannedResponse = cannedResponses[i];

        for (let j = 0; j < cannedResponse.shortcuts.length; j++) {
          let shortcut = cannedResponse.shortcuts[j].shortcut;

          (results[shortcut] ??= []).push(cannedResponse);
        }
      }

      // Sort shortcuts alphabetically asc
      results = Object.keys(results).sort(function (a, b) {
        return a.toLowerCase().localeCompare(b.toLowerCase());
      }).reduce(
        (obj, key) => {
          obj[key] = results[key];
          return obj;
        },
        {}
      );

      return results;
    },
    filterCannedResponsesForClient(cannedResponses, clientId) {
      if (clientId) {
        return cannedResponses.filter((cannedResponse) => cannedResponse.client_id === null || cannedResponse.client_id === clientId);
      }

      return cannedResponses;
    },
  },

  // computed
  getters: {
    //
  },
});

import { default as LiveChatSDK } from '@livechat/chat-sdk';
import { detectAppEnvironment, livechatClientId } from '@/helpers';
import { DateTime } from 'luxon';

const livechatApi = new LiveChatSDK({ apiVersion: 'v3.5', region: 'america', debug: true });

livechatApi.isConnected = function() {
  return livechatApi._checkRtmConnection() && livechatApi._AGENT_API_RTM.isConnected;
}

// Response must be retunred in <20s, otherwise an error will be thrown
livechatApi.getLatestChats = function(pageId) {
  let payload = { limit: 100 };

  if (typeof pageId !== 'undefined') {
    payload = { page_id: pageId };
  }

  return livechatApi.methodFactory({
    action: 'list_chats',
    payload: payload,
  });
}

// Response must be retunred in <20s, otherwise an error will be thrown
livechatApi.getSupervisableChats = function(pageId) {
  let payload = {
    limit: 100,
    filters: {
      include_active: true,
      include_chats_without_threads: false,
    }
  };

  if (typeof pageId !== 'undefined') {
    payload = { page_id: pageId };
  }

  return livechatApi.methodFactory({
    action: 'list_chats',
    payload: payload,
  });
}

livechatApi.getChat = function(chatId) {
  return livechatApi.methodFactory({
    action: 'get_chat',
    payload: {
      chat_id: chatId,
    },
  });
}

livechatApi.getLatestChatThread = function(chatId) {
  return livechatApi.getLatestChatThreads(chatId, 1).then(data => {
    return data.threads.length ? data.threads[0] : null;
  });
}

livechatApi.getLatestChatThreads = function(chatId, amount) {
  return livechatApi.methodFactory({
    action: 'list_threads',
    payload: {
      chat_id: chatId,
      limit: typeof amount !== 'undefined' ? amount : 2, // from 1 to 100
    },
  });
}

livechatApi.getAgentsForChatTransfer = function(chatId) {
  return livechatApi.methodFactory({
    action: 'list_agents_for_transfer',
    payload: {
      chat_id: chatId,
    },
  });
}

livechatApi.getRoutingStatuses = function(agentId) {
  return livechatApi.methodFactory({
    action: 'list_routing_statuses'
  });
}

livechatApi.getAgentRoutingStatus = function(agentId) {
  return livechatApi.methodFactory({
    action: 'list_routing_statuses'
  }).then(data => {
    let agent = data.find(function (item) {
      return item.agent_id === agentId;
    });

    return agent.status;
  });
}

livechatApi.setAgentStatusToAcceptingChats = function(agentId) {
  return livechatApi.methodFactory({
    action: 'set_routing_status',
    payload: {
      status: 'accepting_chats',
      agent_id: agentId,
    },
  });
}

livechatApi.setAgentStatusToNotAcceptingChats = function(agentId) {
  return livechatApi.methodFactory({
    action: 'set_routing_status',
    payload: {
      status: 'not_accepting_chats',
      agent_id: agentId,
    },
  });
}

livechatApi.getVisitor = function(visitorId) {
  return livechatApi.methodFactory({
    action: 'get_customer',
    payload: {
      id: visitorId,
    },
  });
}

livechatApi.banVisitor = function(visitorId, days) {
  return livechatApi.methodFactory({
    action: 'ban_customer',
    payload: {
      id: visitorId,
      ban: {
        days: days,
      },
    },
  });
}

livechatApi.resumeChat = function(chatId, groupId) {
  return livechatApi.methodFactory({
    action: 'resume_chat',
    payload: {
      active: true,
      chat: {
        id: chatId,
        access: {
          group_ids: [ groupId ],
        },
      },
    },
  });
}

livechatApi.transferChat = function(chatId, agentId) {
  return livechatApi.methodFactory({
    action: 'transfer_chat',
    payload: {
      id: chatId,
      target: {
        type: 'agent',
        ids: [ agentId ],
      }
    },
  });
}

livechatApi.deactivateChat = function(chatId) {
  return livechatApi.methodFactory({
    action: 'deactivate_chat',
    payload: {
      id: chatId,
      ignore_requester_presence: true,
    },
  });
}

livechatApi.unfollowChat = function(chatId) {
  return livechatApi.methodFactory({
    action: 'unfollow_chat',
    payload: {
      id: chatId,
    },
  });
}

livechatApi.updateChatSupervisors = function(chatId, updatedAgentIds) {
  return livechatApi.methodFactory({
    action: 'update_chat_properties',
    payload: {
      id: chatId,
      properties: {
        supervising: {
          agent_ids: updatedAgentIds, // comma-separated string of LC agent IDs
        },
      },
    },
  });
}

livechatApi.sendPlainTextMessage = function(data) {
  return livechatApi.methodFactory({
    action: 'send_event',
    payload: {
      chat_id: data.chat_id,
      event: {
        type: 'message',
        text: data.message,
        visibility: data.is_private ? 'agents' : 'all',
        attach_to_last_thread: true,
      },
    },
  });
}

livechatApi.sendFileMessage = function(data) {
  return livechatApi.methodFactory({
    action: 'send_event',
    payload: {
      chat_id: data.chat_id,
      event: {
        type: 'file',
        url: data.livechat_file_url,
        visibility: data.is_private ? 'agents' : 'all',
        attach_to_last_thread: true,
      },
    },
  });
}

livechatApi.markEventsAsSeen = function(chatId, dateTimeString) {
  // We'll use current time by default, however, it's not recommended
  // because user's device time will always be out of sync by a few milliseconds,
  // which can cause a bug like when the date up to which we mark the events as seen we be smaller then the message created_at date
  // which means that the message wasn't actually read
  // so it's always better to use dateTimeString parameter
  let seenUpTo = DateTime.now().setZone('UTC').toFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'999Z'");

  if (dateTimeString) {
    seenUpTo = dateTimeString;
  }

  return livechatApi.methodFactory({
    action: 'mark_events_as_seen',
    payload: {
      chat_id: chatId,
      seen_up_to: seenUpTo,
    },
  });
}

livechatApi.addAgentToChat = function(chatId, agentId, asSupervisor) {
  return livechatApi.methodFactory({
    action: 'add_user_to_chat',
    payload: {
      chat_id: chatId,
      user_id: agentId,
      user_type: 'agent',
      visibility: asSupervisor === true ? 'agents' : 'all',
      ignore_requester_presence: true,
    },
  });
}

livechatApi.removeAgentFromChat = function(chatId, agentId) {
  return livechatApi.methodFactory({
    action: 'remove_user_from_chat',
    payload: {
      chat_id: chatId,
      user_id: agentId,
      user_type: 'agent',
      ignore_requester_presence: true,
    },
  });
}

livechatApi.updateAgentReactionToEvent = function(chatId, threadId, eventId, agentId, messageReaction) {
  let environment = detectAppEnvironment();

  let payload = {
    chat_id: chatId,
    thread_id: threadId,
    event_id: eventId,
    properties: {},
  };

  payload['properties'][livechatClientId] = {
    message_reaction: messageReaction,
    message_reaction_author: agentId,
  };

  return livechatApi.methodFactory({
    action: 'update_event_properties',
    payload: payload,
  });
}

// Typing indicator will be shown for 10 seconds or until we send a message,
// so we need to make sure that we send this at least each second when user types or when we're sending files
livechatApi.sendTypingIndicator = function(chatId, isTyping) {
  // By default we send a push to notify visitor that agent is typing
  isTyping = isTyping === false ? false : true;

  return livechatApi.methodFactory({
    action: 'send_typing_indicator',
    payload: {
      chat_id: chatId,
      is_typing: isTyping,
    },
  });
}

export default livechatApi;

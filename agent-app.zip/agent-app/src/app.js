// Core dependencies
import { createApp, ref } from 'vue';
import { createPinia } from 'pinia';
import { DateTime, Settings as LuxonSettings } from 'luxon';
import { detectAppEnvironment } from '@/helpers';
import { default as LiveChatSDK } from '@livechat/chat-sdk';
import Toast, { POSITION as TOAST_POSITION, TYPE as TOAST_TYPE } from 'vue-toastification';
import axios from 'axios';
import mitt from 'mitt';
import jQuery from 'jquery';
import router from '@/router';
import livechatApi from '@/livechat-api';
import objectPath from 'object-path';
import vClickOutside from 'click-outside-vue3';
import FloatingVue from 'floating-vue';
import Bugsnag from '@bugsnag/js';
import BugsnagPluginVue from '@bugsnag/plugin-vue';
import ToastCloseButtonDanger from '@/components/ToastCloseButtonDanger.vue';
import ToastCloseButtonDefault from '@/components/ToastCloseButtonDefault.vue';
import ToastCloseButtonInfo from '@/components/ToastCloseButtonInfo.vue';
import ToastCloseButtonSuccess from '@/components/ToastCloseButtonSuccess.vue';
import ToastCloseButtonWarning from '@/components/ToastCloseButtonWarning.vue';
import App from './App.vue';

// Styles
import './css/main.css';
import './css/html-section.scss';
import './css/tooltip.scss';
import './css/github-markdown.scss';
import './css/toast.scss';
import './css/moveable.scss';
import './css/flags.scss';

// API tokens
let helpflowApiToken = null;
let livechatApiToken = null;
let bugsnagApiToken = null;

let helpflowApiTokenElement = document.head.querySelector('meta[name="hf-api-token"]');

if (helpflowApiTokenElement && helpflowApiTokenElement.content.length) {
  helpflowApiToken = helpflowApiTokenElement.content;

  axios.defaults.headers.common['Authorization'] = 'Bearer ' + helpflowApiToken;
}

let livechatApiTokenElement = document.head.querySelector('meta[name="livechat-personal-access-token"]');

if (livechatApiTokenElement && livechatApiTokenElement.content.length) {
  livechatApiToken = livechatApiTokenElement.content;
}

let bugsnagApiTokenElement = document.head.querySelector('meta[name="bugsnag-api-token"]');

if (bugsnagApiTokenElement && bugsnagApiTokenElement.content.length) {
  bugsnagApiToken = bugsnagApiTokenElement.content;
}

// Settings for dependencies
LuxonSettings.defaultLocale = 'en-US';

// Initialize app and dependencies
const app = createApp(App, {data: JSON.parse(document.getElementById('app').getAttribute('data'))});
const emitter = mitt();
const pinia = createPinia();
const delay = (ms) => new Promise((res) => setTimeout(res, ms));
const appVersion = APP_VERSION; // taken from package.json
const appEnvironment = detectAppEnvironment();
const mixEnvironment = MIX_ENV; // "development" or "production"

// Load jQuery
window.$ = window.jQuery = jQuery;

// Add ability to retry axios requests
// Usage: axios.get(url, { retry: 3, retryDelay: 1000 });
axios.interceptors.response.use(undefined, (err) => {
  const { config, message } = err;

  if (!config || !config.retry) {
    return Promise.reject(err);
  }

  // Retry while internet is down or we have a server error
  if (
      !(
        message.includes('Request failed with status code 5') ||
        message.includes('timeout') ||
        message.includes('Network Error')
      )
    ) {
    return Promise.reject(err);
  }

  config.retry -= 1;

  const delayRetryRequest = new Promise((resolve) => {
    setTimeout(() => {
      resolve();
    }, config.retryDelay || 200);
  });

  return delayRetryRequest.then(() => axios(config));
});

// Provide Pinia stores with key variables
pinia.use(({ store }) => {
  store.environment = appEnvironment;
  store.isProduction = appEnvironment === 'production';
  store.livechatApi = livechatApi;
  store.objectPath = objectPath;
  store.emitter = emitter;
  store.delay = delay;
});

// Load BugSnag
let bugsnagLoaded = false;

try {
  Bugsnag.start({
    apiKey: bugsnagApiToken,
    plugins: [ new BugsnagPluginVue() ],
    appVersion: appVersion,
    appType: 'HAS',
    maxBreadcrumbs: 100,
    maxEvents: 100,
    releaseStage: appEnvironment,
  });

  const bugsnagVue = Bugsnag.getPlugin('vue');

  app.use(bugsnagVue);

  bugsnagLoaded = true;
} catch (e) {
  console.warn('[bugsnag] Failed to load!');
}

// Use app dependencies
app.use(pinia);

app.use(router);

app.use(vClickOutside);

app.use(FloatingVue, {
  // Default position offset along main axis (px)
  distance: 0,

  // Skip delay & CSS transitions when another popper is shown, so that the popper appear to instanly move to the new position.
  instantMove: false,

  // Themes
  themes: {
    tooltip: {
      delay: {
        show: 200, // in ms
        hide: 0, // in ms
      },
      html: true, // Enable HTML content in directive
    },
  },
});

app.use(Toast, {
  transition: 'Vue-Toastification__bounce',
  maxToasts: 10,
  timeout: 5000,
  position: TOAST_POSITION.BOTTOM_LEFT,
  newestOnTop: true,
  icon: false,
  draggable: false,
  closeOnClick: false,
  hideProgressBar: true,
  pauseOnHover: true,
  pauseOnFocusLoss: false,
  closeButton: ToastCloseButtonDefault,
  shareAppContext: true,
  toastDefaults: {
    [TOAST_TYPE.SUCCESS]: {
      closeButton: ToastCloseButtonSuccess,
    },
    [TOAST_TYPE.INFO]: {
      closeButton: ToastCloseButtonInfo,
    },
    [TOAST_TYPE.WARNING]: {
      closeButton: ToastCloseButtonWarning,
    },
    [TOAST_TYPE.ERROR]: {
      closeButton: ToastCloseButtonDanger,
    },
  },
  filterBeforeCreate: (toast, toasts) => {
    if (toasts.filter(t => t.content === toast.content).length !== 0) {
      return false; // Returning false discards duplicate toast
    }

    return toast;
  }
});

// Used to refresh computed properties once per second (e.g. time diffs)
let now = ref(Date.now());
setInterval(() => { now.value = Date.now() }, 1000);

// Used to refresh computed properties once per minute to optimize performance
let nowDelayed = ref(Date.now());
setInterval(() => { nowDelayed.value = Date.now() }, 1000 * 60);

// Provide global variables
app.provide('helpflowApiToken', helpflowApiToken);
app.provide('livechatApiToken', livechatApiToken);
app.provide('livechatApi', livechatApi);
app.provide('emitter', emitter);
app.provide('delay', delay);
app.provide('now', now);
app.provide('nowDelayed', nowDelayed);
app.provide('appVersion', appVersion);
app.provide('appEnvironment', appEnvironment);
app.provide('mixEnvironment', mixEnvironment);
app.provide('bugsnagLoaded', bugsnagLoaded);

// Mount the app
app.mount('#app');

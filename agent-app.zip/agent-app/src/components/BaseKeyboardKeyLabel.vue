<script setup></script>

<template>
  <pre
    class="mr-1.5 min-w-[40px] select-none rounded-md border border-gray-200 bg-white px-2 py-1.5 text-center"
  ><slot></slot></pre>
</template>

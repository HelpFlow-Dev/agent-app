<script setup></script>

<template>
  <Transition
    name="blur-in"
    enter-from-class="opacity-0"
    enter-to-class="opacity-100"
    enter-active-class="transition-all duration-75"
    leave-active-class="transition-all duration-75"
    leave-from-class="opacity-100"
    leave-to-class="opacity-0"
  >
    <slot></slot>
  </Transition>
</template>

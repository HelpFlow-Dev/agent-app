<script setup>
import { computed } from 'vue';
import { partial } from 'filesize';
import { getAspectRatio, getFontAwesomeIconClassForFileMimeType, openInNewTab } from '@/helpers';
import BaseIconButton from '@/components/BaseIconButton';
import ChatEventMessageMeta from '@/components/ChatEventMessageMeta';
import IconLoader from '@/components/icons/IconLoader.vue';
import FilePreviewModal from '@/components/modals/FilePreviewModal.vue';

const filesize = partial({ base: 2, round: 2, pad: true, standard: 'jedec' });

let showLoader = $ref(true);
let previewImageMaxHeight = $ref(150);
let previewImageMaxWidth = $ref(200);
let showFilePreviewModal = $ref(false);

const props = defineProps({
  chat: {
    type: Object,
    required: true,
  },
  event: {
    type: Object,
    required: true,
  },
});

const canViewFileInModal = computed(() => {
  if (props.event.thumbnail2x_url || props.event.mime_type === 'image/heif' || props.event.mime_type === 'image/heic') {
    return true;
  }

  return false;
});

const fileTypeForPreviewModal = computed(() => {
  if (props.event.thumbnail2x_url) {
    return 'image';
  }

  if (props.event.mime_type === 'image/heif' || props.event.mime_type === 'image/heic') {
    return 'image-heic';
  }

  return 'file';
});

const shouldRenderFileAsImage = computed(() => {
  return props.event.thumbnail2x_url;
});

const aspectRatio = computed(() => {
  if (props.event.height && props.event.width) {
    return getAspectRatio(props.event.width, props.event.height);
  }

  return 1;
});

const previewImageWidth = computed(() => {
  if (aspectRatio.value === 1) return previewImageMaxHeight;

  if (props.event.width > props.event.height) {
    return previewImageMaxWidth;
  }

  return props.event.width / (props.event.height / previewImageMaxHeight);
});

const previewImageHeight = computed(() => {
  if (aspectRatio.value === 1) return previewImageMaxHeight;

  if (props.event.width > props.event.height) {
    return props.event.height / (props.event.width / previewImageMaxWidth);
  }

  return previewImageMaxHeight;
});

function openFilePreviewModal() {
  showFilePreviewModal = true;
}

function closeFilePreviewModal() {
  showFilePreviewModal = false;
}
</script>

<template>
  <div v-if="shouldRenderFileAsImage" class="flex select-none flex-col">
    <div
      v-if="showLoader"
      class="flex min-h-[3.5rem] min-w-[3.5rem] items-center justify-center rounded-md border border-gray-200"
      :style="{ width: previewImageWidth + 'px', height: previewImageHeight + 'px' }"
    >
      <IconLoader size="md" class="text-blue-500"></IconLoader>
    </div>

    <a
      v-if="shouldRenderFileAsImage"
      v-show="!showLoader"
      target="_blank"
      class="w-fit transition hover:brightness-75"
      draggable="false"
      :href="event.url"
      @click.prevent="openFilePreviewModal"
    >
      <img
        class="h-auto w-full rounded-md border border-gray-200"
        draggable="false"
        :style="{
          'max-width': previewImageMaxWidth + 'px',
          'max-height': previewImageMaxHeight + 'px',
        }"
        :src="event.thumbnail2x_url"
        :alt="event.name"
        @load="showLoader = false"
      />
    </a>

    <ChatEventMessageMeta class="text-gray-400" :chat="chat" :event="event" />
  </div>
  <div v-else class="flex max-w-full flex-col">
    <div class="flex items-center rounded-md bg-gray-100 border-gray-200 p-3">
      <div
        class="flex h-10 w-10 shrink-0 items-center justify-center rounded-md text-xl"
      >
        <i :class="getFontAwesomeIconClassForFileMimeType(event.mime_type)"></i>
      </div>
      <div class="flex flex-col truncate px-3">
        <div class="truncate leading-5">
          {{ event.name }}
        </div>
        <div class="truncate text-sm text-gray-400">
          {{ filesize(event.size) }}
        </div>
      </div>
      <div class="ml-auto flex shrink-0">
        <BaseIconButton
          v-if="canViewFileInModal"
          class="fa-solid fa-magnifying-glass mr-3"
          v-tooltip="'Preview file'"
          @click="openFilePreviewModal"
        ></BaseIconButton>
        <BaseIconButton
          class="fa-solid fa-circle-down"
          v-tooltip="'Download file'"
          @click="openInNewTab(event.url)"
        ></BaseIconButton>
      </div>
    </div>

    <ChatEventMessageMeta class="text-gray-400" :chat="chat" :event="event" />
  </div>

  <FilePreviewModal
    v-if="canViewFileInModal"
    :show="showFilePreviewModal"
    :url="event.url"
    :file-type="fileTypeForPreviewModal"
    :file-name="event.name"
    @close="closeFilePreviewModal"
  />
</template>

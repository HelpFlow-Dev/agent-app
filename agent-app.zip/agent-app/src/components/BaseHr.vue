<script setup></script>

<template>
  <div class="-mx-3 my-3 h-[2px] bg-gray-200"></div>
</template>

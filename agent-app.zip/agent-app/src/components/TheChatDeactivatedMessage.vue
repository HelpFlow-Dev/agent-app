<script setup>
import { useAppStore } from '@/stores/app';
import { useChatsStore } from '@/stores/chats';
import BaseButton from '@/components/BaseButton.vue';
import BaseTextMessage from '@/components/BaseTextMessage.vue';

const app = useAppStore();
const chats = useChatsStore();
</script>

<template>
  <div class="-mx-3 border-b-2 border-gray-200 bg-gray-50 px-3 py-6">
    <div class="w-full text-center">
      <BaseTextMessage
        v-if="!chats.activeChat.is_deactivated && chats.activeChat.is_unassigned"
        class="flex-col"
      >
        This chat is unassigned.
      </BaseTextMessage>
      <BaseTextMessage v-else-if="chats.activeChat.is_transferred" class="flex-col">
        This chat has been transferred to another agent.
      </BaseTextMessage>
      <BaseTextMessage v-else class="flex-col">This chat has been archived.</BaseTextMessage>

      <!-- Sometimes chat can get unassiged because auth agent's internet got disconnected -->
      <BaseButton
        v-if="!chats.activeChat.is_deactivated && chats.activeChat.is_unassigned"
        class="mt-3"
        :disabled="!app.online || !app.livechatOnline"
        @click="chats.assignToSelf(chats.activeChat)"
      >
        Assign to me
      </BaseButton>
      <BaseButton
        v-else-if="chats.activeChat.status === 'supervising'"
        class="mt-3"
        :disabled="!app.online || !app.livechatOnline"
        @click="chats.stopAndCloseSupervisedChat(chats.activeChat)"
      >
        Close chat
      </BaseButton>
      <BaseButton
        v-else-if="chats.activeChat.is_transferred"
        class="mt-3"
        @click="chats.closeChat(chats.activeChat)"
      >
        Close chat
      </BaseButton>
      <BaseButton
        v-else
        class="mt-3"
        :disabled="!app.online || !app.livechatOnline"
        @click="chats.openNewChatThread(chats.activeChat)"
      >
        Start a new chat
      </BaseButton>
    </div>
  </div>
</template>

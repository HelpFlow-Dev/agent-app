<script setup>
defineProps({
  text: {
    type: String,
  },
  url: {
    type: String,
  },
  isAvailable: {
    type: Boolean,
    default: null,
  },
  variant: {
    type: String,
    default: 'agent',
    validator(value) {
      // The value must match one of these strings
      return ['agent', 'visitor'].includes(value);
    },
  },
  size: {
    type: Number,
    default: 32,
    validator(value) {
      // The value must match one of these strings
      return [32, 40].includes(value);
    },
  },
});
</script>

<template>
  <div class="relative flex shrink-0" :class="{ 'h-8 w-8': size === 32, 'h-10 w-10': size === 40 }">
    <div
      v-if="text"
      class="relative flex w-full select-none items-center justify-center rounded-full border capitalize text-white"
      :class="{
        'border-blue-500 bg-blue-400': variant === 'agent',
        'border-slate-500 bg-slate-400': variant === 'visitor',
      }"
      v-text="text.charAt(0)"
    ></div>
    <img
      v-else-if="url"
      :src="url"
      class="pointer-events-none relative w-full select-none rounded-full border border-gray-200"
      :class="{
        'text-lg': size === 40,
      }"
    />

    <span
      v-if="isAvailable === true || isAvailable === false"
      class="absolute bottom-0 right-0 flex"
      :class="{ 'h-3 w-3': size === 32, 'h-4 w-4': size === 40 }"
    >
      <span
        class="relative inline-flex rounded-full border-2 border-white shadow"
        :class="{
          'h-3 w-3': size === 32,
          'h-4 w-4': size === 40,
          'bg-emerald-500': isAvailable,
          'bg-rose-500': !isAvailable,
        }"
      ></span>
    </span>
  </div>
</template>

<script setup>
defineProps({
  variant: {
    type: String,
    default: 'light',
    validator(value) {
      // The value must match one of these strings
      return ['danger', 'light'].includes(value);
    },
  },
  grow: {
    type: Boolean,
    default: true,
  },
});
</script>

<template>
  <div
    class="items-center justify-center text-center"
    :class="{
      'text-gray-400': variant === 'light',
      'text-rose-500': variant === 'danger',
      'flex h-full': grow,
    }"
  >
    <slot></slot>
  </div>
</template>

<script setup>
import { computed } from 'vue';
import { partial } from 'filesize';
import { getFontAwesomeIconClassForFileMimeType } from '@/helpers';
import BaseIconButton from '@/components/BaseIconButton.vue';
import IconLoader from '@/components/icons/IconLoader.vue';

const filesize = partial({ base: 2, round: 2, pad: true, standard: 'jedec' });

const props = defineProps({
  file: {
    type: Object,
    required: true,
  },
  validateSize: {
    type: Boolean,
    default: true,
  },
  showUploadProgress: {
    type: Boolean,
    default: true,
  },
  canRemove: {
    type: Boolean,
    required: true,
  },
  fileSizeSoftLimit: {
    type: Number,
    default: null, // in binary units (base-2)
  },
  fileSizeHardLimit: {
    type: Number,
    default: null, // in binary units (base-2)
  },
});

defineEmits(['file-removed']);

const removeButtonVariant = computed(() => {
  if (!props.validateSize)  return 'primary';

  if (isInvalid.value) return 'danger';

  if (isLarge.value) return 'warning';

  return 'success';
});

const isLarge = computed(() => {
  let overSoftLimit = false;

  if (props.fileSizeSoftLimit) {
    overSoftLimit = props.file.size > props.fileSizeSoftLimit;
  }

  let overHardLimit = false;
  if (props.fileSizeHardLimit) {
    overHardLimit = props.file.size > props.fileSizeHardLimit;
  }

  return overSoftLimit && !overHardLimit;
});

const isInvalid = computed(() => {
  let overHardLimit = false;

  if (props.fileSizeHardLimit) {
    overHardLimit = props.file.size > props.fileSizeHardLimit;
  }

  return overHardLimit;
});
</script>

<template>
  <div
    class="mb-3 flex items-center rounded-md border-2 bg-white p-3"
    :class="{
      'border-gray-200': !validateSize,
      'border-emerald-500': validateSize && !isLarge,
      'border-yellow-500': validateSize && isLarge,
      'border-rose-500': validateSize && isInvalid,
    }"
  >
    <div
      class="flex shrink-0 items-center justify-center text-lg"
      :class="{
        'text-gray-500': !validateSize,
        'text-emerald-500': validateSize &&!isLarge,
        'text-yellow-500': validateSize && isLarge,
        'text-rose-500': validateSize && isInvalid,
      }"
    >
      <i class="fa-fw" :class="getFontAwesomeIconClassForFileMimeType(file.type)"></i>
    </div>
    <div class="truncate px-2 leading-7">
      {{ file.name }}
    </div>
    <div class="ml-auto flex shrink-0 whitespace-nowrap font-mono text-gray-400">
      {{ filesize(file.size) }}
    </div>
    <div v-if="canRemove && !file.isUploading && !file.isUploaded" class="ml-3 flex shrink-0">
      <BaseIconButton
        class="fa-solid fa-times"
        size="xs"
        :variant="removeButtonVariant"
        v-tooltip="'Remove file'"
        @click="$emit('file-removed', file)"
      ></BaseIconButton>
    </div>
    <div
      v-if="
        showUploadProgress &&
        (file.isQueuedForUpload || file.isUploading || file.isUploaded || file.uploadError)
      "
      class="ml-3 flex shrink-0"
    >
      <div class="flex h-7 w-7 flex-col items-center justify-center text-center">
        <IconLoader v-if="file.isUploading" class="text-blue-500" />

        <i v-if="file.isQueuedForUpload" class="fa-regular fa-clock text-lg text-gray-400"></i>
        <i v-if="file.isUploaded" class="fa-solid fa-check text-lg text-emerald-500"></i>
        <i v-if="file.uploadError" class="fa-solid fa-xmark text-lg text-rose-500"></i>
      </div>
    </div>
  </div>
</template>

<script setup>
import FilePreviewListItem from '@/components/FilePreviewListItem.vue';

defineProps({
  files: {
    type: Array,
    required: true,
  },
  canRemove: {
    type: Boolean,
    required: true,
  },
  validateSize: {
    type: Boolean,
    default: true,
  },
  fileSizeSoftLimit: {
    type: Number,
    default: null, // in binary units (base-2)
  },
  fileSizeHardLimit: {
    type: Number,
    default: null, // in binary units (base-2)
  },
});

const emit = defineEmits(['file-removed']);

function onRemovedFile(file) {
  emit('file-removed', file);
}
</script>

<template>
  <div v-if="files.length" class="flex flex-col">
    <FilePreviewListItem
      v-for="file in files"
      :file="file"
      :can-remove="canRemove"
      :file-size-soft-limit="fileSizeSoftLimit"
      :file-size-hard-limit="fileSizeHardLimit"
      :validate-size="validateSize"
      @file-removed="onRemovedFile"
    />
  </div>
</template>

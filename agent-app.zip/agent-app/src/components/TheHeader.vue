<script setup>
import { inject, onMounted, onUnmounted, nextTick } from 'vue';
import { useRoute } from 'vue-router';
import { useAppStore } from '@/stores/app';
import { useChatsStore } from '@/stores/chats';
import { useClientsStore } from '@/stores/clients';
import BaseIconButton from '@/components/BaseIconButton.vue';
import BaseLink from '@/components/BaseLink.vue';
import BaseTextMessage from '@/components/BaseTextMessage.vue';
import BugReportModal from '@/components/modals/BugReportModal.vue';
import KeyboardShortcutsModal from '@/components/modals/KeyboardShortcutsModal.vue';
import PerformanceDashboardModal from '@/components/modals/PerformanceDashboardModal.vue';
import SettingsModal from '@/components/modals/SettingsModal.vue';
import TheAgentStatusBox from '@/components/TheAgentStatusBox.vue';
import TheSuperviseIconButton from '@/components/TheSuperviseIconButton.vue';
import TheScreenRecorderIconButton from '@/components/TheScreenRecorderIconButton.vue';

const app = useAppStore();
const chats = useChatsStore();
const clients = useClientsStore();
const route = useRoute();
const emitter = inject('emitter');
const bugsnagLoaded = inject('bugsnagLoaded');

let showBugReportModal = $ref(false);
let showKeyboardShortcutsModal = $ref(false);
let showPerformanceDashboardModal = $ref(false);
let showSettingsModal = $ref(false);

onMounted(() => {
  emitter.on('shortcut-show-shortcuts-modal', () => {
    console.debug('[emitter:TheHeader] shortcut-show-shortcuts-modal');

    // Close any active modal first
    emitter.emit('shortcut-close-modal');

    // We need to use nextTick to wait for other modal to close
    nextTick(() => {
      showKeyboardShortcutsModal = true;
    });
  });
});

onUnmounted(() => {
  emitter.off('shortcut-show-shortcuts-modal');
});
</script>

<template>
  <div class="app-header flex w-full border-b-2 border-gray-200 bg-white">
    <div v-if="chats.activeChat" class="flex items-center pl-3">
      <!-- Current chat ID -->
      <div class="shrink-0 whitespace-nowrap pr-3">
        <span class="select-none">CHAT #</span>
        <span class="font-mono">{{ chats.activeChatCurrentThreadId }}</span>
      </div>

      <!-- Current chat client code -->
      <div class="shrink-0 whitespace-nowrap pr-3">
        {{ clients.activeClient.code }}
      </div>

      <!-- Current chat client website -->
      <BaseLink
        v-if="clients.activeClient.website_url && clients.activeClient.display_website_url"
        :to="clients.activeClient.website_url"
        class="max-w-[200px] select-none truncate font-medium"
        :show-external-link-icon="true"
      >
        {{ clients.activeClient.display_website_url }}
      </BaseLink>

      <!-- Current chat client quick links -->
      <div
        v-if="clients.activeClient.links.length"
        class="flex max-h-full flex-1 shrink select-none flex-wrap items-center overflow-y-auto break-all"
      >
        <BaseLink
          v-for="(link, index) in clients.activeClient.links"
          :key="index"
          :to="link.url"
          class="my-1 ml-3 font-medium"
          :show-external-link-icon="true"
        >
          {{ link.name }}
        </BaseLink>
      </div>
    </div>
    <div v-else class="flex items-center pl-3">
      <BaseTextMessage>Open a chat to view related information</BaseTextMessage>
    </div>

    <div class="ml-auto flex shrink-0 items-center">
      <!-- Open supervise chats page button -->
      <TheSuperviseIconButton :disabled="route.name !== 'supervise' && (!app.online || !app.livechatOnline)" />

      <!-- Open screen recorder modal button -->
      <TheScreenRecorderIconButton class="ml-3" />

      <!-- Open report bug modal button -->
      <BaseIconButton
        v-if="bugsnagLoaded"
        class="fa-solid fa-bug ml-3"
        v-tooltip="'Report a bug'"
        @click="showBugReportModal = true"
      />

      <!-- Open performance dashboard modal button -->
      <BaseIconButton
        v-if="app.livechatEnabled"
        class="fa-solid fa-chart-line ml-3"
        v-tooltip="'Performance dashboard'"
        :disabled="!app.online || !app.livechatOnline"
        @click="showPerformanceDashboardModal = true"
      ></BaseIconButton>

      <!-- Open keyboard shortcuts button -->
      <BaseIconButton
        class="fa-regular fa-keyboard ml-3"
        v-tooltip="'Keyboard shortcuts'"
        @click="showKeyboardShortcutsModal = true"
      ></BaseIconButton>

      <!-- Open settings button -->
      <BaseIconButton
        class="fa-solid fa-gear mx-3"
        v-tooltip="'Settings'"
        @click="showSettingsModal = true"
      />
    </div>

    <!-- Agent status management -->
    <TheAgentStatusBox v-if="app.livechatEnabled" />
  </div>

  <BugReportModal :show="showBugReportModal" @close="showBugReportModal = false" />

  <KeyboardShortcutsModal
    :show="showKeyboardShortcutsModal"
    @close="showKeyboardShortcutsModal = false"
  />

  <PerformanceDashboardModal
    :show="showPerformanceDashboardModal"
    @close="showPerformanceDashboardModal = false"
  />
  <SettingsModal :show="showSettingsModal" @close="showSettingsModal = false" />
</template>

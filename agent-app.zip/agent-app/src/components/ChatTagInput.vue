<script setup>
import { computed, inject, nextTick, onMounted, onUnmounted } from 'vue';
import { useAppStore } from '@/stores/app';
import { useChatsStore } from '@/stores/chats';
import { useTagsStore } from '@/stores/tags';
import BaseTextMessage from '@/components/BaseTextMessage.vue';

const app = useAppStore();
const chats = useChatsStore();
const tags = useTagsStore();
const emitter = inject('emitter');

let focusedTagIndex = $ref(0);
let tagSelectorInput = $ref(null);
let tagSelectorInputValue = $ref(null);

const availableTags = computed(() => {
  return tags.getAvailableTagsForChatThread(
    chats.activeChat,
    chats.activeChatCurrentThreadId,
    tagSelectorInputValue
  );
});

function showTagSelector() {
  app.tagPickerOpen = true;

  nextTick(() => {
    if (tagSelectorInput) tagSelectorInput.focus();
  });
}

function hideTagSelector() {
  app.tagPickerOpen = false;

  focusedTagIndex = 0;
  tagSelectorInputValue = null;

  nextTick(() => {
    if (tagSelectorInput) tagSelectorInput.blur();
  });
}

function scrollToFocusedTag() {
  let tagsList = document.getElementById('tags-list').children;

  if (tagsList[focusedTagIndex]) {
    tagsList[focusedTagIndex].scrollIntoView({ behavior: 'instant', block: 'end' });
  }
}

function focusOnNextTag() {
  focusedTagIndex++;

  // If there's no next item, focus on the first one
  if (focusedTagIndex > availableTags.value.length - 1) {
    focusedTagIndex = 0;
  }

  nextTick(() => {
    scrollToFocusedTag();
  });
}

function focusOnPreviousTag() {
  if (focusedTagIndex) {
    focusedTagIndex--;
  } else {
    // If there is no previous item, focus on the last one
    focusedTagIndex = availableTags.value.length - 1;
  }

  nextTick(() => {
    scrollToFocusedTag();
  });
}

function addFocusedTag() {
  let tag = availableTags.value[focusedTagIndex];

  if (tag) {
    addTag(tag);
  }
}

function filterTags() {
  if (availableTags.value.length === 1) {
    focusedTagIndex = 0;
  } else if (focusedTagIndex === null) {
    focusedTagIndex = 0;
  } else {
    let tag = availableTags.value[focusedTagIndex];

    if (!tag) {
      focusedTagIndex = 0;
    }
  }
}

function addTag(tag) {
  // By default if we're using keyboard we want to move focus to the previous tag
  let nextFocusedIndex = focusedTagIndex - 1;

  // However, if we were searching for something then we'll clear the input and reset focused index
  if (tagSelectorInputValue) nextFocusedIndex = 0;

  tagSelectorInputValue = null;

  tags.addTagToChatThread(chats.activeChat, chats.activeChatCurrentThreadId, tag.id);

  focusedTagIndex = availableTags.value[nextFocusedIndex] ? nextFocusedIndex : 0;

  nextTick(() => {
    scrollToFocusedTag();
  });
}

onMounted(() => {
  emitter.on('shortcut-toggle-tag-picker', () => {
    console.debug('[emitter:ChatTagInput] shortcut-toggle-tag-picker');

    if (app.tagPickerOpen) {
      hideTagSelector();
    } else if (!app.modalOpen) {
      // We don't want to open tag picker when any modal is open
      showTagSelector();
    }
  });

  emitter.on('shortcut-close-tag-picker', () => {
    console.debug('[emitter:ChatTagInput] shortcut-close-tag-picker');

    hideTagSelector();
  });
});

onUnmounted(() => {
  app.tagPickerOpen = false;

  emitter.off('shortcut-toggle-tag-picker');
  emitter.off('shortcut-close-tag-picker');
});
</script>

<template>
  <div class="relative mt-1.5 flex shrink-0 flex-col justify-center">
    <div class="relative flex flex-1" v-click-outside="hideTagSelector">
      <input
        ref="tagSelectorInput"
        v-model="tagSelectorInputValue"
        type="text"
        class="relative w-48 rounded-md border-y-2 border-transparent px-1.5 py-1 text-sm outline-none placeholder:text-gray-300 focus:placeholder:text-gray-400"
        placeholder="Start typing to add a tag..."
        @focus="showTagSelector"
        @keydown.up="focusOnPreviousTag"
        @keydown.down="focusOnNextTag"
        @keydown.enter="addFocusedTag"
        @input="filterTags"
      />

      <div
        v-if="app.tagPickerOpen"
        class="absolute z-20 bottom-full left-0 mb-1.5 min-w-full select-none rounded-md bg-white shadow-xl"
        :class="{ 'w-full': !availableTags.length }"
      >
        <div id="tags-list" class="flex max-h-[352px] flex-col overflow-y-auto border-gray-200">
          <div v-if="!availableTags.length">
            <BaseTextMessage class="rounded-md border-2 border-gray-200 p-1.5 text-sm shadow">
              No tags available
            </BaseTextMessage>
          </div>
          <div
            v-for="(tag, index) in availableTags"
            class="flex cursor-pointer items-center whitespace-nowrap p-1.5 px-2 text-sm hover:text-white"
            :class="{
              'bg-yellow-500 hover:bg-yellow-600': tag.level === 1,
              'bg-blue-500 hover:bg-blue-600': tag.level === 2,
              'bg-yellow-600': tag.level === 1 && focusedTagIndex === index,
              'bg-blue-600': tag.level === 2 && focusedTagIndex === index,
              'text-white': focusedTagIndex === index,
              'text-white/80': focusedTagIndex !== index,
              'rounded-t-md': index === 0,
              'rounded-b-md': index === Object.keys(availableTags).length - 1,
            }"
            :key="tag.id"
            @mouseover.passive="focusedTagIndex = index"
            @click="addTag(tag)"
          >
            {{ tag.title }}
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

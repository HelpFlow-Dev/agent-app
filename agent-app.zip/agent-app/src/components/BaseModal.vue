<script setup>
import { inject, onMounted, onUnmounted, watch } from 'vue';
import { useAppStore } from '@/stores/app';
import BaseButton from '@/components/BaseButton.vue';
import BaseIconButton from '@/components/BaseIconButton.vue';
import TransitionOpacity from '@/components/TransitionOpacity.vue';
import TransitionScaleIn from '@/components/TransitionScaleIn.vue';

const app = useAppStore();
const appEnvironment = inject('appEnvironment');
const emitter = inject('emitter');

const props = defineProps({
  show: {
    type: Boolean,
    default: false,
  },
  canClose: {
    type: Boolean,
    default: true,
  },
  size: {
    type: String,
    default: 'default',
    validator(value) {
      // The value must match one of these strings
      return ['sm', 'default', 'lg', 'xl', '2xl', '3xl', 'full'].includes(value);
    },
  },
  usePadding: {
    type: Boolean,
    default: true,
  },
  useWhiteBackground: {
    type: Boolean,
    default: false,
  },
});

let showInner = $ref(false);

watch(() => props.show, handleModalVisibilityChange);

const emit = defineEmits(['show', 'close']);

function handleModalVisibilityChange() {
  if (props.show) {
    emit('show');

    showInner = true;
    app.modalOpen = true;
  } else {
    showInner = false;
    app.modalOpen = false;
  }
}

onMounted(() => {
  emitter.on('shortcut-close-modal', handleModalCloseShortcut);
});

onUnmounted(() => {
  // When we remove parent element and cause open modal to be unmounted we must also mark it as closed
  if (props.show) app.modalOpen = false;

  emitter.off('shortcut-close-modal', handleModalCloseShortcut);
});

function handleModalCloseShortcut() {
  if (props.show && props.canClose) {
    if (appEnvironment !== 'production') console.debug('[emitter:BaseModal] shortcut-close-modal');

    emit('close');
  }
}
</script>

<template>
  <Teleport to="body">
    <TransitionOpacity>
      <div
        v-show="show"
        class="absolute inset-0 z-[9999] grid min-w-[1200px] place-items-center overflow-y-auto overflow-x-hidden bg-black/60"
        @click="handleModalCloseShortcut"
      >
        <TransitionScaleIn>
          <div
            v-if="showInner"
            class="m-auto w-full p-3"
            :class="{
              'max-w-xl': size === 'sm',
              'max-w-2xl': size === 'default',
              'max-w-3xl': size === 'lg',
              'max-w-5xl': size === 'xl',
              'max-w-7xl': size === '2xl',
              'max-w-[100rem]': size === '3xl',
              'max-w-full': size === 'full',
            }"
          >
            <div class="rounded-lg bg-white" @click.stop>
              <div class="flex items-center border-b-2 border-gray-200 p-3 font-bold leading-9">
                <div class="mr-3 truncate">
                  <slot name="title">BaseModal</slot>
                </div>

                <BaseIconButton
                  v-if="canClose"
                  class="fa-solid fa-times ml-auto shrink-0"
                  size="sm"
                  @click="$emit('close')"
                />
              </div>
              <div :class="{ 'bg-gray-100': !useWhiteBackground, 'p-3': usePadding }">
                <slot></slot>
              </div>
              <div class="flex border-t-2 border-gray-200 p-3">
                <slot name="footer">
                  <BaseButton @click="handleModalCloseShortcut" variant="gray-outline">Close</BaseButton>
                </slot>
              </div>
            </div>
          </div>
        </TransitionScaleIn>
      </div>
    </TransitionOpacity>
  </Teleport>
</template>

<script setup>
import { inject, onMounted, onUnmounted } from 'vue';
import { useAppStore } from '@/stores/app';
import { useChatsStore } from '@/stores/chats';
import DropZone from '@/components/DropZone.vue';

const emitter = inject('emitter');
const app = useAppStore();
const chats = useChatsStore();

defineProps({
  showDropZone: {
    type: Boolean,
    default: false,
  },
});

const emit = defineEmits(['leftDropZone']);

onMounted(() => {
  document.addEventListener('paste', handlePaste);
});

onUnmounted(() => {
  document.removeEventListener('paste', handlePaste);
});

function handlePaste(e) {
  // We can't send files to deactivated chat
  if (chats.activeChat.is_deactivated) return false;

  // If any other modal is already open we'll ignore the paste event
  if (!chats.activeChat.show_file_upload_modal && app.modalOpen) return false;

  const data = e.clipboardData || window.clipboardData;

  if (data.files.length) {
    emitter.emit('files-selected', { files: data.files, chatId: chats.activeChatId });
  }
}

function handleFileInputChange(e) {
  if (e.target.files.length) {
    emitter.emit('files-selected', { files: e.target.files, chatId: chats.activeChatId });
  }

  // Clear the input
  e.target.value = null;
}

function handleDroppedFiles(droppedFiles) {
  emit('leftDropZone'); // Close drop zone

  if (droppedFiles.length) {
      emitter.emit('files-selected', { files: droppedFiles, chatId: chats.activeChatId });
  }
}
</script>

<template>
  <input id="active-chat-file-input" type="file" class="hidden" multiple @change="handleFileInputChange" />

  <DropZone
    :show="showDropZone"
    @files-dropped="handleDroppedFiles"
    @dragleave.prevent="$emit('leftDropZone')"
  />
</template>

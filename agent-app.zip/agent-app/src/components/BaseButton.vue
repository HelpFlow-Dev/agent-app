<script setup>
import IconLoader from '@/components/icons/IconLoader.vue';

defineProps({
  variant: {
    type: String,
    default: 'primary',
    validator(value) {
      // The value must match one of these strings
      return [
        'primary',
        'primary-outline',
        'success',
        'success-outline',
        'danger',
        'danger-outline',
        'gray',
        'gray-outline',
      ].includes(value);
    },
  },
  iconBefore: {
    type: String,
    default: '',
  },
  iconAfter: {
    type: String,
    default: '',
  },
  showLoader: {
    type: Boolean,
    default: false,
  },
  active: {
    type: Boolean,
    default: false,
  },
  disabled: {
    type: Boolean,
    default: false,
  },
  useDefaultPadding: {
    type: Boolean,
    default: true,
  },
});
</script>

<template>
  <button
    type="button"
    class="inline-flex select-none items-center justify-center rounded-md border-2 text-sm font-semibold transition"
    :class="{
      /* primary */
      'border-transparent bg-blue-500 text-white': variant == 'primary',
      'hover:bg-blue-400 active:bg-blue-500': variant == 'primary' && !active && !disabled,
      /* primary-outline */
      'border-blue-500 bg-white text-blue-500': variant == 'primary-outline',
      'hover:border-blue-500 hover:bg-blue-50 hover:text-blue-500 active:bg-blue-100':
        variant == 'primary-outline' && !active && !disabled,
      'border-blue-500 bg-blue-100 text-blue-500': variant == 'primary-outline' && active === true,
      /* gray */
      'border-transparent bg-gray-500 text-white': variant == 'gray',
      'hover:bg-gray-400 active:bg-gray-500': variant == 'gray' && !active && !disabled,
      /* gray-outline */
      'border-gray-400 bg-white text-gray-500': variant == 'gray-outline',
      'hover:bg-gray-100 active:bg-gray-200': variant == 'gray-outline' && !active && !disabled,
      'bg-gray-200': variant == 'gray-outline' && active === true,
      /* success */
      'border-transparent bg-emerald-500 text-white': variant == 'success',
      'hover:bg-emerald-400 active:bg-emerald-500': variant == 'success' && !active && !disabled,
      /* success-outline */
      'border-emerald-500 bg-white text-emerald-500': variant == 'success-outline',
      'hover:border-emerald-500 hover:bg-emerald-50 hover:text-emerald-500 active:bg-emerald-100':
        variant == 'success-outline' && !active && !disabled,
      'bg-emerald-100': variant == 'success-outline' && active === true,
      /* danger */
      'border-transparent bg-rose-500 text-white': variant == 'danger',
      'hover:bg-rose-400 active:bg-rose-500': variant == 'danger' && !active && !disabled,
      'bg-rose-500': variant == 'danger' && active === true,
      /* danger-outline */
      'border-rose-500 bg-white text-rose-500': variant == 'danger-outline',
      'hover:border-rose-500 hover:bg-rose-50 hover:text-rose-500 active:bg-rose-100':
        variant == 'danger-outline' && !active && !disabled,
      'bg-rose-100': variant == 'danger-outline' && active === true,
      /* disabled state */
      'pointer-events-none opacity-60': disabled,
      /* padding */
      'px-4 py-2': useDefaultPadding,
    }"
    :disabled="disabled"
  >
    <IconLoader v-if="showLoader" class="-ml-1 mr-1.5" />

    <i
      v-if="iconBefore && !showLoader"
      :class="iconBefore"
      class="relative -ml-1 mr-1.5 flex h-5 w-5 items-center justify-center text-lg"
    ></i>

    <span><slot></slot></span>

    <i
      v-if="iconAfter && !showLoader"
      class="relative -mr-1 ml-1.5 flex h-5 w-5 items-center justify-center text-lg"
      :class="iconAfter"
    ></i>
  </button>
</template>

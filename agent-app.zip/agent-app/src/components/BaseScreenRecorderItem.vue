<script setup>
import { computed, inject } from 'vue';
import { DateTime } from 'luxon';
import BaseIconButton from '@/components/BaseIconButton.vue';
import { formatLuxonDuration } from '@/helpers';

const emitter = inject('emitter');
const now = inject('now');

const props = defineProps({
  screen: {
    type: Object,
    required: true,
  },
  title: {
    type: String,
    default: null,
  },
  description: {
    type: String,
    default: null,
  },
});

const isRecording = computed(() => {
  return props.screen.captureStartedAt !== null;
});
</script>

<template>
  <div
    class="flex items-center rounded-md border-2 bg-white p-3"
    :class="{
      'border-gray-200': !isRecording,
      'border-rose-500': isRecording,
    }"
  >
    <div class="h-[72px] w-[128px] shrink-0 rounded" :class="{ 'bg-gray-200': !isRecording }">
      <video
        v-if="isRecording"
        :srcObject="screen.stream"
        autoplay
        muted
        playsinline
        class="mx-auto h-full"
      ></video>
    </div>

    <div class="flex flex-col truncate px-2 leading-7">
      <div v-if="title" class="truncate" v-text="title"></div>
      <div v-if="description" class="truncate text-gray-400" v-text="description"></div>
    </div>

    <div
      class="ml-auto flex shrink-0 flex-col items-end whitespace-nowrap font-mono leading-7 text-gray-400"
    >
      <div>
        {{ isRecording ? 'Recording' : 'Paused' }}
      </div>
      <div v-if="screen.captureStartedAt">
        {{ formatLuxonDuration(DateTime.now().diff(screen.captureStartedAt), now) }}
      </div>
    </div>

    <div class="ml-3 flex shrink-0">
      <BaseIconButton
        class="fa-regular fa-circle-dot"
        size="xs"
        :variant="isRecording ? 'danger' : 'primary'"
        :active="isRecording"
        v-tooltip="isRecording ? '' : 'Select screen for recording'"
        @click="
          isRecording
            ? emitter.emit('screen-recording-stopped', { screenId: screen.id })
            : emitter.emit('screen-recording-pick-screen', { screenId: screen.id })
        "
      ></BaseIconButton>
    </div>
  </div>
</template>

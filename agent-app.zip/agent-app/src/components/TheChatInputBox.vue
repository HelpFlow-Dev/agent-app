<script setup>
import { inject, nextTick, onMounted, onUnmounted, watch } from 'vue';
import { useRoute } from 'vue-router';
import { useAgentsStore } from '@/stores/agents';
import { useAppStore } from '@/stores/app';
import { useChatsStore } from '@/stores/chats';
import { useCopilot } from '@/stores/copilot';
import BaseButton from '@/components/BaseButton.vue';
import BaseIconButton from '@/components/BaseIconButton.vue';
import CannedResponsePicker from '@/components/CannedResponsePicker.vue';
import EmojiPicker from '@/components/EmojiPicker.vue';

const emitter = inject('emitter');
const now = inject('now');
const route = useRoute();
const app = useAppStore();
const agents = useAgentsStore();
const chats = useChatsStore();
const copilot = useCopilot();

// Default line height in px for the input
const messageInputRowHeight = 24;
// This is the min height in px of message history that provides a good UX
const messageHistoryContainerMinHeight = 149;

let messageInput = $ref(null);
let inputIsScrollable = $ref(false);
let inputScrolledToEnd = $ref(false);
let showCannedResponsePicker = $ref(false);
let cannedResponsePickerSearchTerm = $ref('');
let showEmojiPicker = $ref(false);
// Interval for sendTypingIndicatorOnInputFocus method
let sendTypingIndicatorInterval = $ref(null);

onMounted(() => {
  handleChatTabSwitch();

  window.addEventListener('resize', handleInputAutoResize);

  sendTypingIndicatorInterval = setInterval(sendTypingIndicatorIfApplicable, 1000 * 7); // Every 7 seconds
});

onUnmounted(() => {
  window.removeEventListener('resize', handleInputAutoResize);

  app.chatInputFocused = false;

  clearInterval(sendTypingIndicatorInterval);
});

watch(() => route.params.id, handleChatTabSwitch);
watch(() => chats.activeChatMessageDraft, handleMessageDraftChange);

function handleMessageDraftChange() {
  // If agent is typing then we need to send typing indicator
  if (chats.activeChatMessageDraft) chats.sendTypingIndicator(chats.activeChatId);
}

function sendTypingIndicatorIfApplicable() {
  if (chats.activeChatMessageDraft || copilot.isLoading) {
    chats.sendTypingIndicator(chats.activeChatId);
  }
}

function handleChatTabSwitch() {
  // This prevents executing the following if active chat is not loaded,
  // for example, when you manually open chat that doesn't exist
  if (chats.activeChatIsLoaded) {
    handleInput();

    if (messageInput && chats.activeChat.message_draft.trim()) {
      messageInput.focus();
    }
  }
}

function sendMessage() {
  let message = chats.activeChat.message_draft.trim();

  chats.sendMessage(chats.activeChat, {
    chat_id: chats.activeChatId,
    message: message,
    is_private: chats.activeChat.is_private_message_mode,
  });

  chats.setMessageDraft(chats.activeChat, null);

  nextTick(() => {
    handleInput();
  });
}

function handleTyping() {
  handleInput();
}

function handleInput() {
  handleInputAutoResize();
  handleInputScroll();
  handleInputCannedResponsesPicker();
}

function handleInputAutoResize() {
  if (!messageInput) return;

  let messageHistoryContainer = document.getElementById('messageHistoryContainer');

  if (!messageHistoryContainer) return;

  // We need to get message history height to calculate the available height we can work with
  let messageHistoryContainerHeight = messageHistoryContainer.clientHeight;

  // At least 2 rows of text will always be visible by default
  let maxHeight = messageInputRowHeight * 2;

  // If we have more available space we'll calculate how much exactly
  if (messageHistoryContainerHeight >= messageHistoryContainerMinHeight) {
    let availableHeight = messageHistoryContainerHeight - messageHistoryContainerMinHeight;
    let availableRows = Math.floor(availableHeight / messageInputRowHeight);

    maxHeight = messageInput.clientHeight + availableRows * messageInputRowHeight;
  }

  // We need to reset the height first to calculate how much height input really needs
  messageInput.style.height = messageInputRowHeight * 2 + 'px';
  messageInput.style.height =
    (messageInput.scrollHeight > maxHeight ? maxHeight : messageInput.scrollHeight) + 'px';
}

function handleInputScroll() {
  if (!messageInput) return;

  inputIsScrollable = messageInput.scrollHeight > messageInput.clientHeight;

  inputScrolledToEnd =
    Math.abs(messageInput.scrollHeight - messageInput.clientHeight - messageInput.scrollTop) <= 2.5;
}

function handleInputCannedResponsesPicker() {
  if (!chats.activeChat) return;

  // If the latest char is "#" then we'll open canned responses picker
  if (chats.activeChat.message_draft.slice(-1) === '#') {
    showCannedResponsePicker = true;
  }

  if (showCannedResponsePicker) {
    // If the latest char is " " then we'll hide canned responses picker
    if (chats.activeChat.message_draft.slice(-1) === ' ') {
      hideCannedResponsePicker();
    }
  }

  let hashIndex = chats.activeChat.message_draft.lastIndexOf('#');

  if (hashIndex > -1) {
    cannedResponsePickerSearchTerm = chats.activeChat.message_draft.slice(hashIndex + 1);
  } else {
    hideCannedResponsePicker();
  }
}

function handleUpKey(e) {
  if (showCannedResponsePicker) {
    e.preventDefault();
    emitter.emit('cannedResponsesPickerKeydownUp');
  }
}

function handleDownKey(e) {
  if (showCannedResponsePicker) {
    e.preventDefault();
    emitter.emit('cannedResponsesPickerKeydownDown');
  }
}

function handleLeftKey(e) {
  if (showCannedResponsePicker) {
    e.preventDefault();
    emitter.emit('cannedResponsesPickerKeydownLeft');
  }
}

function handleRightKey(e) {
  if (showCannedResponsePicker) {
    e.preventDefault();
    emitter.emit('cannedResponsesPickerKeydownRight');
  }
}

function handleEnterKey() {
  if (showCannedResponsePicker) {
    emitter.emit('cannedResponsesPickerKeydownEnter');
  } else {
    sendMessage();
  }
}

function handleInputFocused() {
  app.chatInputFocused = true;

  emitter.emit('chatInputFocused');
}

function handleEscKey() {
  if (showCannedResponsePicker) {
    hideCannedResponsePicker();
  } else if (messageInput) {
    messageInput.blur();
  }
}

function hideEmojiPicker() {
  showEmojiPicker = false;
}

function toggleCannedResponsePicker() {
  showCannedResponsePicker = !showCannedResponsePicker;

  if (showCannedResponsePicker) {
    if (chats.activeChat.message_draft.slice(-1) !== '#') {
      chats.activeChat.message_draft += '#';
      messageInput.focus();
    }
  }
}

function hideCannedResponsePicker() {
  showCannedResponsePicker = false;
  cannedResponsePickerSearchTerm = '';
}

function handleUploadFileButtonClick() {
  if (chats.activeChatSelectedFilesCount) {
    chats.showFileUploadModal(chats.activeChat);
  } else {
    openFilePicker();
  }
}

function handleChatHoldButtonClick() {
  // If chat is already on hold, we'll cancel the hold timer
  if (chats.isOnHold(chats.activeChat)) {
    chats.cancelHold(chats.activeChat);
  } else {
    chats.putOnHold(chats.activeChat);
  }
}

function openFilePicker() {
  let fileInput = document.getElementById('active-chat-file-input');

  if (fileInput) fileInput.click();
}

// TODO-HAS: add support for %customer-name%, %customer-email%, %agent-name%, %agent-email% placeholders
function handlePickedCannedResponse(cannedResponse) {
  hideCannedResponsePicker();

  if (!messageInput || !cannedResponse) return;

  let hashIndex = chats.activeChat.message_draft.lastIndexOf('#');

  let currentPosition = messageInput.selectionStart;

  if (hashIndex > -1) {
    let searchTerm = chats.activeChat.message_draft.slice(hashIndex);

    chats.setMessageDraft(
      chats.activeChat,
      chats.activeChat.message_draft.replace(searchTerm, cannedResponse.response_text)
    );

    if (messageInput) messageInput.focus();

    let newPosition = currentPosition + Array.from(cannedResponse.response_text).length + 1;

    // We'll move cursor to the end of canned response and scroll to cursor
    setTimeout(() => {
      if (messageInput) {
        messageInput.setSelectionRange(newPosition, newPosition);
        messageInput.blur();
        messageInput.focus();
      }

      handleInput();
    }, 0);
  }
}

function handlePickedEmoji(emoji) {
  hideEmojiPicker();

  if (!messageInput || !emoji) return;

  // Current cursor position
  let currentPosition = messageInput.selectionStart;
  let prevChar = chats.activeChat.message_draft.charAt(currentPosition - 1);
  let nextChar = chats.activeChat.message_draft.charAt(currentPosition);

  let newText = '';

  // If previous char is not space, we'll add a space
  if (currentPosition > 0 && !/\s/g.test(prevChar)) newText += ' ';

  newText += emoji;

  // If next char is not space, we'll add a space
  if (!/\s/g.test(nextChar)) newText += ' ';

  let textBefore = chats.activeChat.message_draft.slice(0, currentPosition);
  let textAfter = chats.activeChat.message_draft.slice(currentPosition);

  chats.setMessageDraft(chats.activeChat, textBefore + newText + textAfter);

  let newPosition = currentPosition + Array.from(newText).length + 1;

  if (messageInput) messageInput.focus();

  // We'll move cursor back to where it was after inserting emoji and scroll to cursor
  setTimeout(() => {
    if (messageInput) {
      messageInput.setSelectionRange(newPosition, newPosition);
      messageInput.blur();
      messageInput.focus();
    }

    handleInput();
  }, 0);
}

function handlePaste(e) {
  const data = e.clipboardData || window.clipboardData;

  // We have a separate handler for file pasting in TheChatFileInput component
  if (data.files.length) {
    messageInput.blur();
    e.preventDefault();
    return false;
  }
}
</script>

<template>
  <div
    class="relative rounded-md border-2 transition-[border]"
    :class="{
      'border-gray-200': !app.chatInputFocused && !chats.activeChat.is_private_message_mode,
      'border-gray-300': !app.chatInputFocused && chats.activeChat.is_private_message_mode,
      'border-blue-500': app.chatInputFocused && !chats.activeChat.is_private_message_mode,
      'border-gray-500': app.chatInputFocused && chats.activeChat.is_private_message_mode,
      'bg-gray-100': chats.activeChat.is_private_message_mode,
    }"
  >
    <div class="relative flex px-3 pt-3">
      <textarea
        ref="messageInput"
        class="w-full select-none resize-none outline-none"
        :class="{
          'bg-gray-100 placeholder:text-gray-500': chats.activeChat.is_private_message_mode,
          'placeholder:text-gray-400': !chats.activeChat.is_private_message_mode,
        }"
        :placeholder="chats.activeChat.is_private_message_mode ? 'Type a private message that will be visible to agents only...' : 'Type a message...'"
        :disabled="chats.activeChat.is_deactivated"
        v-model="chats.activeChat.message_draft"
        @focus="handleInputFocused"
        @blur="app.chatInputFocused = false"
        @keydown.esc.stop="handleEscKey"
        @keydown.up="handleUpKey"
        @keydown.down="handleDownKey"
        @keydown.left="handleLeftKey"
        @keydown.right="handleRightKey"
        @keydown.enter.exact.prevent="handleEnterKey"
        @scroll="handleInputScroll"
        @paste="handlePaste"
        @change="handleTyping"
        @input="handleTyping"
      ></textarea>

      <EmojiPicker
        :show="showEmojiPicker"
        v-click-outside="hideEmojiPicker"
        @picked="handlePickedEmoji"
        @close="hideEmojiPicker"
      />

      <CannedResponsePicker
        :show="showCannedResponsePicker"
        :search-term="cannedResponsePickerSearchTerm"
        v-click-outside="hideCannedResponsePicker"
        @picked="handlePickedCannedResponse"
        @closed="hideCannedResponsePicker"
      />
    </div>
    <div
      class="flex border-t-2 p-3 items-center"
      :class="{
        'border-transparent': !inputIsScrollable || (inputIsScrollable && inputScrolledToEnd),
        'border-gray-200':
          inputIsScrollable && !inputScrolledToEnd && !chats.activeChat.is_private_message_mode,
        'border-gray-300':
          inputIsScrollable && !inputScrolledToEnd && chats.activeChat.is_private_message_mode,
      }"
    >
      <BaseIconButton
        v-if="chats.activeChat.status !== 'supervising'"
        class="fa-solid"
        v-tooltip="
          chats.activeChat.is_private_message_mode
            ? 'Private mode enabled'
            : 'Enable private mode to talk with your team behind the scenes and leave private notes'
        "
        variant="gray-outline"
        :disabled="!agents.privateMessageModeAvailable"
        :active="chats.activeChat.is_private_message_mode"
        :class="{
          'fa-lock': chats.activeChat.is_private_message_mode,
          'fa-lock-open': !chats.activeChat.is_private_message_mode,
        }"
        @click="
          chats.activeChat.is_private_message_mode = !chats.activeChat.is_private_message_mode
        "
      />
      <BaseIconButton
        v-else-if="chats.activeChat.status === 'supervising'"
        class="fa-solid fa-lock"
        v-tooltip="'Private mode enabled'"
        variant="gray-outline"
        :disabled="true"
        :active="true"
      />

      <BaseIconButton
        class="fa-solid fa-hashtag ml-3"
        :active="showCannedResponsePicker"
        v-tooltip="showCannedResponsePicker ? '' : 'Canned responses'"
        @click="toggleCannedResponsePicker"
      />

      <BaseIconButton
        class="fa-solid fa-paperclip ml-3 before:rotate-[-45deg] before:content-['\f0c6']"
        :active="chats.activeChatSelectedFilesCount > 0"
        v-tooltip="chats.activeChatSelectedFilesCount ? 'Upload and send selected files' : 'Choose files to upload'"
        @click="handleUploadFileButtonClick"
      />

      <BaseIconButton
        class="fa-regular fa-face-laugh-beam ml-3"
        :active="showEmojiPicker"
        v-tooltip="showEmojiPicker ? '' : 'Emoji picker'"
        @click="showEmojiPicker = !showEmojiPicker"
      />

      <BaseIconButton
        class="fa-solid fa-stopwatch ml-3"
        :active="chats.isOnHold(chats.activeChat)"
        v-tooltip="chats.isOnHold(chats.activeChat) ? 'Chat is placed on hold, click to cancel' : 'Click to put the chat on hold for 3 minutes'"
        @click="handleChatHoldButtonClick"
      />

      <span v-if="chats.isOnHold(chats.activeChat)" class="ml-3 text-sm text-gray-400 pointer-events-none select-none">
        On hold for {{ chats.chatHoldTimerDiffFormatted(chats.activeChat, now) }}
      </span>

      <BaseButton
        variant="primary-outline"
        class="ml-auto"
        icon-after="fa-regular fa-circle-right"
        :use-default-padding="true"
        :disabled="!chats.activeChat.message_draft.trim()"
        @click="sendMessage"
      >
        Send
      </BaseButton>
    </div>
  </div>
</template>

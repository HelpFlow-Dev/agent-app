<script setup>
import objectPath from 'object-path';
import BaseLink from '@/components/BaseLink';
import ChatEventMessageMeta from '@/components/ChatEventMessageMeta';

defineProps({
  chat: {
    type: Object,
    required: true,
  },
  event: {
    type: Object,
    required: true,
  },
});
</script>

<template>
  <div class="flex flex-col">
    <div class="flex w-fit flex-col rounded-lg border border-gray-200 bg-white">
      <div class="rounded-t-lg border-b border-gray-200 bg-gray-50 px-10 py-3 text-center">
        <span v-if="event.form_type === 'prechat'">Pre-chat form</span>
        <span v-else-if="event.form_type === 'postchat'">Post-chat form</span>
        <span v-else>Form</span>
      </div>

      <div
        v-for="(field, index) in event.fields"
        :key="field.id"
        class="px-3 pb-3"
        :class="{ 'pt-3': index === 0, 'pt-0': index > 0 }"
      >
        <div v-text="field.label"></div>

        <BaseLink
          v-if="
            (field.label.toLowerCase().includes('e-mail') ||
              field.label.toLowerCase().includes('email')) &&
            field.answer
          "
          :to="'mailto:' + field.answer"
          class="-ml-1 font-medium"
        >
          {{ field.answer }}
        </BaseLink>
        <div
          v-else-if="objectPath.has(field, 'answer.label')"
          class="text-gray-400"
          v-text="field.answer.label || '(no answer)'"
        ></div>
        <div v-else class="text-gray-400" v-text="field.answer || '(no answer)'"></div>
      </div>
    </div>

    <ChatEventMessageMeta class="text-gray-400" :chat="chat" :event="event" />
  </div>
</template>

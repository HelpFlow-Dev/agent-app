<script setup>
import { inject, nextTick, onMounted, onUnmounted, watch } from 'vue';
import { useAppStore } from '@/stores/app';
import BaseInput from '@/components/BaseInput.vue';
import BaseTextMessage from '@/components/BaseTextMessage.vue';
import emojis from '@/stores/emojis.json';

const app = useAppStore();
const emitter = inject('emitter');

const props = defineProps({
  show: {
    type: Boolean,
    default: false,
  },
});

const emit = defineEmits(['close', 'picked']);

let searchValue = $ref('');
let emojisByCategories = $ref([]);
let searchResults = $ref([]);

watch(() => props.show, handleVisibilityChange);

onMounted(() => {
  emitter.on('shortcut-close-emoji-picker', () => {
    console.debug('[emitter:EmojiPicker] shortcut-close-emoji-picker');

    emit('close');
  });

  emojisByCategories = emojis.list.reduce(function (results, item) {
    results[item.category] = results[item.category] || [];
    results[item.category].push(item);
    return results;
  }, Object.create(null));
});

onUnmounted(() => {
  app.emojiPickerOpen = false;

  emitter.off('shortcut-close-emoji-picker');
});

function search() {
  nextTick(() => {
    if (searchValue.trim()) {
      const lastWord = searchValue.split(' ').pop().toLowerCase();

      searchResults = emojis.list.filter(({ name }) =>
        name.replace(/\s/g, '').toLowerCase().includes(lastWord.replace(/:/g, ''))
      );
    } else {
      searchResults = [];
    }
  });
}

function handleVisibilityChange() {
  if (props.show) {
    app.emojiPickerOpen = true;

    nextTick(() => {
      let searchInput = document.getElementById('emoji-search-input');

      if (searchInput) searchInput.focus();
    });
  } else {
    app.emojiPickerOpen = false;

    searchValue = '';
  }
}
</script>

<template>
  <div
    v-if="show"
    class="absolute bottom-full left-0 z-10 -mb-3 ml-3 flex h-[324px] w-[352px] select-none flex-col rounded-md border-2 border-gray-200 bg-white shadow-xl"
  >
    <!-- TODO: tabs with icons and scroll -->
    <!-- <div class="flex">
      <div v-for="category in emojis.categories" :key="category">
        {{ category }}
      </div>
    </div> -->

    <div class="relative flex flex-col border-b-2 border-gray-200 p-3">
      <div class="relative flex">
        <i class="fa-solid fa-magnifying-glass absolute left-3 top-3 text-gray-400"></i>

        <BaseInput
          id="emoji-search-input"
          variant="with-icon"
          placeholder="Search..."
          v-model="searchValue"
          @input="search"
        />
      </div>
    </div>

    <div v-if="!searchValue.trim()" class="flex flex-col overflow-y-auto">
      <div v-for="(category, categoryId) in emojis.categories" :key="categoryId" class="p-3">
        <div class="mb-1.5 flex w-full text-sm font-medium text-gray-400">
          {{ category }}
        </div>

        <div class="grid grid-cols-9">
          <div
            class="flex h-9 w-9 cursor-pointer items-center justify-center rounded-md border-2 border-transparent text-2xl transition hover:border-blue-500 hover:bg-blue-50 active:border-blue-500 active:bg-blue-100"
            v-for="emojis in emojisByCategories[categoryId]"
            :key="emojis.emoji"
            :emoji="emojis.emoji"
            :title="emojis.name"
            @click="$emit('picked', emojis.emoji)"
          >
            {{ emojis.emoji }}
          </div>
        </div>
      </div>
    </div>

    <div v-if="searchValue.trim()" class="flex flex-1 flex-col overflow-y-auto">
      <div class="flex flex-1 flex-col p-3">
        <div class="mb-1.5 flex w-full text-sm font-medium text-gray-400">Search results</div>

        <div v-if="searchResults.length" class="grid grid-cols-9">
          <div
            class="flex h-9 w-9 cursor-pointer items-center justify-center rounded-md border-2 border-transparent text-2xl transition hover:border-blue-500 hover:bg-blue-50 active:border-blue-500 active:bg-blue-100"
            v-for="emojis in searchResults"
            :key="emojis.emoji"
            :emoji="emojis.emoji"
            :title="emojis.name"
            @click="$emit('picked', emojis.emoji)"
          >
            {{ emojis.emoji }}
          </div>
        </div>
        <BaseTextMessage v-else>Nothing found</BaseTextMessage>
      </div>
    </div>
  </div>
</template>

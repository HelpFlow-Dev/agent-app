<script setup>
import BaseIconButton from '@/components/BaseIconButton.vue';
</script>

<template>
  <BaseIconButton class="fa-solid fa-times ml-3 shrink-0" size="xs" variant="warning" />
</template>

<script setup>
import ChatEventMessageAgent from '@/components/ChatEventMessageAgent.vue';
import ChatEventMessageSystem from '@/components/ChatEventMessageSystem.vue';
import ChatEventMessageVisitor from '@/components/ChatEventMessageVisitor.vue';
import ChatUnreadMessagesBanner from '@/components/ChatUnreadMessagesBanner.vue';

defineProps({
  chat: {
    type: Object,
    required: true,
  },
  event: {
    type: Object,
    required: true,
  },
  sameAuthorAsPreviousEvent: {
    type: Boolean,
    required: true,
  },
  showUnreadMessagesBanner: {
    type: Boolean,
    required: true,
  },
  unreadMessagesCount: {
    type: Number,
    required: true,
  },
});
</script>

<template>
  <ChatUnreadMessagesBanner
    v-if="showUnreadMessagesBanner"
    :unread-messages-count="unreadMessagesCount"
  />

  <ChatEventMessageSystem v-if="event.author_is_system" :event="event" />
  <ChatEventMessageVisitor
    v-else-if="event.author_is_visitor && !(event.form_type === 'prechat' && event.fields.length === 0)"
    :chat="chat"
    :event="event"
    :same-author-as-previous-event="sameAuthorAsPreviousEvent"
  />
  <ChatEventMessageAgent
    v-else-if="event.author_is_agent"
    :chat="chat"
    :event="event"
    :same-author-as-previous-event="sameAuthorAsPreviousEvent"
  />
</template>

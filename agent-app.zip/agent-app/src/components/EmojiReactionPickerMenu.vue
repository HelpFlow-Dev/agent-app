<script setup>
const props = defineProps({
  show: {
    type: Boolean,
    default: false,
  },
  currentReaction: {
    type: String,
    default: null,
  },
});

const emit = defineEmits(['picked']);

let availableReactions = $ref(['👍', '👎', '❤️', '😢', '✅', '⌛️']);

function pick(reaction) {
  emit('picked', reaction);
}
</script>

<template>
  <div
    v-if="show"
    class="absolute top-[calc(50%-48px)] left-1/2 transform -translate-x-1/2 -translate-y-1/2 z-10 select-none grid gap-1.5 grid-flow-col rounded-md bg-white shadow p-1.5"
  >
    <div
      v-for="(reaction, index) in availableReactions"
      class="flex items-center justify-center h-[36px] w-[36px] text-[20px] rounded-md cursor-pointer transition"
      :class="{
        'bg-gray-200': currentReaction === reaction,
        'hover:bg-gray-100 active:bg-gray-200': currentReaction !== reaction,
      }"
      @click="pick(reaction)"
    >
      {{ reaction }}
    </div>
  </div>
</template>

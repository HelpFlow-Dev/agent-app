<script setup>
import { computed, inject } from 'vue';
import { livechatClientId } from '@/helpers';
import { useAgentsStore } from '@/stores/agents';
import ChatEventMessageBubble from '@/components/ChatEventMessageBubble';
import ChatEventMessageCard from '@/components/ChatEventMessageCard';
import ChatEventMessageFile from '@/components/ChatEventMessageFile';
import BaseAvatar from '@/components/BaseAvatar';

const agents = useAgentsStore();
const emitter = inject('emitter');

const props = defineProps({
  chat: {
    type: Object,
    required: true,
  },
  event: {
    type: Object,
    required: true,
  },
  sameAuthorAsPreviousEvent: {
    type: Boolean,
    required: true,
  },
});

const hasEmojiReaction = computed(() => {
  if (props.event.properties && props.event.properties[livechatClientId] && props.event.properties[livechatClientId].message_reaction) {
    return true;
  }

  return false;
});
</script>

<template>
  <div
    class="agent-message relative flex flex-col items-end px-3"
    :class="{ 'mt-1.5': sameAuthorAsPreviousEvent, 'mt-3': !sameAuthorAsPreviousEvent }"
    :data-event-id="event.id"
  >
    <!-- Agent name -->
    <div v-if="!sameAuthorAsPreviousEvent" class="mr-10 inline-flex p-px text-sm text-gray-400">
      {{
        agents.getAgentByLivechatId(event.author_id)
          ? agents.getAgentByLivechatId(event.author_id).display_name
          : event.author_id
      }}
    </div>

    <!-- Message -->
    <div
      class="relative mr-10 flex justify-end"
      :class="{
        'max-w-[266px]': event.type === 'rich_message',
        'max-w-[66%]': event.type !== 'rich_message',
      }"
    >
      <div class="relative flex mr-1.5">
        <!-- Add new canned response button -->
        <i
          v-if="event.type === 'message'"
          class="fa-regular fa-square-plus flex h-[26px] w-[26px] shrink-0 cursor-pointer items-center justify-center self-center text-[0.925rem] transition hover:text-blue-500"
          v-tooltip="'Save as canned response'"
          @click="emitter.emit('openAddCannedResponseModal', { event: event })"
        ></i>

        <div
          v-if="(event.type === 'message' || event.type === 'file') && chat.client_code !== 'General' && hasEmojiReaction"
          class="relative flex"
          :class="{ 'top-[-10px]': event.type === 'file' }"
        >
          <i
            class="relative flex h-[26px] w-[26px] shrink-0 items-center justify-center self-center rounded-md transition select-none not-italic"
            v-tooltip="'Visitor left this reaction to the message'"
          >{{ hasEmojiReaction ? event.properties[livechatClientId].message_reaction : '' }}</i>
        </div>
      </div>

      <ChatEventMessageCard v-if="event.type === 'rich_message'" :chat="chat" :event="event" />
      <ChatEventMessageFile v-else-if="event.type === 'file'" :chat="chat" :event="event" />
      <ChatEventMessageBubble v-else :chat="chat" :event="event" />

      <!-- Avatar -->
      <div class="absolute -mr-10">
        <BaseAvatar
          v-if="!sameAuthorAsPreviousEvent && event.author_is_auth_agent"
          :url="agents.agent.avatar_url ? agents.agent.avatar_url : agents.agent.livechat_avatar"
        />
        <BaseAvatar
          v-else-if="!sameAuthorAsPreviousEvent && !event.author_is_auth_agent && agents.getAgentByLivechatId(event.author_id) && agents.getAgentByLivechatId(event.author_id).avatar_url"
          :url="agents.getAgentByLivechatId(event.author_id).avatar_url"
        />
        <BaseAvatar
          v-else-if="!sameAuthorAsPreviousEvent && !event.author_is_auth_agent"
          :text="
            agents.getAgentByLivechatId(event.author_id)
              ? agents.getAgentByLivechatId(event.author_id).display_name
              : event.author_id
          "
        />
      </div>
    </div>
  </div>
</template>

<script setup>
import { computed } from 'vue';
import { useScreenRecordingsStore } from '@/stores/screenRecordings';
import BaseToast from '@/components/BaseToast.vue';
import BaseLink from '@/components/BaseLink.vue';

const screenRecordings = useScreenRecordingsStore();

const props = defineProps({
  recordingId: {
    type: String,
    required: true,
  },
  validationMessage: {
    type: String,
    default: null,
  },
});

const errorMessage = computed(() => {
  if (props.validationMessage) {
    return 'Screen recording upload failed: ' + props.validationMessage + ', retrying...';
  }

  return 'Screen recording upload failed, retrying...'
});

function downloadFile(event) {
  screenRecordings.downloadRecording(props.recordingId);

  let toast = event.target.closest('.Vue-Toastification__toast');
  let toastCloseButton = toast.querySelector('.Vue-Toastification__close-button');

  toastCloseButton.click();
}
</script>

<template>
  <BaseToast>
    <div>
      <div class="block">
        {{ errorMessage }}
      </div>

      <div class="block -ml-1">
        <BaseLink
          class="whitespace-nowrap font-medium"
          to="javascript:void(0);"
          :show-download-icon="true"
          @click="downloadFile"
        >Download file</BaseLink>
      </div>
    </div>
  </BaseToast>
</template>

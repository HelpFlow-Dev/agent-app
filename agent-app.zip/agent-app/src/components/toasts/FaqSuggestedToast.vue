<script setup>
import BaseToast from '@/components/BaseToast.vue';
import BaseLink from '@/components/BaseLink.vue';

defineProps({
  url: {
    type: String,
    required: false,
  },
});
</script>

<template>
  <BaseToast>
    <div>
      FAQ has been suggested.

      <BaseLink
        v-if="url"
        class="whitespace-nowrap font-medium"
        :to="url"
        :show-external-link-icon="true"
      >View FAQ</BaseLink>
    </div>
  </BaseToast>
</template>

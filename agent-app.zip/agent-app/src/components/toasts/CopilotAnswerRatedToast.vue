<script setup>
import BaseToast from '@/components/BaseToast.vue';
import BaseLink from '@/components/BaseLink.vue';

const props = defineProps({
  rating: {
    type: Number,
    required: true,
  },
  requestId: {
    type: Number,
    required: true,
  },
});
</script>

<template>
  <BaseToast>
    <div>
      Copilot answer rated as {{ rating === 1 ? 'good' : 'bad' }}.

      <BaseLink
        class="whitespace-nowrap font-medium"
        to="javascript:void(0);"
        :show-comment-icon="true"
        @click="$emit('comment')"
      >Comment</BaseLink>
    </div>
  </BaseToast>
</template>

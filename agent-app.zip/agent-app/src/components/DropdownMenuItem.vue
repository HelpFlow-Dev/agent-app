<script setup>
defineProps({
  icon: {
    type: String,
    default: '',
  },
  disabled: {
    type: Boolean,
    default: false,
  },
});
</script>

<template>
  <div
    class="mx-[-2px] flex cursor-pointer whitespace-nowrap border-x-2 border-gray-200 px-3 py-2 transition hover:border-blue-500 hover:bg-blue-100 hover:text-blue-500 active:border-blue-500 active:bg-blue-100 active:text-blue-500 active:opacity-70"
    :class="{ 'pointer-events-none text-gray-300': disabled }"
  >
    <div v-if="icon" class="mr-3 flex w-5 items-center justify-center">
      <i :class="icon"></i>
    </div>
    <slot></slot>
  </div>
</template>

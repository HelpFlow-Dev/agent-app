<script setup>
import { inject } from 'vue';
import { useRouter } from 'vue-router';
import { useAppStore } from '@/stores/app';
import { useChatsStore } from '@/stores/chats';
import { useClientsStore } from '@/stores/clients';
import ChatTabButton from '@/components/ChatTabButton.vue';
import CloseChatConfirmationModal from '@/components/modals/CloseChatConfirmationModal.vue';
import FileUploadModal from '@/components/modals/FileUploadModal.vue';
import RTOModal from '@/components/modals/RTOModal.vue';

const app = useAppStore();
const router = useRouter();
const chats = useChatsStore();
const clients = useClientsStore();
const now = inject('now');

function openChat(chat) {
  if (chat.is_loaded) router.push({ name: 'chat', params: { id: chat.id } });
}
</script>

<template>
  <div
    v-if="app.livechatEnabled && chats.getChats().length"
    class="desktop:grid-cols-5 laptop:text-sm laptop:max-h-[169px] relative grid max-h-[188px] w-full grid-cols-4 gap-3 overflow-y-auto p-3 text-xs shrink-0"
  >
    <ChatTabButton
      v-for="chat in chats.getChats()"
      :key="chat.id"
      :chat="chat"
      :client="clients.getClientByCode(chat.client_code)"
      :seconds-since-last-agent-reply="chats.secondsSinceLastAgentReply(chat, now)"
      @click="openChat(chat)"
    >
      {{ chat.id }}
    </ChatTabButton>

    <!-- Some modals need to be rendered independent of ChatView -->

    <FileUploadModal
      v-for="chat in chats.getLoadedOngoingChats()"
      :key="chat.id"
      :show="chat.show_file_upload_modal"
      :chat="chat"
    />

    <CloseChatConfirmationModal
      v-for="chat in chats.getLoadedChats()"
      :key="chat.id"
      :show="chat.show_close_chat_confirmation_modal"
      :chat="chat"
    />

    <RTOModal
      v-for="chat in chats.getLoadedChats()"
      :key="chat.id"
      :show="chat.show_rto_modal"
      :chat="chat"
      :client="clients.getClientByCode(chat.client_code)"
    />
  </div>
  <div v-else class="relative mt-3 w-full"></div>
</template>

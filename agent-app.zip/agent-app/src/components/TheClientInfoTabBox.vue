<script setup>
import { useChatsStore } from '@/stores/chats';
import { useClientsStore } from '@/stores/clients';
import BaseLink from '@/components/BaseLink.vue';
import BaseTabButton from '@/components/BaseTabButton.vue';
import BaseTextMessage from '@/components/BaseTextMessage.vue';

const chats = useChatsStore();
const clients = useClientsStore();

let activeTab = $ref('client_summary');

function openFaqInFaqSeach(faqId) {
  new BroadcastChannel('faq_search_open_faq').postMessage(faqId);

  console.debug('[BroadcastChannel:faq_search_open_faq]', faqId);
}
</script>

<template>
  <div class="relative top-0.5 flex shrink-0">
    <BaseTabButton
      size="sm"
      :active="activeTab === 'client_summary'"
      @click="activeTab = 'client_summary'"
    >
      Client Summary
    </BaseTabButton>
    <BaseTabButton
      class="ml-3"
      size="sm"
      :active="activeTab === 'client_strategy'"
      @click="activeTab = 'client_strategy'"
    >
      Client Strategy
    </BaseTabButton>
    <BaseTabButton
      class="ml-3"
      size="sm"
      :active="activeTab === 'top_faqs'"
      @click="activeTab = 'top_faqs'"
    >
      Top FAQs
    </BaseTabButton>
  </div>

  <div
    v-if="activeTab === 'client_summary'"
    class="laptop:h-[186px] h-[170px] shrink-0 flex-col overflow-y-auto rounded-md rounded-t-none border-2 border-gray-200 bg-white p-3 mb-3"
  >
    <div v-if="!chats.activeChat" class="h-full">
      <BaseTextMessage>Open a chat to view client summary</BaseTextMessage>
    </div>
    <div v-else class="html-section">
      <p v-if="clients.activeClient.gdpr_compliant" class="text-rose-500 font-bold">
        This client is GDPR-compliant.
      </p>
      <div v-html="clients.activeClient.summary"></div>
    </div>
  </div>

  <div
    v-if="activeTab === 'client_strategy'"
    class="laptop:h-[186px] h-[170px] shrink-0 flex-col overflow-y-auto rounded-md rounded-t-none border-2 border-gray-200 bg-white p-3 mb-3"
  >
    <div v-if="!chats.activeChat" class="h-full">
      <BaseTextMessage>Open a chat to view client strategy</BaseTextMessage>
    </div>
    <div
      v-else-if="clients.activeClient.strategy"
      class="html-section"
      v-html="clients.activeClient.strategy"
    ></div>
    <div v-else class="h-full">
      <BaseTextMessage>There is no specific strategy at the moment</BaseTextMessage>
    </div>
  </div>

  <div
    v-if="activeTab === 'top_faqs'"
    class="laptop:h-[186px] h-[170px] shrink-0 select-none flex-col overflow-y-auto rounded-md rounded-t-none border-2 border-gray-200 bg-white p-3 mb-3"
  >
    <div v-if="!chats.activeChat" class="h-full">
      <BaseTextMessage>Open a chat to view top FAQs</BaseTextMessage>
    </div>
    <div v-else-if="clients.activeClient.top_faqs.length" class="flex flex-col">
      <div v-for="(faq, index) in clients.activeClient.top_faqs" :key="faq.id" class="flex">
        <BaseLink to="javascript:void(0);" class="font-medium" @click="openFaqInFaqSeach(faq.id)">
          {{ index + 1 }}. {{ faq.title }}
        </BaseLink>
      </div>
    </div>
    <div v-else class="h-full">
      <BaseTextMessage>There are no top FAQs at the moment</BaseTextMessage>
    </div>
  </div>
</template>

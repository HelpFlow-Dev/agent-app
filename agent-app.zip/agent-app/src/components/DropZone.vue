<script setup>
import TransitionBlurIn from '@/components/TransitionBlurIn.vue';

defineProps({
  show: {
    type: Boolean,
    default: false,
  },
});

const emit = defineEmits(['files-dropped']);

function onDrop(e) {
  emit('files-dropped', [...e.dataTransfer.files]);
}
</script>

<template>
  <TransitionBlurIn>
    <div
      v-show="show"
      class="absolute inset-0 z-30 bg-white/75 p-3 backdrop-blur"
      @drop.prevent="onDrop"
    >
      <div
        class="pointer-events-none flex h-full w-full flex-col items-center justify-center rounded-md border-4 border-dashed border-blue-500"
      >
        <div class="font-semibold">Drop files to upload</div>
        <div class="text-gray-500">Maximum file size is 100MB</div>
      </div>
    </div>
  </TransitionBlurIn>
</template>

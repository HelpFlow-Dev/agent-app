<script>
export default {
  inheritAttrs: false,
};
</script>

<script setup>
import { computed } from 'vue';
import { RouterLink } from 'vue-router';
import { useToast } from '@/stores/toasts';

const toast = useToast();

const props = defineProps({
  ...RouterLink.props,
  variant: {
    type: String,
    default: 'blue',
    validator(value) {
      // The value must match one of these strings
      return ['blue', 'black'].includes(value);
    },
  },
  disabled: {
    type: Boolean,
    default: false,
  },
  useCopyToClipboard: {
    type: Boolean,
    default: false,
  },
  copyToClipboardValue: {
    type: [Number, String],
    default: null,
  },
  useDefaultPadding: {
    type: Boolean,
    default: true,
  },
  showExternalLinkIcon: {
    type: Boolean,
    default: false,
  },
  showDownloadIcon: {
    type: Boolean,
    default: false,
  },
});

const linkText = $ref(null);

const isPlaceholderLink = computed(() => {
  return typeof props.to === 'string' && props.to.startsWith('javascript:');
});

const isExternalLink = computed(() => {
  return (
    typeof props.to === 'string' && (props.to.startsWith('http') || props.to.startsWith('mailto'))
  );
});

function copyToClipboard() {
  let text = linkText.textContent.trim();

  if (props.copyToClipboardValue !== null) {
    text = props.copyToClipboardValue;
  }

  if (navigator.clipboard) {
    navigator.clipboard.writeText(text);

    toast.copiedToClipBoard();
  } else {
    toast.copyToClipBoardFailed();
  }
}
</script>

<template>
  <a
    v-if="isPlaceholderLink"
    v-bind="$attrs"
    :href="to"
    ref="linkText"
    class="rounded-sm no-underline transition hover:bg-blue-100 hover:text-blue-500 active:bg-blue-200"
    draggable="false"
    :class="{
      'text-blue-500': variant === 'blue',
      'px-1 py-px': useDefaultPadding,
      'pointer-events-none opacity-50': disabled,
    }"
    tabindex="-1"
    @click="useCopyToClipboard ? copyToClipboard() : null"
  >
    <slot></slot>
    <i v-if="useCopyToClipboard" class="fa-regular fa-copy ml-1"></i>
    <i v-if="showDownloadIcon" class="fa-solid fa-circle-down ml-1"></i>
  </a>

  <a
    v-else-if="isExternalLink"
    v-bind="$attrs"
    :href="to"
    target="_blank"
    class="rounded-sm no-underline transition hover:bg-blue-100 hover:text-blue-500 active:bg-blue-200"
    :class="{
      'text-blue-500': variant === 'blue',
      'px-1 py-px': useDefaultPadding,
      'pointer-events-none opacity-50': disabled,
    }"
    tabindex="-1"
  >
    <slot></slot>
    <i v-if="showExternalLinkIcon" class="fa-solid fa-square-arrow-up-right ml-0.5"></i>
    <i v-if="showDownloadIcon" class="fa-solid fa-circle-down ml-1"></i>
  </a>

  <RouterLink v-else v-bind="$props" custom v-slot="{ isActive, href, navigate }">
    <a
      v-bind="$attrs"
      :href="href"
      class="select-none rounded-sm border-transparent no-underline transition hover:bg-blue-100 hover:text-blue-500 active:bg-blue-200"
      :class="{
        'pointer-events-none opacity-50': isActive || disabled,
        'text-blue-500': variant === 'blue',
        'px-1 py-px': useDefaultPadding,
      }"
      tabindex="-1"
      @click="navigate"
    >
      <slot></slot>
    </a>
  </RouterLink>
</template>

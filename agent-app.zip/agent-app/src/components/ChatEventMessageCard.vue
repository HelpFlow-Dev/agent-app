<script setup>
import ChatEventMessageMeta from '@/components/ChatEventMessageMeta';

defineProps({
  chat: {
    type: Object,
    required: true,
  },
  event: {
    type: Object,
    required: true,
  },
});

function getButtons(element) {
  if (element.buttons && element.buttons.length) return element.buttons;

  return [];
}
</script>

<template>
  <div v-for="(element, index) in event.elements" :key="index" class="flex flex-col">
    <div class="flex w-fit flex-col rounded-lg border border-gray-200 bg-white">
      <div
        v-if="element.image"
        class="pointer-events-none select-none rounded-t-lg border-b border-gray-200"
      >
        <img
          class="h-[150px] w-full rounded-t-md object-cover"
          :src="element.image.url"
          :alt="element.image.alternative_text"
        />
      </div>

      <div v-if="element.title" class="p-3">
        {{ element.title }}
      </div>

      <div v-if="element.subtitle" class="p-3 text-gray-400" :class="{ '-mt-3': element.title }">
        {{ element.subtitle }}
      </div>

      <div
        v-for="(button, index) in getButtons(element)"
        :key="index"
        class="border-t border-gray-200 p-3 text-center text-gray-400"
        v-text="button.text"
      ></div>
    </div>

    <ChatEventMessageMeta class="text-gray-400" :chat="chat" :event="event" />
  </div>
</template>

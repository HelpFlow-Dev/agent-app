<script setup></script>

<template>
  <div class="mb-3 text-2xl font-bold">
    <slot></slot>
  </div>
</template>

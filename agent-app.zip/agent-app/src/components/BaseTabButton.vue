<script setup>
defineProps({
  active: {
    type: Boolean,
    required: true,
  },
});
</script>

<template>
  <div
    class="flex-1 cursor-pointer select-none rounded-t-md border-2 px-1 py-1.5 text-center font-semibold transition hover:border-blue-500 hover:bg-blue-100 hover:text-blue-500"
    :class="{
      'pointer-events-none border-blue-600 bg-blue-500 text-white': active,
      'bg-white': !active,
    }"
  >
    <slot></slot>
  </div>
</template>

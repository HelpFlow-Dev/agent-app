<script setup>
defineProps({
  unreadMessagesCount: {
    type: Number,
    required: true,
  },
});
</script>

<template>
  <div id="unread-messages-banner" class="my-3 flex w-full items-center justify-center">
    <div class="flex w-full shrink-0 border-y bg-gray-100 px-3 py-1 leading-6 text-gray-400">
      <span class="select-none">↓</span>
      <span class="mx-auto">
        {{ unreadMessagesCount }}
        {{ unreadMessagesCount === 1 ? 'new message' : 'new messages' }}
      </span>
      <span class="select-none">↓</span>
    </div>
  </div>
</template>

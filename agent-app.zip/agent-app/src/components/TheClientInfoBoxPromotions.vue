<script setup>
import { useClientsStore } from '@/stores/clients';
import BaseHeading from '@/components/BaseHeading.vue';
import BaseHr from '@/components/BaseHr.vue';
import PromotionList from '@/components/PromotionList.vue';

const clients = useClientsStore();
</script>

<template>
  <div v-if="clients.getActivePromotionsByClientCode(clients.activeClient.code).length">
    <BaseHeading>Active Promotions</BaseHeading>

    <PromotionList
      :promotions="clients.getActivePromotionsByClientCode(clients.activeClient.code)"
    />

    <BaseHr />
  </div>
</template>

<script setup>
defineProps({
  active: {
    type: Boolean,
    required: true,
  },
  disabled: {
    type: Boolean,
    default: false,
  },
});
</script>

<template>
  <div
    class="flex select-none items-center rounded-md border-2 p-3 transition"
    :class="{
      'hover:border-blue-500': !active,
      'border-blue-600 bg-blue-100': active,
      'bg-white': !active,
      'pointer-events-none opacity-50': disabled,
      'cursor-pointer': !disabled,
    }"
  >
    <slot></slot>
  </div>
</template>

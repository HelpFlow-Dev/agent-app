<script setup></script>

<template>
  <div class="Vue-Toastification__toast-body">
    <slot></slot>
  </div>
</template>

<script>
export default {
  inheritAttrs: false,
};
</script>

<script setup>
let dropZoneIsVisible = $ref(false);

defineProps({
  multiple: {
    type: Boolean,
    default: false,
  },
  modelValue: {
    type: [String, Number],
    default: '',
  },
  disabled: {
    type: Boolean,
    default: false,
  },
  ref: {
    type: String,
    default: null,
  },
});

const emit = defineEmits(['update:modelValue']);

function showDropZone() {
  dropZoneIsVisible = true;
}

function hideDropZone() {
  dropZoneIsVisible = false;
}

function onInput(event) {
  emit('update:modelValue', event.target.value);
}
</script>

<template>
  <input
    class="block w-full p-3 border-2 rounded-md cursor-pointer select-none transition disabled:pointer-events-none disabled:bg-gray-100 disabled:opacity-60 text-transparent"
    :class="{
      'border-gray-200 hover:border-blue-500': !dropZoneIsVisible,
      'border-blue-500 border-dashed': dropZoneIsVisible,
    }"
    type="file"
    v-bind="$attrs"
    :value="modelValue"
    :disabled="disabled"
    :multiple="multiple"
    title=""
    @dragenter="showDropZone()"
    @dragover="showDropZone()"
    @dragleave="hideDropZone()"
    @drop="hideDropZone()"
    @change="onInput"
  />
</template>

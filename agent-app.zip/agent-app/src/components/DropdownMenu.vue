<script setup>
import { inject, onMounted, onUnmounted, watch } from 'vue';
import { useAppStore } from '@/stores/app';

const app = useAppStore();
const emitter = inject('emitter');

const props = defineProps({
  show: {
    type: Boolean,
    default: false,
  },
  position: {
    type: String,
    default: 'left',
    validator(value) {
      // The value must match one of these strings
      return ['left', 'right'].includes(value);
    },
  },
});

const emit = defineEmits(['close']);

watch(() => props.show, handleVisibilityChange);

function handleVisibilityChange() {
  if (props.show) {
    // This is needed to keep app.dropdownMenuOpen boolean state correct
    // for example, when user clicks to open another dropdown when this one is open
    // the new dropdown would open before this one is closed unless we do a timeout
    setTimeout(() => {
      app.dropdownMenuOpen = true;
    }, 0);
  } else {
    app.dropdownMenuOpen = false;
  }
}

onMounted(() => {
  emitter.on('shortcut-close-dropdown-menu', handleDropdownMenuCloseShortcut);
});

onUnmounted(() => {
  if (props.show) app.dropdownMenuOpen = false;

  emitter.off('shortcut-close-dropdown-menu', handleDropdownMenuCloseShortcut);
});

function handleDropdownMenuCloseShortcut() {
  console.debug('[emitter:DropdownMenu] shortcut-close-dropdown-menu');

  emit('close');
}
</script>

<template>
  <div
    v-if="show"
    class="dropdown-menu absolute top-[40px] z-10 mt-1 min-w-[220px] max-w-max select-none rounded-md border-2 border-gray-200 bg-white shadow-xl"
    :class="{ 'left-0': position === 'left', 'right-0': position === 'right' }"
  >
    <slot></slot>
  </div>
</template>

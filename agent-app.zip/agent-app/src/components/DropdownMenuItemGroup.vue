<script setup></script>

<template>
  <div class="flex flex-col py-1.5">
    <slot></slot>
  </div>
</template>

<script setup>
import { DateTime } from 'luxon';
import { useChatsStore } from '@/stores/chats';

const chats = useChatsStore();

defineProps({
  event: {
    type: Object,
    required: true,
  },
});
</script>

<template>
  <div
    class="system-message mt-3 flex w-full items-center justify-center px-3"
    :data-event-id="event.id"
  >
    <div
      class="max-w-full shrink-0 rounded-md border px-1.5 py-0.5 text-center leading-6 text-gray-400"
    >
      <i
        v-if="
          [
            'chat_transferred',
            'routing.assigned_deleted',
            'routing.assigned_disconnected',
            'routing.assigned_inactive',
            'routing.assigned_other',
            'routing.assigned_remotely_signed_out',
            'routing.assigned_signed_out',
          ].includes(event.system_message_type)
        "
        class="fa-fw fa-solid fa-arrow-right mr-0.5"
      ></i>
      <i
        v-else-if="
          event.system_message_type === 'rating.chat_rated' && event.text_vars.score === 'good'
        "
        class="fa-fw fa-regular fa-thumbs-up mr-0.5 text-emerald-500"
      ></i>
      <i
        v-else-if="
          event.system_message_type === 'rating.chat_rated' && event.text_vars.score === 'bad'
        "
        class="fa-fw fa-regular fa-thumbs-down mr-0.5 text-rose-500"
      ></i>
      <i
        v-else-if="chats.chatArchivedEventKeys.includes(event.system_message_type)"
        class="fa-fw fa-solid fa-box-archive mr-0.5"
      ></i>
      <i
        v-else-if="event.system_message_type === 'routing.idle'"
        class="fa-fw fa-regular fa-clock mr-0.5"
      ></i>
      <i
        v-else-if="['agent_joined'].includes(event.system_message_type)"
        class="fa-fw fa-solid fa-headset mr-0.5"
      ></i>
      <i
        v-else-if="chats.chatUnassignedEventKeys.includes(event.system_message_type)"
        class="fa-fw fa-solid fa-plug-circle-xmark mr-0.5"
      ></i>
      <i
        v-else-if="event.system_message_type === 'customer_banned'"
        class="fa-fw fa-solid fa-ban mr-0.5 text-rose-500"
      ></i>

      <span v-html="event.text"></span> at
      <span
        v-tooltip="event.created_at.toLocaleString(DateTime.DATETIME_FULL_WITH_SECONDS)"
        v-text="event.created_at.toLocaleString(DateTime.TIME_WITH_SECONDS)"
      ></span>
    </div>
  </div>
</template>

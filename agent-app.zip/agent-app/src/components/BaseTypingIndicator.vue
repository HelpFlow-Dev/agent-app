<script setup></script>

<template>
  <div
    class="relative inline-block rounded-full border border-slate-200 bg-white px-[5px] py-[6px]"
  >
    <span
      class="animate-typing-indicator float-left m-px block h-[3px] w-[3px] rounded-full bg-slate-600"
    ></span>
    <span
      class="animation-delay-200 animate-typing-indicator float-left m-px block h-[3px] w-[3px] rounded-full bg-slate-600"
    ></span>
    <span
      class="animation-delay-400 animate-typing-indicator float-left m-px block h-[3px] w-[3px] rounded-full bg-slate-600"
    ></span>
  </div>
</template>

<script setup></script>

<template>
  <Transition
    name="opacity"
    enter-from-class="opacity-0"
    enter-to-class="opacity-100"
    enter-active-class="transition duration-200"
    leave-active-class="transition duration-100"
    leave-from-class="opacity-100"
    leave-to-class="opacity-0"
  >
    <slot></slot>
  </Transition>
</template>

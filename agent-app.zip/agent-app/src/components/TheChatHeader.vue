<script setup>
import { inject } from 'vue';
import { useAppStore } from '@/stores/app';
import { useChatsStore } from '@/stores/chats';
import { useClientsStore } from '@/stores/clients';
import BanVisitorModal from '@/components/modals/BanVisitorModal.vue';
import BaseIconButton from '@/components/BaseIconButton.vue';
import BaseLink from '@/components/BaseLink.vue';
import DropdownMenu from '@/components/DropdownMenu.vue';
import DropdownMenuItem from '@/components/DropdownMenuItem.vue';
import DropdownMenuItemGroup from '@/components/DropdownMenuItemGroup.vue';
import SendChatTranscriptModal from '@/components/modals/SendChatTranscriptModal.vue';
import TransferChatModal from '@/components/modals/TransferChatModal.vue';

const app = useAppStore();
const chats = useChatsStore();
const clients = useClientsStore();
const appEnvironment = inject('appEnvironment');

let showBanVisitorModal = $ref(false);
let showChatActionsDropdown = $ref(false);
let showChatTranscriptModal = $ref(false);
let showTransferChatModal = $ref(false);

function hideChatActionsDropdown() {
  showChatActionsDropdown = false;
}

function openTransferChatModal() {
  hideChatActionsDropdown();

  showTransferChatModal = true;
}

function openChatTranscriptModal() {
  hideChatActionsDropdown();

  showChatTranscriptModal = true;
}

function openBanVisitorModal() {
  hideChatActionsDropdown();

  showBanVisitorModal = true;
}

function flagForHelp() {
  hideChatActionsDropdown();

  chats.flagForHelp(chats.activeChat);
}

function openNewChatThread() {
  hideChatActionsDropdown();

  chats.openNewChatThread(chats.activeChat);
}

function askToCloseChat() {
  hideChatActionsDropdown();

  chats.showCloseChatModal(chats.activeChat);
}

function closeChat() {
  hideChatActionsDropdown();

  // Without confirmation modal
  chats.stopAndCloseChat(chats.activeChat);
}

function closeSupervisedChat() {
  hideChatActionsDropdown();

  // Without confirmation modal
  chats.stopAndCloseSupervisedChat(chats.activeChat);
}

function sendGoogleAnalyticsEvent() {
  chats.sendGoogleAnalyticsEvent(chats.activeChat, clients.activeClient);

  hideChatActionsDropdown();
}
</script>

<template>
  <div class="relative flex shrink-0 items-center border-b-2 border-gray-200 p-3">
    <div
      class="absolute inset-x-0 mx-auto flex max-w-[80%] flex-col flex-wrap justify-center text-center font-semibold leading-5"
      :class="{ '-mt-px': chats.activeChat.visitor.is_loaded && chats.activeChat.visitor.email }"
    >
      <div class="flex w-full justify-center">
        <div v-if="!chats.activeChat.visitor.is_loaded" class="truncate">Loading visitor...</div>
        <div
          v-else
          class="truncate"
          :class="{ 'text-rose-500': chats.activeChat.visitor.banned_until }"
          v-tooltip="
            chats.activeChat.visitor.banned_until
              ? 'This visitor is banned (ban ends ' +
                chats.activeChat.visitor.banned_until.toRelative() +
                ')'
              : ''
          "
        >
          <span
            v-if="
              chats.activeChat.threads[chats.activeChatCurrentThreadId].rating === 'good' ||
              chats.activeChat.threads[chats.activeChatCurrentThreadId].rating === 'bad'
            "
            class="mr-1.5"
          >
            <i
              v-if="chats.activeChat.threads[chats.activeChatCurrentThreadId].rating === 'good'"
              class="fa-regular fa-thumbs-up text-[18px] text-emerald-500"
              v-tooltip="'Visitor rated the chat as good'"
            ></i>
            <i
              v-if="chats.activeChat.threads[chats.activeChatCurrentThreadId].rating === 'bad'"
              class="fa-regular fa-thumbs-down text-[18px] text-rose-500"
              v-tooltip="'Visitor rated the chat as bad'"
            ></i>
          </span>
          <span>
            {{ chats.activeChat.visitor.name }}

            <BaseLink
              to="javascript:void(0);"
              class="max-w-[500px] select-none truncate"
              v-tooltip="chats.activeChat.visitor.id"
              :copy-to-clipboard-value="chats.activeChat.visitor.id"
              :use-copy-to-clipboard="true"
              >ID</BaseLink
            >
          </span>
        </div>
      </div>

      <div
        v-if="chats.activeChat.visitor.is_loaded && chats.activeChat.visitor.email"
        class="flex justify-center"
      >
        <BaseLink
          to="javascript:void(0);"
          class="-ml-1 max-w-[500px] truncate"
          v-tooltip="'Copy to clipboard'"
          :use-copy-to-clipboard="true"
          >{{ chats.activeChat.visitor.email }}</BaseLink
        >
      </div>
    </div>

    <div class="relative mr-auto">
      <BaseIconButton
        class="mr-auto"
        :class="{
          'fa-solid fa-star': chats.activeChat.is_important,
          'fa-regular fa-star': !chats.activeChat.is_important,
        }"
        variant="warning"
        v-tooltip="
          chats.activeChat.is_important
            ? 'This chat marked as important, click to mark as not important'
            : 'Mark chat as important'
        "
        :active="chats.activeChat.is_important"
        @click="chats.toggleImportantStatus(chats.activeChatId)"
      ></BaseIconButton>
    </div>

    <div class="relative ml-auto">
      <BaseIconButton
        class="fa-solid fa-ellipsis ml-auto"
        :active="showChatActionsDropdown"
        @click="showChatActionsDropdown = !showChatActionsDropdown"
      ></BaseIconButton>

      <DropdownMenu
        :show="showChatActionsDropdown"
        position="right"
        v-click-outside="hideChatActionsDropdown"
        @close="hideChatActionsDropdown"
      >
        <DropdownMenuItemGroup
          v-if="
            chats.activeChat.status !== 'supervising' &&
            chats.activeChat.is_deactivated &&
            !chats.activeChat.is_transferred &&
            !chats.activeChat.is_unassigned &&
            !chats.activeChat.visitor.banned_until
          "
          class="border-b-2"
        >
          <DropdownMenuItem
            icon="fa-regular fa-paper-plane"
            :disabled="!app.online || !app.livechatOnline"
            @click="openNewChatThread"
          >
            Start a new chat
          </DropdownMenuItem>

          <DropdownMenuItem
            v-if="appEnvironment !== 'production'"
            icon="fa-regular fa-envelope"
            :disabled="!app.online || !app.livechatOnline"
            @click="openChatTranscriptModal"
          >
            Send chat transcript
          </DropdownMenuItem>
        </DropdownMenuItemGroup>

        <DropdownMenuItemGroup
          v-if="
            chats.activeChat.status !== 'supervising' &&
            !chats.activeChat.is_deactivated &&
            !chats.activeChat.is_transferred &&
            !chats.activeChat.is_unassigned
          "
          class="border-b-2"
        >
          <DropdownMenuItem
            icon="fa-solid fa-arrow-right"
            :disabled="!app.online || !app.livechatOnline"
            @click="openTransferChatModal"
          >
            Transfer chat
          </DropdownMenuItem>

          <!-- <DropdownMenuItem
            icon="fa-solid fa-ticket"
            :disabled="!app.online || !app.livechatOnline"
            @click="hideChatActionsDropdown"
          >
            Create ticket
          </DropdownMenuItem> -->

          <DropdownMenuItem
            icon="fa-regular fa-flag"
            :disabled="!app.online || !app.livechatOnline"
            @click="flagForHelp"
          >
            Flag for help
          </DropdownMenuItem>
        </DropdownMenuItemGroup>

        <DropdownMenuItemGroup
          v-if="clients.activeClient.ga_event_tracking_enabled && chats.activeChat.status !== 'supervising'"
          class="border-b-2"
        >
          <DropdownMenuItem
            icon="fa-brands fa-google"
            :disabled="chats.activeChat.ga_event_sent"
            @click="sendGoogleAnalyticsEvent"
          >
            <span v-if="chats.activeChat.ga_event_sent">GA Event is logged</span>
            <span v-else>Log "{{ clients.activeClient.ga_event_label }}" GA Event</span>
          </DropdownMenuItem>
        </DropdownMenuItemGroup>

        <!-- This group is always visible because at least one item is always visible -->
        <DropdownMenuItemGroup>
          <DropdownMenuItem
            v-if="
              chats.activeChat.status !== 'supervising' &&
              !chats.activeChat.visitor.banned_until
            "
            :disabled="!app.online || !app.livechatOnline || !chats.activeChat.visitor.is_loaded"
            icon="fa-solid fa-ban"
            @click="openBanVisitorModal"
          >
            Ban visitor
          </DropdownMenuItem>

          <DropdownMenuItem
            v-if="chats.activeChat.status === 'supervising'"
            icon="fa-regular fa-circle-xmark"
            :disabled="!app.online || !app.livechatOnline"
            @click="chats.activeChat.is_deactivated ? closeSupervisedChat() : askToCloseChat()"
          >
            {{ chats.activeChat.is_deactivated ? 'Close chat' : 'Stop supervising' }}
          </DropdownMenuItem>

          <DropdownMenuItem
            v-if="chats.activeChat.status !== 'supervising'"
            icon="fa-regular fa-circle-xmark"
            :disabled="!app.online || !app.livechatOnline"
            @click="askToCloseChat"
          >
            {{ chats.activeChat.is_deactivated ? 'Close this chat' : 'Stop this chat' }}
          </DropdownMenuItem>
        </DropdownMenuItemGroup>
      </DropdownMenu>
    </div>
  </div>

  <SendChatTranscriptModal
    :show="showChatTranscriptModal"
    @close="showChatTranscriptModal = false"
  />
  <BanVisitorModal :show="showBanVisitorModal" @close="showBanVisitorModal = false" />
  <TransferChatModal :show="showTransferChatModal" @close="showTransferChatModal = false" />
</template>

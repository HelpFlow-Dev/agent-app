<script setup>
import { inject, nextTick, onMounted, onUnmounted, watch } from 'vue';
import { useCannedResponsesStore } from '@/stores/cannedResponses';
import { useClientsStore } from '@/stores/clients';
import BaseTextMessage from '@/components/BaseTextMessage.vue';

const appEnvironment = inject('appEnvironment');
const emitter = inject('emitter');
const clients = useClientsStore();
const cannedResponses = useCannedResponsesStore();

const props = defineProps({
  show: {
    type: Boolean,
    default: false,
  },
  searchTerm: {
    type: String,
    default: '',
  },
});

const emit = defineEmits(['picked', 'closed']);

let currentShortcut = $ref(null);
let focusedShortcutIndex = $ref(0);
let focusedCannedResponseIndex = $ref(0);
let cannedResponsesContainerElement = $ref(null);
let cannedResponsesElements = $ref([]);
let shortcutsContainerElement = $ref(null);
let shortcutElements = $ref([]);
let shortcutsScrollPosition = $ref(0);

onMounted(() => {
  emitter.on('cannedResponsesPickerKeydownUp', () => {
    if (appEnvironment !== 'production') console.debug('[emitter:CannedResponsePicker] cannedResponsesPickerKeydownUp');

    if (currentShortcut === null) {
      focusOnPreviousShortcut();
    } else {
      focusOnPreviousCannedResponse();
    }
  });

  emitter.on('cannedResponsesPickerKeydownDown', () => {
    if (appEnvironment !== 'production') console.debug('[emitter:CannedResponsePicker] cannedResponsesPickerKeydownDown');

    if (currentShortcut === null) {
      focusOnNextShortcut();
    } else {
      focusOnNextCannedResponse();
    }
  });

  emitter.on('cannedResponsesPickerKeydownLeft', () => {
    if (appEnvironment !== 'production') console.debug('[emitter:CannedResponsePicker] cannedResponsesPickerKeydownLeft');

    if (currentShortcut === null) {
      emit('closed');
    } else {
      goBackToShortcuts();
    }
  });

  emitter.on('cannedResponsesPickerKeydownRight', () => {
    if (appEnvironment !== 'production') console.debug('[emitter:CannedResponsePicker] cannedResponsesPickerKeydownRight');

    if (currentShortcut === null) {
      openFocusedShortcut();
    } else {
      pickCannedResponseByIndex(focusedCannedResponseIndex);
    }
  });

  emitter.on('cannedResponsesPickerKeydownEnter', () => {
    if (appEnvironment !== 'production') console.debug('[emitter:CannedResponsePicker] cannedResponsesPickerKeydownEnter');

    if (currentShortcut === null) {
      openFocusedShortcut();
    } else {
      pickCannedResponseByIndex(focusedCannedResponseIndex);
    }
  });
});

onUnmounted(() => {
  emitter.off('cannedResponsesPickerKeydownUp');
  emitter.off('cannedResponsesPickerKeydownDown');
  emitter.off('cannedResponsesPickerKeydownLeft');
  emitter.off('cannedResponsesPickerKeydownRight');
  emitter.off('cannedResponsesPickerKeydownEnter');
});

watch(() => props.show, handlePickerVisiblityChange);
watch(() => props.searchTerm, handleSearch);

function handlePickerVisiblityChange() {
  if (!props.show) {
    currentShortcut = null;
    shortcutsScrollPosition = 0;
    focusedShortcutIndex = 0;
    focusedCannedResponseIndex = 0;
  }
}

function getCannedResponseForCurrentShortcutByIndex(index) {
  let responses = cannedResponses.getCannedResponsesForShortcut(
    currentShortcut,
    clients.activeClientId
  );

  return responses[index];
}

function handleSearch() {
  shortcutsScrollPosition = 0;

  // If index doesn't exist anymore we'll reset it to 0
  if (
    typeof Object.keys(
      cannedResponses.getFilteredShortcuts(props.searchTerm, clients.activeClientId)
    )[focusedShortcutIndex] === 'undefined'
  ) {
    focusedShortcutIndex = 0;
  }

  // If there's only one shortcut remaining, we'll open it
  if (
    Object.keys(cannedResponses.getFilteredShortcuts(props.searchTerm, clients.activeClientId))
      .length === 1
  ) {
    openShortcut(
      Object.keys(cannedResponses.getFilteredShortcuts(props.searchTerm, clients.activeClientId))[0]
    );
  } else {
    goBackToShortcuts();
  }
}

function focusOnNextShortcut() {
  if (focusedShortcutIndex !== null) {
    focusedShortcutIndex++;

    // If there's no next item, focus on the first one
    if (
      focusedShortcutIndex >
      Object.keys(cannedResponses.getFilteredShortcuts(props.searchTerm, clients.activeClientId))
        .length -
        1
    ) {
      focusedShortcutIndex = 0;
    }
  } else {
    focusedShortcutIndex = 0;
  }

  nextTick(() => {
    if (
      shortcutsContainerElement &&
      focusedShortcutIndex ===
        Object.keys(cannedResponses.getFilteredShortcuts(props.searchTerm, clients.activeClientId))
          .length -
          1
    ) {
      shortcutsContainerElement.scrollTop = shortcutsContainerElement.scrollHeight;
    } else if (shortcutElements[focusedShortcutIndex]) {
      shortcutElements[focusedShortcutIndex].scrollIntoView({ behavior: 'instant', block: 'end' });
    }
  });
}

function focusOnPreviousShortcut() {
  if (focusedShortcutIndex) {
    focusedShortcutIndex--;
  } else {
    // If there is no previous item, focus on the last one
    focusedShortcutIndex =
      Object.keys(cannedResponses.getFilteredShortcuts(props.searchTerm, clients.activeClientId))
        .length - 1;
  }

  nextTick(() => {
    if (
      shortcutsContainerElement &&
      focusedShortcutIndex ===
        Object.keys(cannedResponses.getFilteredShortcuts(props.searchTerm, clients.activeClientId))
          .length -
          1
    ) {
      shortcutsContainerElement.scrollTop = shortcutsContainerElement.scrollHeight;
    } else if (shortcutElements[focusedShortcutIndex]) {
      shortcutElements[focusedShortcutIndex].scrollIntoView({ behavior: 'instant', block: 'end' });
    }
  });
}

function focusOnNextCannedResponse() {
  if (focusedCannedResponseIndex !== null) {
    focusedCannedResponseIndex++;

    // If there's no next item, focus on the first one
    if (
      focusedCannedResponseIndex >
      cannedResponses.getCannedResponsesForShortcut(currentShortcut, clients.activeClientId)
        .length -
        1
    ) {
      focusedCannedResponseIndex = 0;
    }
  } else {
    focusedCannedResponseIndex = 0;
  }

  nextTick(() => {
    if (
      cannedResponsesContainerElement &&
      focusedCannedResponseIndex ===
        cannedResponses.getCannedResponsesForShortcut(currentShortcut, clients.activeClientId)
          .length -
          1
    ) {
      cannedResponsesContainerElement.scrollTop = cannedResponsesContainerElement.scrollHeight;
    } else if (cannedResponsesElements[focusedCannedResponseIndex]) {
      cannedResponsesElements[focusedCannedResponseIndex].scrollIntoView({
        behavior: 'instant',
        block: 'end',
      });
    }
  });
}

function focusOnPreviousCannedResponse() {
  if (focusedCannedResponseIndex) {
    focusedCannedResponseIndex--;
  } else {
    // If there is no previous item, focus on the last one
    focusedCannedResponseIndex =
      cannedResponses.getCannedResponsesForShortcut(currentShortcut, clients.activeClientId)
        .length - 1;
  }

  nextTick(() => {
    if (
      cannedResponsesContainerElement &&
      focusedCannedResponseIndex ===
        cannedResponses.getCannedResponsesForShortcut(currentShortcut, clients.activeClientId)
          .length -
          1
    ) {
      cannedResponsesContainerElement.scrollTop = cannedResponsesContainerElement.scrollHeight;
    } else if (cannedResponsesElements[focusedCannedResponseIndex]) {
      cannedResponsesElements[focusedCannedResponseIndex].scrollIntoView({
        behavior: 'instant',
        block: 'end',
      });
    }
  });
}

function openFocusedShortcut() {
  openShortcut(
    Object.keys(cannedResponses.getFilteredShortcuts(props.searchTerm, clients.activeClientId))[
      focusedShortcutIndex
    ]
  );
}

function openShortcut(shortcut) {
  currentShortcut = shortcut;
}

function goBackToShortcuts() {
  currentShortcut = null;
  focusedCannedResponseIndex = 0;

  nextTick(() => {
    if (shortcutsContainerElement) {
      shortcutsContainerElement.scrollTop = shortcutsScrollPosition;
    }
  });
}

function pickCannedResponseByIndex(index) {
  let cannedResponse = getCannedResponseForCurrentShortcutByIndex(index);

  emit('picked', cannedResponse);
}

function pickCannedResponse(cannedResponse) {
  emit('picked', cannedResponse);
}
</script>

<template>
  <div
    v-if="show"
    class="desktop:max-h-[475px] desktop:w-[525px] absolute bottom-full left-0 z-10 -mb-3 ml-3 flex max-h-[425px] w-[475px] select-none flex-col rounded-md border-2 border-gray-200 bg-white shadow-xl"
  >
    <!-- Viewing list of shortcuts (that is not empty) -->
    <div
      v-if="
        currentShortcut === null &&
        Object.keys(cannedResponses.getFilteredShortcuts(searchTerm, clients.activeClientId))
          .length > 0
      "
      ref="shortcutsContainerElement"
      class="mx-[-2px] flex flex-col overflow-y-auto py-1.5"
      @scroll="shortcutsScrollPosition = shortcutsContainerElement.scrollTop"
    >
      <div
        v-for="(cannedResponses, shortcut, index) in cannedResponses.getFilteredShortcuts(
          searchTerm,
          clients.activeClientId
        )"
        :key="shortcut"
        ref="shortcutElements"
        class="flex cursor-pointer items-stretch border-x-2 hover:border-blue-500 hover:bg-blue-100 hover:text-blue-500 active:border-blue-500 active:bg-blue-100 active:text-blue-500"
        :class="{
          'border-gray-200': focusedShortcutIndex !== index,
          'border-blue-500 bg-blue-100 text-blue-500': focusedShortcutIndex === index,
        }"
        @mouseover="focusedShortcutIndex = index"
        @click="openShortcut(shortcut)"
      >
        <div class="w-full truncate px-3 py-1.5">{{ shortcut }}</div>

        <div v-if="cannedResponses.length > 1" class="ml-auto flex shrink-0 items-center">
          {{ cannedResponses.length }}
        </div>

        <div class="flex shrink-0 items-center justify-center px-3 py-1.5 text-center">
          <i class="fa-solid fa-caret-right"></i>
        </div>
      </div>
    </div>

    <!-- Viewing list of shortcuts (that is empty) -->
    <div
      v-if="
        currentShortcut === null &&
        Object.keys(cannedResponses.getFilteredShortcuts(searchTerm, clients.activeClientId))
          .length === 0
      "
      class="mx-[-2px] flex flex-col overflow-y-auto py-3"
    >
      <BaseTextMessage v-if="searchTerm">Nothing found</BaseTextMessage>
      <BaseTextMessage v-else>No canned responses available</BaseTextMessage>
    </div>

    <!-- Shortcut is open, viewing list of replies -->
    <div
      v-if="currentShortcut"
      ref="cannedResponsesContainerElement"
      class="mx-[-2px] flex flex-col overflow-y-auto py-1.5"
    >
      <div
        v-for="(cannedResponse, index) in cannedResponses.getCannedResponsesForShortcut(
          currentShortcut,
          clients.activeClientId
        )"
        :key="cannedResponse.id"
        ref="cannedResponsesElements"
        class="flex cursor-pointer items-stretch border-x-2 hover:border-blue-500 hover:bg-blue-100 hover:text-blue-500 active:border-blue-500 active:bg-blue-100 active:text-blue-500"
        :class="{
          'border-gray-200': focusedCannedResponseIndex !== index,
          'border-blue-500 bg-blue-100 text-blue-500': focusedCannedResponseIndex === index,
        }"
        @mouseover="focusedCannedResponseIndex = index"
      >
        <div
          class="relative flex shrink-0 items-center justify-center px-3 py-1.5 text-center"
          @click="goBackToShortcuts"
        >
          <i class="fa-solid fa-caret-left"></i>
        </div>

        <div
          class="flex w-full whitespace-pre-wrap py-1.5 pr-1.5"
          @click="pickCannedResponse(cannedResponse)"
        >
          <div class="flex items-center">{{ cannedResponse.response_text }}</div>
          <div class="ml-auto flex flex-col items-start pl-1.5">
            <span
              class="w-full min-w-[72px] whitespace-nowrap rounded-md bg-gray-400 p-1 text-center text-sm tracking-tight text-white"
              >{{
                cannedResponse.client_id
                  ? clients.getClient(cannedResponse.client_id).code
                  : 'All clients'
              }}</span
            >
            <span
              class="mt-1.5 w-full min-w-[72px] whitespace-nowrap rounded-md bg-gray-400 p-1 text-center text-sm tracking-tight text-white"
              >{{ !cannedResponse.user_id ? 'Shared' : 'Private' }}</span
            >
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

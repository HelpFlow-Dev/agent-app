<script setup>
import { computed, inject } from 'vue';
import { livechatClientId } from '@/helpers';
import { useAgentsStore } from '@/stores/agents';
import { useCopilot } from '@/stores/copilot';
import { useChatsStore } from '@/stores/chats';
import BaseAvatar from '@/components/BaseAvatar';
import ChatEventMessageBubble from '@/components/ChatEventMessageBubble';
import ChatEventMessageFile from '@/components/ChatEventMessageFile';
import ChatEventMessageForm from '@/components/ChatEventMessageForm';
import EmojiReactionPickerMenu from '@/components/EmojiReactionPickerMenu';

const agents = useAgentsStore();
const chats = useChatsStore();
const copilot = useCopilot();
const emitter = inject('emitter');

let emojiReactionPickerOpen = $ref(false);

const props = defineProps({
  chat: {
    type: Object,
    required: true,
  },
  event: {
    type: Object,
    required: true,
  },
  sameAuthorAsPreviousEvent: {
    type: Boolean,
    required: true,
  },
});

const hasEmojiReaction = computed(() => {
  if (props.event.properties && props.event.properties[livechatClientId] && props.event.properties[livechatClientId].message_reaction) {
    return true;
  }

  return false;
});

const canSetEmojiReaction = computed(() => {
  // Cannot update reactions if chat doesn't belong to auth agent
  if (props.chat.status === 'supervising' || props.chat.is_deactivated || props.chat.is_unassigned) {
    return false;
  }

  // Cannot update reactions set by other agents
  if (props.event.properties
      && props.event.properties[livechatClientId]
      && props.event.properties[livechatClientId].message_reaction
      && props.event.properties[livechatClientId].message_reaction_author
  ) {
    return props.event.properties[livechatClientId].message_reaction_author === agents.agent.livechat_id;
  }

  return true;
});


const emojiReactionButtonTooltip = computed(() => {
  if (hasEmojiReaction.value) {
    return 'Visitor will see this reaction to their message';
  } else if (canSetEmojiReaction.value) {
    return 'Leave a reaction to visitor\'s message';
  }

  return '';
});

function toggleCopilot() {
  if (copilot.show && copilot.isOpenForEvent(props.event)) {
    copilot.close();
  } else {
    copilot.open(props.event);
  }
}

function openCopilotAndGenerateAnswer() {
  copilot.open(props.event, true);
}

async function handleReactionEmojiPicked(reaction) {
  hideReactionEmojiPicker();

  if (!canSetEmojiReaction.value) return;

  // If the same reaction is picked then we need to remove the reaction
  if (hasEmojiReaction.value && props.event.properties[livechatClientId].message_reaction === reaction) {
    reaction = '';
  }

  await chats.setMessageReaction(props.chat, props.event, reaction);
}

function hideReactionEmojiPicker() {
  emojiReactionPickerOpen = false;
}

function toggleReactionEmojiPicker() {
  if (!canSetEmojiReaction.value) {
    hideReactionEmojiPicker();
    return;
  }

  emojiReactionPickerOpen = !emojiReactionPickerOpen;
}
</script>

<template>
  <div
    class="visitor-message relative flex flex-col items-start px-3"
    :class="{ 'mt-1.5': sameAuthorAsPreviousEvent, 'mt-3': !sameAuthorAsPreviousEvent }"
    :data-event-id="event.id"
  >
    <!-- Visitor name -->
    <div v-if="!sameAuthorAsPreviousEvent" class="ml-10 inline-flex p-px text-sm text-gray-400">
      {{ chat.visitor.name }}
    </div>

    <div class="relative ml-10 flex max-w-[66%]">
      <!-- Avatar -->
      <div class="absolute -ml-10">
        <BaseAvatar v-if="!sameAuthorAsPreviousEvent" variant="visitor" :text="chat.visitor.name" />
      </div>

      <!-- Message -->
      <ChatEventMessageForm v-if="event.type === 'filled_form'" :chat="chat" :event="event" />
      <ChatEventMessageFile v-else-if="event.type === 'file'" :chat="chat" :event="event" />
      <ChatEventMessageBubble v-else :chat="chat" :event="event" />

      <!-- Buttons -->
      <div class="relative flex ml-1.5">
        <!-- Open emoji reaction picker button -->
        <div
          v-if="(event.type === 'message' || event.type === 'file') && chat.client_code !== 'General'"
          class="relative flex"
          :class="{ 'top-[-10px]': event.type === 'file' }"
        >
          <i
            class="relative flex h-[26px] w-[26px] shrink-0 items-center justify-center self-center rounded-md transition select-none"
            :class="{
              'cursor-pointer': canSetEmojiReaction,
              'border border-gray-200': canSetEmojiReaction && hasEmojiReaction,
              'hover:bg-gray-100': canSetEmojiReaction && !emojiReactionPickerOpen,
              'bg-gray-200': emojiReactionPickerOpen,
              'text-blue-500': emojiReactionPickerOpen && !hasEmojiReaction,
              'fa-regular fa-face-smile text-[0.825rem] hover:text-blue-500': !hasEmojiReaction,
              'not-italic': hasEmojiReaction,
            }"
            v-tooltip="emojiReactionButtonTooltip"
            @click="toggleReactionEmojiPicker"
          >{{ hasEmojiReaction ? event.properties[livechatClientId].message_reaction : '' }}</i>

          <EmojiReactionPickerMenu
            :show="emojiReactionPickerOpen && canSetEmojiReaction"
            :current-reaction="hasEmojiReaction ? event.properties[livechatClientId].message_reaction : null"
            v-click-outside="hideReactionEmojiPicker"
            @picked="handleReactionEmojiPicked"
          />
        </div>

        <!-- Suggest FAQ button -->
        <i
          v-if="event.type === 'message' && chat.client_code !== 'General'"
          class="fa-regular fa-flag flex h-[26px] w-[26px] shrink-0 cursor-pointer items-center justify-center self-center rounded-md text-[0.825rem] transition hover:text-blue-500"
          v-tooltip="'Suggest an FAQ using this message'"
          @click="emitter.emit('openSuggestFaqModal', { event: event })"
        ></i>

        <!-- Open Copilot button -->
        <i
          v-if="
            chat.status !== 'supervising' &&
            !chat.is_deactivated &&
            !chat.is_unassigned &&
            (event.type === 'message' || event.type === 'sneak_peek')
          "
          class="fa-solid fa-headset flex h-[26px] w-[26px] shrink-0 cursor-pointer items-center justify-center self-center rounded-md text-[0.825rem] transition"
          :class="{
            'pointer-events-none opacity-30': !copilot.isCurrentEvent(event) && copilot.isLoading,
            'hover:text-blue-500': !copilot.isOpenForEvent(event),
            'bg-gray-200 text-blue-500': copilot.isOpenForEvent(event),
          }"
          v-tooltip="'Toggle Copilot'"
          @click="toggleCopilot"
        ></i>

        <!-- Open Copilot & generate answer button -->
        <i
          v-if="
            chat.status !== 'supervising' &&
            !chat.is_deactivated &&
            !chat.is_unassigned &&
            (event.type === 'message' || event.type === 'sneak_peek')
          "
          class="fa-solid fa-wand-magic-sparkles flex h-[26px] w-[26px] shrink-0 cursor-pointer items-center justify-center self-center rounded-md text-[0.825rem] transition hover:text-violet-500 active:scale-75"
          :class="{
            'pointer-events-none opacity-30': copilot.isLoading,
          }"
          v-tooltip="'Generate Copilot answer from this message'"
          @click="openCopilotAndGenerateAnswer()"
        ></i>
      </div>
    </div>
  </div>
</template>

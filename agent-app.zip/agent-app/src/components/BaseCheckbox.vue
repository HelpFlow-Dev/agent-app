<script>
export default {
  inheritAttrs: false,
};
</script>

<script setup>
import { v4 as uuidv4 } from 'uuid';

const props = defineProps({
  disabled: {
    type: Boolean,
    default: false,
  },
  modelValue: {
    type: [String, Number, Boolean],
    required: true,
  },
  trueValue: {
    type: [String, Number, Boolean],
    default: true,
  },
  falseValue: {
    type: [String, Number, Boolean],
    default: false,
  },
});

let id = uuidv4();

const emit = defineEmits(['update:modelValue']);

function onChange(event) {
  if (event.target.checked) {
    emit('update:modelValue', props.trueValue);
  } else {
    emit('update:modelValue', props.falseValue);
  }
}
</script>

<template>
  <div class="flex" :class="{ 'opacity-50': disabled }">
    <input
      v-bind="$attrs"
      type="checkbox"
      class="absolute hidden"
      :id="id"
      :value="modelValue"
      :checked="modelValue === trueValue"
      :disabled="disabled"
      :true-value="trueValue"
      :false-value="falseValue"
      @change="onChange"
    />
    <label
      class="group flex select-none items-center overflow-hidden rounded py-0.5 transition-all duration-200"
      :class="{ 'cursor-pointer': !disabled, 'pointer-events-none': disabled }"
      :for="id"
    >
      <span
        class="relative h-[18px] w-[18px] shrink-0 scale-100 rounded border transition-all duration-200"
        :class="{
          'animate-checkbox-check border-blue-500 bg-blue-500': modelValue === trueValue,
          'animate-checkbox-uncheck border-gray-200 group-hover:border-blue-500':
            modelValue !== trueValue,
        }"
      >
        <svg
          class="absolute left-[2px] top-[3px] h-[10px] w-[12px] fill-none stroke-white stroke-2"
          :class="{ 'transition-all delay-100 duration-200': modelValue === trueValue }"
          style="
            stroke-linecap: round;
            stroke-linejoin: round;
            stroke-dasharray: 16px;
            transform: translate3d(0, 0, 0);
          "
          :style="{ 'stroke-dashoffset': modelValue === trueValue ? '0' : '16px' }"
        >
          <use :href="'#' + id + '-svg'"></use>
          <symbol viewbox="0 0 12 10">
            <polyline points="1.5 6 4.5 9 10.5 1"></polyline>
          </symbol>
        </svg>
      </span>
      <span class="pl-1.5 leading-[18px]"><slot /></span>
    </label>

    <svg class="pointer-events-none absolute h-0 w-0 select-none">
      <symbol :id="id + '-svg'" viewbox="0 0 12 10">
        <polyline points="1.5 6 4.5 9 10.5 1"></polyline>
      </symbol>
    </svg>
  </div>
</template>

<script setup>
import { useAppStore } from '@/stores/app';
import { useChatsStore } from '@/stores/chats';
import BaseTextMessage from '@/components/BaseTextMessage.vue';
import TheClientInfoBoxAnnouncements from '@/components/TheClientInfoBoxAnnouncements.vue';
import TheClientInfoBoxPromotions from '@/components/TheClientInfoBoxPromotions.vue';

const app = useAppStore();
const chats = useChatsStore();
</script>

<template>
  <div v-if="chats.activeChat">
    <!-- Promotions -->
    <TheClientInfoBoxPromotions />

    <!-- Client Announcements -->
    <TheClientInfoBoxAnnouncements />
  </div>
  <div v-else-if="!chats.activeChat" class="h-full">
    <BaseTextMessage v-if="app.livechatEnabled">Open a chat to view client promotions and announcements</BaseTextMessage>
    <BaseTextMessage v-else>Open a chat to view client details</BaseTextMessage>
  </div>
</template>

<script setup>
defineProps({
  variant: {
    type: String,
    default: 'primary',
    validator(value) {
      // The value must match one of these strings
      return ['primary', 'success', 'danger', 'warning', 'gray-outline'].includes(value);
    },
  },
  show: {
    type: Boolean,
    default: false,
  },
  thinBorder: {
    type: Boolean,
    default: false,
  },
  active: {
    type: Boolean,
    default: false,
  },
  disabled: {
    type: Boolean,
    default: false,
  },
  size: {
    type: String,
    default: 'default',
    validator(value) {
      // The value must match one of these strings
      return ['xs', 'sm', 'default', 'lg-horizontal'].includes(value);
    },
  },
});
</script>

<template>
  <i
    class="flex cursor-pointer items-center justify-center rounded-md transition select-none"
    :class="{
      /* primary */
      'hover:border-blue-500 hover:bg-blue-100 hover:text-blue-500 active:border-blue-500 active:bg-blue-100 active:text-blue-500':
        variant === 'primary' && !active,
      'border-blue-500 bg-blue-100 text-blue-500': variant === 'primary' && active,
      /* success */
      'hover:border-emerald-500 hover:bg-emerald-100 hover:text-emerald-500 active:border-emerald-500 active:bg-emerald-100 active:text-emerald-500':
        variant === 'success' && !active,
      'border-emerald-500 bg-emerald-100 text-emerald-500': variant === 'success' && active,
      /* danger */
      'hover:border-rose-500 hover:bg-rose-100 hover:text-rose-500 active:border-rose-500 active:bg-rose-100 active:text-rose-500':
        variant === 'danger' && !active,
      'border-rose-500 bg-rose-100 text-rose-500': variant === 'danger' && active,
      /* warning */
      'hover:border-yellow-500 hover:bg-yellow-100 hover:text-yellow-500 active:border-yellow-500 active:bg-yellow-100 active:text-yellow-500':
        variant === 'warning' && !active,
      'border-yellow-500 bg-yellow-100 text-yellow-500': variant === 'warning' && active,
      /* gray-outline */
      'hover:border-gray-500 hover:bg-gray-100 hover:text-gray-500 active:border-gray-500 active:bg-gray-100 active:text-gray-500':
        variant === 'gray-outline' && !active,
      'border-gray-500 bg-gray-100 text-gray-500': variant === 'gray-outline' && active,
      'border-gray-200 bg-white': !active,
      /* sizes */
      'h-7 w-7': size === 'xs',
      'h-9 w-9': size === 'sm',
      'h-10 w-10 text-lg': size === 'default',
      'desktop:w-14 h-10 w-12 text-lg': size === 'lg-horizontal',
      /* disabled */
      'pointer-events-none opacity-50': disabled,
      /* inactive */
      'text-gray-900': !active,
      /* border */
      'border': thinBorder,
      'border-2': !thinBorder,
    }"
  ></i>
</template>

<script setup>
import { computed, inject, onMounted, onUnmounted } from 'vue';
import { useAppStore } from '@/stores/app';
import { useChatsStore } from '@/stores/chats';
import { DateTime } from 'luxon';
import AddCannedResponseModal from '@/components/modals/AddCannedResponseModal';
import ChatEvent from '@/components/ChatEvent.vue';
import ChatEventMessageVisitor from '@/components/ChatEventMessageVisitor.vue';
import SuggestFaqModal from '@/components/modals/SuggestFaqModal';

const app = useAppStore();
const chats = useChatsStore();
const appEnvironment = inject('appEnvironment');
const emitter = inject('emitter');

const props = defineProps({
  chat: {
    type: Object,
    required: true,
  },
  events: {
    type: Object,
    required: true,
  },
});

let messageHistoryContainer = $ref(null);
let historyScrolledToEnd = $ref(false);
let showAddCannedResponseModal = $ref(false);
let addCannedResponseModalEvent = $ref(null);
let showSuggestFaqModal = $ref(false);
let suggestFaqModalEvent = $ref(null);

const unreadMessagesCount = computed(() => {
  return chats.getUnreadMessagesCount(props.chat);
});

const firstUnreadMessagesId = computed(() => {
  let firstUnreadMessage = chats.getFirstUnreadMessage(props.chat);

  return firstUnreadMessage ? firstUnreadMessage.id : null;
});

onMounted(() => {
  scrollToUnreadMessages(false, false);

  emitter.on('tabFocused', handleTabFocused);
  emitter.on('chatInputFocused', handleChatInputFocused);
  emitter.on('incomingEvent', handleIncomingEvent);
  emitter.on('incomingSneakPeek', handleIncomingSneakPeek);
  emitter.on('openSuggestFaqModal', openSuggestFaqModal);
  emitter.on('openAddCannedResponseModal', openAddCannedResponseModal);
});

onUnmounted(() => {
  emitter.off('tabFocused', handleTabFocused);
  emitter.off('chatInputFocused', handleChatInputFocused);
  emitter.off('incomingEvent', handleIncomingEvent);
  emitter.off('incomingSneakPeek', handleIncomingSneakPeek);
  emitter.off('openSuggestFaqModal', openSuggestFaqModal);
  emitter.off('openAddCannedResponseModal', openAddCannedResponseModal);
});

async function handleIncomingEvent(data) {
  if (appEnvironment !== 'production')
    console.debug('[emitter:TheChatMessageHistory] incomingEvent', data);

  // We'll scroll to bottom if it's a currently open chat and browser tab is active
  // or there were no unread messages before we received this one
  if ((props.chat.id === data.chat.id && unreadMessagesCount.value === 0) || !document.hidden) {
    // Only if history was scrolled to end before we received a new event we'll scroll to the end
    // in order to not mess with agent scrolling and re-reading chat messages
    // or if it's auth agent's reply
    if (historyScrolledToEnd || data.event.author_is_auth_agent) {
      scrollToBottom();
    }
  }
}
async function handleIncomingSneakPeek(data) {
  if (appEnvironment !== 'production')
    console.debug('[emitter:TheChatMessageHistory] incomingSneakPeek', data);

  // Only if history was scrolled to end before we received a sneak peek we'll scroll to the end
  if (historyScrolledToEnd) {
    // We'll scroll to bottom to see the sneak peek
    // if it's a currently open chat and browser tab is active, or there are no new messages
    if ((props.chat.id === data.chat.id && unreadMessagesCount.value === 0) || !document.hidden) {
      scrollToBottom();
    }
  }
}

function scrollToUnreadMessages(smooth, scrollToEnd) {
  let banner = document.getElementById('unread-messages-banner');

  if (banner && unreadMessagesCount.value) {
    // If there are unread messages we'll scroll to the unread messages banner
    banner.scrollIntoView({
      behavior: smooth === false ? 'instant' : 'smooth',
      block: scrollToEnd === false ? 'start' : 'end',
    });
  } else {
    // If there are no unread messages we'll scroll to bottom
    scrollToBottom();
  }
}

function scrollToBottom() {
  if (messageHistoryContainer) {
    setTimeout(() => {
      if (messageHistoryContainer) {
        messageHistoryContainer.scrollTop = messageHistoryContainer.scrollHeight;
      }

      // Even if we can't scroll yet we need to imitate that we did
      handleScroll();
    }, 0);
  }
}

function handleTabFocused() {
  if (appEnvironment !== 'production') console.debug('[emitter:TheChatMessageHistory] tabFocused');

  // We need this to handle a corner case when the first few messages from visitor were sent
  // when browser tab was inactive and chat tab was active, thus we haven't read the messages
  scrollToUnreadMessages(true, false);
}

function handleChatInputFocused() {
  if (appEnvironment !== 'production')
    console.debug('[emitter:TheChatMessageHistory] chatInputFocused');

  handleScroll();
}

function handleScroll() {
  if (messageHistoryContainer) {
    historyScrolledToEnd =
      Math.abs(
        messageHistoryContainer.scrollHeight -
          messageHistoryContainer.clientHeight -
          messageHistoryContainer.scrollTop
      ) <= 2.5;
  }

  // When we scroll to bottom we automatically read all messages
  if (historyScrolledToEnd && app.chatInputFocused) {
    chats.markAllMessagesAsRead(props.chat);
  }
}

function openSuggestFaqModal(data) {
  suggestFaqModalEvent = data.event;

  showSuggestFaqModal = true;
}

function openAddCannedResponseModal(data) {
  addCannedResponseModalEvent = data.event;

  showAddCannedResponseModal = true;
}
</script>

<template>
  <div
    id="messageHistoryContainer"
    ref="messageHistoryContainer"
    class="flex min-h-[0px] grow flex-col overflow-y-auto py-3"
    @scroll="handleScroll"
  >
    <div>
      <!-- Chat started at time, should look like a regular system message -->
      <div class="flex w-full justify-center" :data-event-id="chat.current_thread_id + '_START'">
        <div class="shrink-0 rounded-md border px-1.5 py-0.5 text-center text-gray-400">
          <i class="fa-fw fa-regular fa-paper-plane mr-0.5"></i>
          <span>
            Chat started on
            <span
              v-tooltip="
                chat.threads[chat.current_thread_id].created_at.toLocaleString(
                  DateTime.DATETIME_FULL_WITH_SECONDS
                )
              "
              v-text="
                chat.threads[chat.current_thread_id].created_at.toLocaleString(
                  DateTime.DATETIME_MED_WITH_SECONDS
                )
              "
            ></span>
          </span>
        </div>
      </div>

      <ChatEvent
        v-for="(event, index) in events"
        :key="event.id"
        :chat="chat"
        :event="event"
        :unread-messages-count="unreadMessagesCount"
        :show-unread-messages-banner="firstUnreadMessagesId === event.id"
        :same-author-as-previous-event="
          index > 0 ? event.author_id === events[index - 1].author_id : false
        "
      />

      <!-- Visitor message sneak peek, should look like a regular visitor message -->
      <ChatEventMessageVisitor
        v-if="
          !chats.activeChat.is_deactivated &&
          !chats.activeChat.is_transferred &&
          chat.visitor_message_sneak_peek
        "
        :chat="chat"
        :event="{
          id:
            'sneak_peek_' +
            (chat.visitor_message_sneak_peek_time
              ? chat.visitor_message_sneak_peek_time.toMillis()
              : ''),
          type: 'sneak_peek',
          text: chat.visitor_message_sneak_peek,
          thread_id: chats.activeChat.current_thread_id,
          author_is_visitor: true,
        }"
        :same-author-as-previous-event="
          events.length ? chat.visitor.id === events[events.length - 1].author_id : false
        "
      />
    </div>
  </div>

  <SuggestFaqModal
    size="sm"
    :show="showSuggestFaqModal"
    :chat="chat"
    :event="suggestFaqModalEvent"
    @close="showSuggestFaqModal = false"
  />

  <AddCannedResponseModal
    size="sm"
    :show="showAddCannedResponseModal"
    :event="addCannedResponseModalEvent"
    @close="showAddCannedResponseModal = false"
  />
</template>

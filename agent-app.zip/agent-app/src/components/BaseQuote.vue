<script setup>
defineProps({
  text: {
    type: String,
    required: true,
  },
  variant: {
    type: String,
    default: 'dark',
    validator(value) {
      // The value must match one of these strings
      return ['dark', 'light'].includes(value);
    },
  },
});
</script>

<template>
  <blockquote
    class="border-l-4 p-3"
    :class="{
      'border-gray-300 bg-gray-100': variant === 'dark',
      'border-gray-200 bg-white': variant === 'light',
    }"
  >
    <div class="break-word whitespace-pre-line text-xl text-gray-900" v-text="text"></div>
  </blockquote>
</template>

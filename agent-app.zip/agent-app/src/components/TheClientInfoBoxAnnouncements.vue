<script setup>
import { DateTime } from 'luxon';
import { useClientsStore } from '@/stores/clients';
import BaseHeading from '@/components/BaseHeading.vue';

const clients = useClientsStore();
</script>

<template>
  <div>
    <BaseHeading>Client Announcements</BaseHeading>
    <div v-if="clients.activeClient" class="-mt-3 mb-3 text-sm font-light text-gray-400">
      Updated {{ clients.activeClient.updated_at.toLocaleString(DateTime.DATETIME_MED) }}
    </div>

    <div class="html-section" v-html="clients.activeClient.announcements"></div>
  </div>
</template>

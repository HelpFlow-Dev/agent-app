<script>
export default {
  inheritAttrs: false,
};
</script>

<script setup>
defineProps({
  variant: {
    type: String,
    default: 'default',
    validator(value) {
      // The value must match one of these strings
      return ['default', 'with-icon'].includes(value);
    },
  },
  type: {
    type: String,
    default: 'text',
  },
  modelValue: {
    type: [String, Number],
    default: '',
  },
  placeholder: {
    type: String,
    default: '',
  },
  hasError: {
    type: Boolean,
    default: false,
  },
  disabled: {
    type: Boolean,
    default: false,
  },
});

const emit = defineEmits(['update:modelValue']);

function onInput(event) {
  emit('update:modelValue', event.target.value);
}
</script>

<template>
  <input
    class="w-full select-none rounded-md border-2 bg-white outline-none transition placeholder:text-gray-400 disabled:pointer-events-none disabled:bg-gray-100 disabled:opacity-60"
    :class="{
      'p-3': variant == 'default',
      'py-1.5 pl-8 pr-3': variant === 'with-icon',
      'border-gray-200 focus:border-blue-500 active:border-blue-500': !hasError,
      'border-rose-500': hasError,
    }"
    v-bind="$attrs"
    :type="type"
    :placeholder="placeholder"
    :disabled="disabled"
    :value="modelValue"
    @input="onInput"
  />
</template>

<script setup>
import { inject } from 'vue';
import { useAgentsStore } from '@/stores/agents';
import { useScreenRecordingsStore } from '@/stores/screenRecordings';

const appEnvironment = inject('appEnvironment');
const emitter = inject('emitter');
const now = inject('now');
const agents = useAgentsStore();
const screenRecordings = useScreenRecordingsStore();

async function handleStatusChange(e) {
  let newStatusId = parseInt(e.target.value);

  await agents.updateStatus(newStatusId);

  // If screen recroding is not working and agent is switching to "Accpeting" status,
  // we'll need to remind them to start recroding
  if (appEnvironment === 'production'
    && agents.currentStatusId === agents.acceptingStatusId
    && !screenRecordings.recordingInProgress
  ) {
    // Close any active modal
    emitter.emit('shortcut-close-modal');

    // Open screen recording modal
    emitter.emit('show-screen-recorder-modal');
  }
}
</script>

<template>
  <div
    class="mb-[-2px] flex shrink-0 select-none items-center border-b-2 p-3 text-white"
    :class="{
      'border-emerald-600 bg-emerald-500': agents.currentStatusId == agents.acceptingStatusId,
      'border-rose-700 bg-rose-500': agents.currentStatusId != agents.acceptingStatusId,
    }"
  >
    <div class="mr-3">
      <select
        class="select-none rounded-md border-2 border-white bg-transparent p-1.5 font-semibold outline-0 transition"
        :class="{
          'hover:bg-emerald-400':
            !agents.statusUpdating && agents.currentStatusId == agents.acceptingStatusId,
          'hover:bg-rose-400':
            !agents.statusUpdating && agents.currentStatusId != agents.acceptingStatusId,
          'cursor-pointer': !agents.statusUpdating,
          'pointer-events-none opacity-60': agents.statusUpdating,
        }"
        :disabled="agents.statusUpdating"
        tabindex="-1"
        @change="handleStatusChange"
      >
        <option
          v-for="status in agents.statuses"
          :key="status.id"
          :value="status.id"
          :selected="agents.currentStatusId == status.id"
        >
          {{ status.status }}
        </option>
      </select>
    </div>

    <!-- Amount of time agent is in current status -->
    <div class="min-w-[106px] text-right font-mono tracking-tighter">
      <div v-if="agents.statusUpdating" class="font-mono">Updating...</div>
      <div v-else-if="!agents.statusUpdating && agents.currentStatusId !== agents.goingOnBreakStatusId">
        {{ agents.currentStatusUpdatedAtDiffFormatted(now) }}
      </div>
      <div v-else-if="!agents.statusUpdating && agents.currentStatusId === agents.goingOnBreakStatusId">
        in {{ agents.goingToBreakInDiffFormatted(now) }}
      </div>
    </div>
  </div>
</template>

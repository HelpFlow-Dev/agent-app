<script setup>
import { inject } from 'vue';
import { useScreenRecordingsStore } from '@/stores/screenRecordings';

const emitter = inject('emitter');
const screenRecordings = useScreenRecordingsStore();

defineProps({
  disabled: {
    type: Boolean,
    default: false,
  },
});
</script>

<template>
  <div
    class="flex cursor-pointer items-center justify-center rounded-md transition h-10 px-2.5 border-2 select-none"
    :class="{
      'border-gray-200 bg-white hover:border-blue-500 hover:bg-blue-100 hover:text-blue-500 active:border-blue-500 active:bg-blue-100 active:text-blue-500':
       !screenRecordings.recordingInProgress,
      'border-rose-500 bg-rose-100 text-rose-500': screenRecordings.recordingInProgress,
      'pointer-events-none opacity-50': disabled,
    }"
    v-tooltip="screenRecordings.recordingInProgress ? 'Screen recording is in progress...' : 'Start screen recording'"
    @click="emitter.emit('show-screen-recorder-modal')"
  >
    <i
      class="fa-regular fa-circle-dot text-lg"
     :class="{ 'animate-pulse': screenRecordings.recordingInProgress }"
    ></i>
    <span
      class="pl-2"
      :class="{ 'animate-pulse': screenRecordings.recordingInProgress }"
      v-text="screenRecordings.recordingInProgress ? 'Recording...' : 'Record screen'"
    ></span>
  </div>
</template>

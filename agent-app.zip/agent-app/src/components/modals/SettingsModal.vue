<script setup>
import { inject } from 'vue';
import { useAppStore } from '@/stores/app';
import { useAgentsStore } from '@/stores/agents';
import BaseLink from '@/components/BaseLink.vue';
import BaseModal from '@/components/BaseModal.vue';
import ChangelogModal from '@/components/modals/ChangelogModal.vue';

const app = useAppStore();
const agents = useAgentsStore();
const appVersion = inject('appVersion');
const appEnvironment = inject('appEnvironment');

defineProps({
  show: {
    type: Boolean,
    default: false,
  },
});

const emit = defineEmits(['close']);

let showChangelogModal = $ref(false);

function openChangelogModal() {
  // Close settings modal
  emit('close');

  showChangelogModal = true;
}
</script>

<template>
  <BaseModal :show="show" @close="$emit('close')">
    <template #title>Settings</template>
    <template #default>
      <div class="flex items-center rounded-md border-2 border-gray-200 bg-white p-3">
        <div class="pr-3 font-semibold">HelpFlow account</div>
        <div class="ml-auto text-right">
          User #{{ agents.agent.user_id }} ({{ agents.agent.email }})
        </div>
      </div>
      <div v-if="app.livechatEnabled" class="mt-3 flex items-center rounded-md border-2 border-gray-200 bg-white p-3">
        <div class="pr-3 font-semibold">LiveChat account</div>
        <div class="ml-auto text-right">
          {{ agents.agent.display_name }} ({{ agents.agent.livechat_id }})
        </div>
      </div>
      <div class="mt-3 flex items-center rounded-md border-2 border-gray-200 bg-white p-3">
        <div class="pr-3 font-semibold">App version and environment</div>
        <div class="ml-auto text-right">
          <BaseLink
            to="javascript:void(0);"
            class="font-medium"
            v-tooltip="'Open changelog'"
            @click="openChangelogModal"
          >
            {{ appVersion }} ({{ appEnvironment }})
          </BaseLink>
        </div>
      </div>
    </template>
  </BaseModal>

  <ChangelogModal
    :show="showChangelogModal"
    :use-white-background="true"
    @close="showChangelogModal = false"
  />
</template>

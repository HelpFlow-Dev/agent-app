<script setup>
import { useScreenRecordingsStore } from '@/stores/screenRecordings';
import BaseModal from '@/components/BaseModal.vue';
import BaseScreenRecorderItem from '@/components/BaseScreenRecorderItem.vue';
import IconLoader from '@/components/icons/IconLoader.vue';

const screenRecordings = useScreenRecordingsStore();

defineProps({
  show: {
    type: Boolean,
    default: false,
  },
  screens: {
    type: Object,
    required: true,
  },
});

defineEmits(['close']);
</script>

<template>
  <BaseModal :show="show" @close="$emit('close')">
    <template #title>Screen recording</template>
    <template #default>
      <div class="flex flex-col">
        <div v-if="!screenRecordings.recordingInProgress" class="flex items-center rounded-md border-2 border-yellow-500 bg-white p-3 leading-7 mb-3">
          <div class="flex items-center">
            <i class="fa-solid fa-circle-exclamation mr-2 w-5 text-center text-lg text-yellow-500"></i>
            <div>Please start screen recording as soon as you start working.</div>
          </div>
        </div>

        <BaseScreenRecorderItem
          class="mb-3"
          title="Primary screen"
          description="For recording HAS screen"
          :screen="screens[1]"
        />

        <BaseScreenRecorderItem
          class="mb-3"
          title="Secondary screen"
          description="For recording FAQ Search screen"
          :screen="screens[2]"
        />

        <BaseScreenRecorderItem
          class="mb-3"
          :screen-id="3"
          title="Third screen"
          description="For recording an additional screen"
          :screen="screens[3]"
        />

        <div class="flex items-center rounded-md border-2 border-gray-200 bg-white p-3 leading-7">
          <div v-if="screenRecordings.queuedRecordingsCount" class="flex items-center">
            <IconLoader class="mr-2 text-blue-500" />
            <div>Uploading recordings...</div>
          </div>
          <div v-else class="flex items-center">
            <i class="fa-solid fa-check mr-2 w-5 text-center text-lg text-emerald-500"></i>
            <div>All recordings uploaded</div>
          </div>

          <div class="ml-auto pl-3 text-right text-gray-400">
            {{ screenRecordings.uploadedRecordingsCount }} of {{ screenRecordings.recordingsCount }}
          </div>
        </div>
      </div>
    </template>
  </BaseModal>
</template>

<script setup>
import { computed, onMounted } from 'vue';
import BaseModal from '@/components/BaseModal.vue';
import BaseKeyboardKeyLabel from '@/components/BaseKeyboardKeyLabel.vue';
import UAParser from 'ua-parser-js';

// We need to handle only two types of OS: windows and mac
// if user is on any other OS we'll asume he's using the keyboard designed for Windows
let os = $ref('windows');

const keyLabelEsc = computed(() => {
  if (os === 'mac') return 'esc';

  return 'Esc';
});

const keyLabelCtrl = computed(() => {
  if (os === 'mac') return 'control';

  return 'Ctrl';
});

const keyLabelAlt = computed(() => {
  if (os === 'mac') return 'option';

  return 'Alt';
});

const keyLabelShift = computed(() => {
  if (os === 'mac') return 'shift';

  return 'Shift';
});

const keyLabelBackspace = computed(() => {
  if (os === 'mac') return 'delete';

  return 'Backspace';
});

onMounted(() => {
  // Parse User Agent string for auth agent
  let userAgentParser = new UAParser();

  if (['Mac OS', 'iOS'].includes(userAgentParser.getOS().name)) os = 'mac';
});
</script>

<template>
  <BaseModal @close="$emit('close')">
    <template #title>Keyboard shortcuts</template>
    <template #default>
      <div class="font-semibold">Global</div>

      <div class="mt-3 flex items-center">
        <BaseKeyboardKeyLabel>{{ keyLabelEsc }}</BaseKeyboardKeyLabel>
        <div class="ml-1.5">Close modal window, dropdown menu, tag picker, emoji picker, etc.</div>
      </div>

      <div class="mt-3 flex items-center">
        <BaseKeyboardKeyLabel>{{ keyLabelCtrl }}</BaseKeyboardKeyLabel>
        <BaseKeyboardKeyLabel>{{ keyLabelShift }}</BaseKeyboardKeyLabel>
        <BaseKeyboardKeyLabel>/</BaseKeyboardKeyLabel>
        <div class="ml-1.5">Display keyboard shortcuts modal window</div>
      </div>

      <div class="mt-3 font-semibold">Chats</div>

      <!-- <div class="mt-3 flex items-center">
        <BaseKeyboardKeyLabel>{{ keyLabelAlt }}</BaseKeyboardKeyLabel>
        <BaseKeyboardKeyLabel>Up</BaseKeyboardKeyLabel>
        <div class="ml-1.5">Jump to previous chat</div>
      </div> -->
      <!-- <div class="mt-3 flex items-center">
        <BaseKeyboardKeyLabel>{{ keyLabelAlt }}</BaseKeyboardKeyLabel>
        <BaseKeyboardKeyLabel>Down</BaseKeyboardKeyLabel>
        <div class="ml-1.5">Jump to next chat</div>
      </div> -->

      <div class="mt-3 flex items-center">
        <BaseKeyboardKeyLabel>{{ keyLabelCtrl }}</BaseKeyboardKeyLabel>
        <BaseKeyboardKeyLabel>{{ keyLabelAlt }}</BaseKeyboardKeyLabel>
        <BaseKeyboardKeyLabel>{{ keyLabelBackspace }}</BaseKeyboardKeyLabel>
        <div class="ml-1.5">Stop or close current chat</div>
      </div>

      <div class="mt-3 flex items-center">
        <BaseKeyboardKeyLabel>{{ keyLabelCtrl }}</BaseKeyboardKeyLabel>
        <BaseKeyboardKeyLabel>{{ keyLabelAlt }}</BaseKeyboardKeyLabel>
        <BaseKeyboardKeyLabel>M</BaseKeyboardKeyLabel>
        <div class="ml-1.5">Toggle tag picker</div>
      </div>
      <div class="mt-3 flex items-center">
        <BaseKeyboardKeyLabel>{{ keyLabelCtrl }}</BaseKeyboardKeyLabel>
        <BaseKeyboardKeyLabel>{{ keyLabelShift }}</BaseKeyboardKeyLabel>
        <BaseKeyboardKeyLabel>Z</BaseKeyboardKeyLabel>
        <div class="ml-1.5">Open and close RTO modal window</div>
      </div>
    </template>
  </BaseModal>
</template>

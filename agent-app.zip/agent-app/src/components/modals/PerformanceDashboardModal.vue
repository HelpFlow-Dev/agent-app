<script setup>
import { inject } from 'vue';
import axios from 'axios';
import { DateTime, Duration } from 'luxon';
import { formatLuxonDuration } from '@/helpers';
import { useToast } from '@/stores/toasts';
import BaseModal from '@/components/BaseModal.vue';
import IconLoader from '@/components/icons/IconLoader.vue';

const toast = useToast();
const appEnvironment = inject('appEnvironment');
const now = inject('now');

let performanceData = $ref(null);

const emit = defineEmits(['close']);

function visitorsUpdatedAtDiffFormatted(now) {
  if (!performanceData) return null;

  return performanceData.queue.visitors_updated_at.toRelative();
}

async function reloadPerformanceData() {
  performanceData = null;

  await axios
    .get('/api/v2/agent/report')
    .then(function (response) {
      performanceData = response.data;

      performanceData.queue.agents_count_updated_at = DateTime.fromSQL(
        performanceData.queue.agents_count_updated_at,
        { zone: 'UTC' }
      );

      performanceData.queue.visitors_updated_at = DateTime.fromSQL(
        performanceData.queue.visitors_updated_at,
        { zone: 'UTC' }
      );

      if (appEnvironment !== 'production')
        console.debug('Loaded performance dashboard data:', performanceData);
    })
    .catch(function (error) {
      toast.failedToLoadPerformanceReport();

      console.error(error);

      performanceData = null;

      emit('close');
    });
}
</script>

<template>
  <BaseModal size="xl" @show="reloadPerformanceData" @close="$emit('close')">
    <template #title>Performance dashboard</template>
    <template #default>
      <div v-if="performanceData" class="flex flex-col">
        <div class="flex pb-3 text-lg">
          <div class="font-semibold">Queue overview</div>
          <div class="ml-auto text-gray-400">Updated {{ visitorsUpdatedAtDiffFormatted(now) }}</div>
        </div>
        <table class="w-full table-auto text-center">
          <tr class="bg-gray-400 text-white">
            <th class="border-2 border-gray-500 p-1.5">Queued visitors</th>
            <th class="border-2 border-gray-500 p-1.5">Longest wait</th>
            <th class="border-2 border-gray-500 p-1.5">Ongoing chats</th>
            <th class="border-2 border-gray-500 p-1.5">Agents online</th>
          </tr>
          <tr>
            <td class="border-2 border-gray-200 bg-white p-1.5">
              {{ performanceData.queue.visitors }}
            </td>
            <td class="border-2 border-gray-200 bg-white p-1.5">
              {{ performanceData.queue.longest_wait_in_seconds || 'Unknown' }}
            </td>
            <td class="border-2 border-gray-200 bg-white p-1.5">
              {{ performanceData.queue.chats_count }}
            </td>
            <td class="border-2 border-gray-200 bg-white p-1.5">
              {{ performanceData.queue.agents_count }}
            </td>
          </tr>
        </table>

        <!-- The report for today is in America/Los_Angeles timezone, so we need to account for that -->
        <div class="mt-3 pb-3 text-lg font-semibold">
          Your statistics for
          {{ DateTime.now().setZone('America/Los_Angeles').toLocaleString(DateTime.DATE_HUGE) }}
          ({{ DateTime.now().setZone('America/Los_Angeles').toFormat('ZZZZ') }})
        </div>
        <table class="w-full table-auto text-center">
          <tr class="bg-blue-500 text-white">
            <th class="border-2 border-blue-600 p-1.5">Number of chats</th>
            <th class="border-2 border-blue-600 p-1.5">Average handle time</th>
            <th class="border-2 border-blue-600 p-1.5">Overall CSAT</th>
            <th class="border-2 border-blue-600 p-1.5">Solution</th>
            <th class="border-2 border-blue-600 p-1.5">Comprehension</th>
            <th class="border-2 border-blue-600 p-1.5">Timeliness</th>
          </tr>
          <tr>
            <td class="border-2 border-gray-200 bg-white p-1.5">
              {{ performanceData.agent.chats }}
            </td>
            <td
              v-if="performanceData.agent.average_handle_time"
              class="border-2 border-gray-200 bg-white p-1.5"
            >
              {{
                formatLuxonDuration(
                  Duration.fromObject({ seconds: performanceData.agent.average_handle_time })
                )
              }}
            </td>
            <td v-else class="border-2 border-gray-200 bg-white p-1.5">Unknown</td>
            <td
              class="border-2 border-gray-200 bg-white p-1.5"
              v-text="
                performanceData.agent.overall_csat
                  ? performanceData.agent.overall_csat.toFixed(2) + '%'
                  : 'Unknown'
              "
            ></td>
            <td
              class="border-2 border-gray-200 bg-white p-1.5"
              v-text="
                performanceData.agent.solution
                  ? performanceData.agent.solution.toFixed(2) + '%'
                  : 'Unknown'
              "
            ></td>
            <td
              class="border-2 border-gray-200 bg-white p-1.5"
              v-text="
                performanceData.agent.comprehension
                  ? performanceData.agent.comprehension.toFixed(2) + '%'
                  : 'Unknown'
              "
            ></td>
            <td
              class="border-2 border-gray-200 bg-white p-1.5"
              v-text="
                performanceData.agent.timeliness
                  ? performanceData.agent.timeliness.toFixed(2) + '%'
                  : 'Unknown'
              "
            ></td>
          </tr>
        </table>
      </div>
      <div v-else class="flex min-h-[248px] items-center justify-center p-3">
        <IconLoader size="lg" class="text-blue-500"></IconLoader>
      </div>
    </template>
  </BaseModal>
</template>

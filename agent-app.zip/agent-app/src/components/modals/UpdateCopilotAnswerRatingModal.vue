<script setup>
import { nextTick, watch } from 'vue';
import validator from 'validator';
import { useCopilot } from '@/stores/copilot';
import BaseButton from '@/components/BaseButton.vue';
import BaseInputHelpText from '@/components/BaseInputHelpText.vue';
import BaseInputLabel from '@/components/BaseInputLabel.vue';
import BaseHr from '@/components/BaseHr.vue';
import BaseModal from '@/components/BaseModal.vue';
import BaseTextarea from '@/components/BaseTextarea.vue';

const copilot = useCopilot();

let comment = $ref('');
let formErrors = $ref({});

const props = defineProps({
  show: {
    type: Boolean,
    default: false,
  },
  requestId: {
    type: Number,
    default: null,
  },
  rating: {
    type: Number,
    default: null,
  },
});

const emit = defineEmits(['close']);

watch(() => props.show, handleModalVisibilityChange);

function handleModalVisibilityChange() {
  if (props.show) {
    nextTick(() => {
      let input = document.getElementById('update-copilot-answer-rating-modal-comment-input');

      if (input) input.focus();
    });
  } else {
    comment = '';
    formErrors = {};
  }
}

function submit() {
  // Validate inputs
  if (validator.isEmpty(comment)) {
    formErrors['comment'] = 'Comment must not be empty.';
  } else if (!validator.isLength(comment, { max: 2500 })) {
    formErrors['comment'] = 'Comment may not be greater than 2500 characters.';
  }

  // Prevent submitting form with errors
  if (Object.keys(formErrors).length) return false;

  copilot.updateRating(props.requestId, props.rating, comment);

  emit('close');
}
</script>

<template>
  <BaseModal size="lg" :show="show" :use-white-background="true" @close="$emit('close')">
    <template #title>Comment on AI answer</template>
    <template #default>
      <div class="mb-3 text-gray-900">
        Please let us know why you've rated the Copilot answer as <span class="font-bold" :class="{ 'text-emerald-500': rating === 1, 'text-rose-500': rating === 0 }">{{ rating === 1 ? 'good' : 'bad' }}</span>.
      </div>

      <div class="flex flex-col">
        <BaseInputLabel>Your comment</BaseInputLabel>

        <BaseTextarea
          id="update-copilot-answer-rating-modal-comment-input"
          placeholder="Enter your comment..."
          rows="4"
          :resizeable="false"
          :has-error="formErrors.hasOwnProperty('comment')"
          v-model.trim="comment"
          @input="delete formErrors['comment']"
        />
        <BaseInputHelpText>{{ formErrors['comment'] }}</BaseInputHelpText>
      </div>
    </template>
    <template #footer>
      <BaseButton @click="submit">Submit</BaseButton>
      <BaseButton @click="$emit('close')" variant="gray-outline" class="ml-3">Cancel</BaseButton>
    </template>
  </BaseModal>
</template>

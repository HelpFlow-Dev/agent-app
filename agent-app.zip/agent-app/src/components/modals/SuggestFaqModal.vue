<script setup>
import { nextTick, watch } from 'vue';
import validator from 'validator';
import { useClientsStore } from '@/stores/clients';
import BaseButton from '@/components/BaseButton.vue';
import BaseInput from '@/components/BaseInput.vue';
import BaseInputHelpText from '@/components/BaseInputHelpText.vue';
import BaseModal from '@/components/BaseModal.vue';
import BaseQuote from '@/components/BaseQuote.vue';

const clients = useClientsStore();

let title = $ref('');
let formErrors = $ref({});

const props = defineProps({
  show: {
    type: Boolean,
    default: false,
  },
  chat: {
    type: Object,
    required: true,
  },
  event: {
    type: Object,
    required: false,
  },
});

const emit = defineEmits(['close']);

watch(() => props.show, handleModalVisibilityChange);

function handleModalVisibilityChange() {
  if (props.show) {
    nextTick(() => {
      let input = document.getElementById('suggest-faq-modal-title-input');

      if (input) input.focus();
    });
  } else {
    title = '';
    formErrors = {};
  }
}

function submit() {
  // Validate inputs
  if (validator.isEmpty(title)) {
    formErrors['title'] = 'Title must not be empty.';
  }

  // Prevent submitting form with errors
  if (Object.keys(formErrors).length) return false;

  clients.suggestFaq(props.chat.client_code, props.chat.current_thread_id, title, props.event);

  emit('close');
}
</script>

<template>
  <BaseModal size="lg" :show="show" :use-white-background="true" @close="$emit('close')">
    <template #title>Suggest an FAQ</template>
    <template #default>
      <div class="mb-3">
        <BaseInput
          id="suggest-faq-modal-title-input"
          :placeholder="'Enter FAQ title...'"
          :has-error="formErrors.hasOwnProperty('title')"
          v-model.trim="title"
          @input="delete formErrors['title']"
        />
        <BaseInputHelpText>{{ formErrors['title'] }}</BaseInputHelpText>
      </div>

      <BaseQuote :text="event.text" />

      <div class="mt-3 text-gray-900">
        ☝️ This message will be attached to the suggested FAQ for context.
      </div>
    </template>
    <template #footer>
      <BaseButton @click="submit">Suggest FAQ</BaseButton>
      <BaseButton @click="$emit('close')" variant="gray-outline" class="ml-3">Cancel</BaseButton>
    </template>
  </BaseModal>
</template>

<script setup>
import { inject } from 'vue';
import { useChatsStore } from '@/stores/chats';
import { pageVisitDurationFormatted, removeProtocolFromUrl } from '@/helpers';
import BaseModal from '@/components/BaseModal.vue';
import BaseLink from '@/components/BaseLink.vue';

const now = inject('now');
const chats = useChatsStore();

defineProps({
  chat: {
    type: Object,
    required: true,
  },
  visitedPages: {
    type: Array,
    required: true,
  },
});
</script>

<template>
  <BaseModal :use-white-background="true">
    <template #title>
      Visited {{ visitedPages.length }} {{ visitedPages.length === 1 ? 'page' : 'pages' }} in
      {{ pageVisitDurationFormatted(visitedPages[visitedPages.length - 1].opened_at, chats.getChatDeactivatedAt(chat), now) }}
    </template>
    <template #default>
      <div class="relative flex flex-col">
        <div
          v-for="(visitedPage, index) in visitedPages"
          :key="index"
          :class="{ 'mt-3': index > 0 }"
          class="relative ml-7 rounded-md border-2 border-gray-200 p-3 leading-5"
        >
          <div class="w-100 flex">
            <BaseLink
              class="-ml-1 truncate font-medium"
              :to="visitedPage.url"
              :show-external-link-icon="true"
            >
              {{ visitedPage.title ? visitedPage.title : removeProtocolFromUrl(visitedPage.url) }}
            </BaseLink>
          </div>
          <div
            v-if="index === 0 && index !== visitedPages.length - 1"
            class="absolute left-[-23px] top-[47px] h-[58px] rounded-md border-l-2 border-gray-200"
          ></div>
          <div
            v-else-if="index !== 0 && index !== visitedPages.length - 1"
            class="absolute left-[-23px] top-[45px] h-[58px] rounded-md border-l-2 border-gray-200"
          ></div>
          <div
            v-if="index === 0"
            class="absolute left-[-30px] top-[25px] box-content h-2 w-2 rounded-full border-4 border-gray-200 bg-emerald-500"
          ></div>
          <div
            v-else
            class="absolute left-[-30px] top-[25px] m-1 box-content h-2 w-2 rounded-full bg-gray-200"
          ></div>
          <div v-if="chat.is_deactivated && index === 0">
            {{ pageVisitDurationFormatted(visitedPage.opened_at, chats.getChatDeactivatedAt(chat), now) }}
          </div>
          <div v-else>
            {{ pageVisitDurationFormatted(visitedPage.opened_at, visitedPage.closed_at, now) }}
          </div>
        </div>
      </div>
    </template>
  </BaseModal>
</template>

<script setup>
import axios from 'axios';
import { partial } from 'filesize';
import { computed, inject, onMounted, onUnmounted, watch } from 'vue';
import Bugsnag from '@bugsnag/js';
import validator from 'validator';
import { useAgentsStore } from '@/stores/agents';
import { useAppStore } from '@/stores/app';
import { useChatsStore } from '@/stores/chats';
import { useTagsStore } from '@/stores/tags';
import { useToast } from '@/stores/toasts';
import { openInNewTab } from '@/helpers';
import BaseButton from '@/components/BaseButton.vue';
import BaseCheckbox from '@/components/BaseCheckbox.vue';
import BaseHr from '@/components/BaseHr.vue';
import BaseFileInput from '@/components/BaseFileInput.vue';
import BaseInput from '@/components/BaseInput.vue';
import BaseInputLabel from '@/components/BaseInputLabel.vue';
import BaseInputHelpText from '@/components/BaseInputHelpText.vue';
import BaseLink from '@/components/BaseLink.vue';
import BaseModal from '@/components/BaseModal.vue';
import BaseRadioSelect from '@/components/BaseRadioSelect.vue';
import BaseTextarea from '@/components/BaseTextarea.vue';
import FilePreviewList from '@/components/FilePreviewList.vue';

const app = useAppStore();
const agents = useAgentsStore();
const chats = useChatsStore();
const tags = useTagsStore();
const toast = useToast();
const appEnvironment = inject('appEnvironment');
const emitter = inject('emitter');
const filesize = partial({ base: 2, round: 2, pad: true, standard: 'jedec' });

let emailContent = $ref('');
let emailTo = $ref('');
let emailCC = $ref('');
let subject = $ref('');
let actionItems = $ref('');
let visitorDetails = $ref('');
let useCustomSubject = $ref(0);
let isUrgent = $ref(0);
let rtoFor = $ref('SALES');
let isSending = $ref(false);
let isInitialized = $ref(false);
let formErrors = $ref({});
// Array of File objects, limits: 4 MB on local (Mailtrap), 19 MB for staging/production (SparkPost)
let attachmentFiles = $ref([]);
let attachmentFilesMaxTotalSize = $ref(appEnvironment === 'local' ? 4194304 : 19922944);

const props = defineProps({
  show: {
    type: Boolean,
    default: false,
  },
  chat: {
    type: Object,
    required: true,
  },
  client: {
    type: Object,
    required: true,
  },
});

// Close modal when we switch to a different chat
watch(() => chats.activeChatId, closeModal);
watch(() => props.show, handleModalVisibilityChange);
watch(() => useCustomSubject, generateEmailSubject);
watch(() => subject, handleSubjectChange);
watch(() => isUrgent, generateEmailSubject);
watch(() => rtoFor, generateEmailSubject);
watch(() => actionItems, generateEmailContent);
watch(() => visitorDetails, generateEmailContent);

onMounted(() => {
  emitter.on('incomingEvent', handleIncomingMessage);

  initModalData();
});

onUnmounted(() => {
  emitter.off('incomingEvent', handleIncomingMessage);
});

function handleModalVisibilityChange() {
  if (props.show) {
    document.addEventListener('paste', handlePaste);
  } else {
    document.removeEventListener('paste', handlePaste);
  }

  if (!isInitialized) {
    initModalData();
  } else {
    generateEmailContent();
  }
}

const visitorGeolocation = computed(() => chats.getVisitorGeolocation(props.chat));
const visitorLocationFormatted = computed(() => chats.getVisitorLocationFormatted(props.chat));

const visitorCountry = computed(() => {
  if (visitorGeolocation.value && visitorGeolocation.value.country) {
    return visitorGeolocation.value.country;
  }

  return 'N/A';
});

const firstVisitedPage = computed(() => {
  if (props.chat.visitor && props.chat.visitor.is_loaded && props.chat.visitor.last_visit && props.chat.visitor.last_visit.last_pages) {
    // We'll copy and reverse the default order, so now we'll have from currently viewing page first
    let visitedPages = props.chat.visitor.last_visit.last_pages.slice().reverse();

    if (visitedPages.length) return visitedPages[visitedPages.length - 1];
  }

  return null;
});

const visitorRtosUrl = computed(() => {
  if (props.chat.visitor.is_loaded && props.chat.visitor.id) {
    return window.location.origin + '/rtos?searchAll=' + props.chat.visitor.id;
  }

  return null;
});

function handleIncomingMessage(data) {
  if (data.chat.id === props.chat.id) {
    if (appEnvironment !== 'production') console.debug('[emitter:RTOModal] incomingEvent', data);

    generateEmailContent();
  }
}

function handleSubjectChange() {
  delete formErrors['subject'];
}

function initModalData() {
  // Don't need to waste performance when RTO has been sent already
  if (props.chat.rto_sent === true) return false;

  let visitorDetailsFormatted = '';

  // Pre-fill visitor details
  visitorDetailsFormatted += 'firstname: ' + props.chat.visitor.first_name + "\n";
  visitorDetailsFormatted += 'lastname: ' + props.chat.visitor.last_name + "\n";
  visitorDetailsFormatted += 'emailaddress: ' + (props.chat.visitor.email ? props.chat.visitor.email : '') + "\n";
  visitorDetailsFormatted += 'phonenumber: n/a' + "\n"; // it would be very hard to grab valid phone number from chat messages
  visitorDetailsFormatted += 'location: ' + visitorLocationFormatted.value;

  // Get the first RTO email and use it as primary
  emailTo = props.client.rto_emails.length ? props.client.rto_emails[0] : '';

  // Get all other RTO emails and use them for CC
  emailCC = props.client.rto_emails.length > 1 ? props.client.rto_emails.slice(1).join(',') : '';
  visitorDetails = visitorDetailsFormatted;

  generateEmailContent();
  generateEmailSubject();

  isInitialized = true;
}

function resetModalData() {
  isInitialized = false;
  isSending = false;
  subject = '';
  emailTo = '';
  emailCC = '';
  actionItems = '';
  attachmentFiles = [];
  visitorDetails = '';
  useCustomSubject = 0;
  isUrgent = 0;
  rtoFor = 'SALES';
  formErrors = {};
}

function handlePaste(e) {
  const data = e.clipboardData || window.clipboardData;

  if (data.files.length) {
    addAttachmentFiles(e.clipboardData.files);

    toast.pastedFilesToInput(data.files.length);
  }
}

function addAttachmentFiles(fileList) {
  // Convert FileList to an Array
  let addedFiles = Array.from(fileList);

  // Remove duplicate files
  addedFiles = addedFiles.filter(
    (uploadedFile) => !attachmentFiles.some((file) => file.name === uploadedFile.name)
  );

  attachmentFiles = attachmentFiles.concat(addedFiles);

  // Total size of all files in bytes
  let totalSize = 0;

  for (let i = 0; i < attachmentFiles.length; i++) {
    totalSize += attachmentFiles[i].size;

    if (totalSize > attachmentFilesMaxTotalSize) {
      toast.selectedFileTooLarge(attachmentFiles.length);
      attachmentFiles = [];
      break;
    }
  }
}

function removeFile(uploadedFile) {
  attachmentFiles = attachmentFiles.filter((file) => file.name !== uploadedFile.name);
}

function handleAttachmentsInputChange(e) {
  if (e.target.files.length) addAttachmentFiles(e.target.files);

  // Clear file input
  e.target.value = null;
}

async function submit() {
  // Validate inputs
  if (validator.isEmpty(emailTo)) {
    formErrors['email_to'] = 'Email must not be empty.';
  } else if (!validator.isEmail(emailTo)) {
    formErrors['email_to'] = 'Email must be a valid email address.';
  }

  if (validator.isEmpty(subject)) {
    formErrors['subject'] = 'Subject must not be empty.';
  }

  let emailCCArray = [];

  if (emailCC.indexOf(',') > -1) {
    emailCCArray = emailCC.split(',');
  } else if (emailCC) {
    emailCCArray.push(emailCC);
  }

  emailCCArray.forEach((item) => {
    if (!validator.isEmpty(emailTo) && !validator.isEmail(item)) {
      if (emailCCArray.length > 1) { // If we have multiple emails and don't know which one is invalid
        formErrors['email_cc'] = 'At least one email is not a valid email address.';
      } else { // If we have a single invalid email
        formErrors['email_cc'] = 'Email must be a valid email address.';
      }
    }
  });

  if (validator.isEmpty(actionItems)) {
    formErrors['action_items'] = 'Action items must not be empty.';
  }

  if (validator.isEmpty(visitorDetails)) {
    formErrors['visitor_details'] = 'Visitor details must not be empty.';
  }

  // Prevent submitting form with errors
  if (Object.keys(formErrors).length) return false;

  isSending = true;

  // Fetch and insert latest messages from visitor before sending
  generateEmailContent();

  let formData = new FormData();
  formData.append('livechat_thread_id', props.chat.current_thread_id);
  formData.append('livechat_visitor_id', props.chat.visitor.id);
  formData.append('client_id', props.client.id);
  formData.append('content', emailContent);
  formData.append('action_items', actionItems);
  formData.append('to', emailTo);
  formData.append('for', rtoFor);
  formData.append('is_urgent', isUrgent);

  for (let i = 0; i < emailCCArray.length; i++) {
    formData.append('cc_to[]', emailCCArray[i]);
  }

  if (attachmentFiles.length) {
    for (let i = 0; i < attachmentFiles.length; i++) {
      formData.append('attachment_files[]', attachmentFiles[i]);
    }
  }

  if (useCustomSubject) {
    formData.append('subject', subject);
  }

  await axios.post('/api/v2/send-rto', formData, {
    headers: { 'Content-Type': 'multipart/form-data' },
  }).then(function (response) {
    // Update active chat thread property and RTO count
    props.chat.rto_sent = true;
    props.chat.visitor.rto_count++;

    tags.handleRTOSubmitted(props.chat, formData.get('for'));

    toast.RTOEmailSent();

    closeModal(true);
  }).catch(function (error) {
    toast.failedToSendRTOEmail();

    console.error(error);
  }).finally(() => {
    isSending = false;
  });
}

function generateEmailSubject() {
  // We won't generate subject if agent wants to have a custom subject line
  if (useCustomSubject) return false;

  let generatedSubject = isUrgent ? 'URGENT ' : '';
  generatedSubject += rtoFor + ' - ';
  generatedSubject += props.client.display_website_url + ' - ';
  generatedSubject += 'Website Chat #' + props.chat.current_thread_id + ' - ';
  generatedSubject += '(' + props.client.code + ')';

  subject = generatedSubject;
}

function generateEmailContent() {
  // Don't need to waste performance when RTO has been sent already
  if (props.chat.rto_sent === true) return false;

  // Don't need to waste performance when agent doesn't see the message preview
  if (!props.show) return false;

  // Note: classes used on elements below are only for previewing email content in the app

  // CSS Settings
  let defaultFontSize = '16px';
  let titleStyles = 'font-size: 30px; font-weight: 700;';
  let headingStyles = 'font-size: 22px; font-weight: 700;';
  let boldTextStyles = 'font-weight: 700;';

  // Line break element for email preview
  let br = "\n";

  let firstVisitedPageLink = 'N/A';
  if (firstVisitedPage.value) {
    firstVisitedPageLink = '<a href="' + firstVisitedPage.value.url + '" target="_blank" class="whitespace-nowrap">' + firstVisitedPage.value.url + '</a>';
  }

  // Reset previous data and add a wrapper
  emailContent = '<div style="font-size: ' + defaultFontSize + '; display: block;">';

  // Chat summary
  emailContent += 'Below is a chat from ';
  emailContent += '<a href="' + props.client.website_url + '" target="_blank" class="whitespace-nowrap">' + props.client.website_url + '</a>';
  emailContent += ' website that has a next action.' + br + br;
  emailContent += '<span style="' + titleStyles + '">## CHAT SUMMARY ##</span>' + br + br;

  // Action items
  emailContent += '<span style="' + boldTextStyles + '">Action items for you:</span>' + br;
  emailContent += actionItems ? actionItems : 'N/A';
  emailContent += br + br;

  // Visitor's contact information
  emailContent += '<span style="' + boldTextStyles + '">Customer\'s information:</span>' + br;
  emailContent += visitorDetails ? visitorDetails : 'N/A';
  emailContent += br + br;

  // Chat started at
  emailContent += '<span style="' + boldTextStyles + '">Chat started on:</span>' + br + firstVisitedPageLink + br;

  // Chat transcript
  let messages = chats.getMessages(props.chat);

  messages = messages.filter(function(event) {
    // We want only public text or file messages
    return event.visibility === 'all' && (event.type === 'message' || event.type === 'file');
  });

  if (messages.length) {
    emailContent += br + '<span style="' + headingStyles + '">##### Chat transcript below #####</span>' + br + br;

    messages.forEach((message, index) => {
      emailContent += formatMessage(message);
    });

    emailContent += '<span style="' + headingStyles + '">##### Chat transcript end #####</span>' + br;
  }

  // Attachments and files
  let fileMessages = chats.getFileMessages(props.chat);

  fileMessages = fileMessages.filter(function(event) {
    // We want only public messages
    return event.visibility === 'all';
  });

  if (fileMessages.length) {
    emailContent += br + '<span style="' + headingStyles + '">##### Attachments and files #####</span>' + br + br;

    fileMessages.forEach((message, index) => {
      let isLastMessage = index === fileMessages.length - 1;

      emailContent += formatFileAttachment(message, isLastMessage);
    });
  }

  emailContent += '</div>';
}

function formatMessage(message) {
  let result = '';
  let authorName = 'Visitor';
  let timestampFormatted = message.created_at.setZone('America/Los_Angeles').toFormat('yyyy-MM-dd HH:mm:ss') + ' PST';

  if (message.author_is_agent) {
    let agent = agents.getAgentByLivechatId(message.author_id);

    authorName = agent ? agent.display_name : 'Agent';
  }

  result += '<span style="font-weight: 700;">' + authorName + ' (' + timestampFormatted + ')</span>' + "\n";
  if (message.type === 'file') {
    result += 'File attachment: ' + message.name + "\n";
    result += '<a href="' + message.url + '" target="_blank" class="whitespace-nowrap">' + message.url + '</a>' + "\n\n";
  } else {
    result += message.text + "\n\n";
  }

  return result;
}

function formatFileAttachment(message, isLastMessage) {
  let result = '';

  result += message.name + "\n";
  result += '<a href="' + message.url + '" target="_blank" class="whitespace-nowrap">' + message.url + '</a>' + "\n";

  if (!isLastMessage) result += "\n";

  return result;
}

function openVisitorRtos() {
  openInNewTab(visitorRtosUrl.value);
}

function closeModal(reset) {
  props.chat.show_rto_modal = false;

  if (reset === true) resetModalData();
}
</script>

<template>
  <BaseModal :show="show" size="xl" :use-white-background="true" @close="closeModal">
    <template #title>RTO chat to client</template>
    <template #default>
      <div class="flex justify-between">
        <div class="flex items-center">
          <!-- Current chat ID -->
          <div class="shrink-0 whitespace-nowrap pr-3">
            <span class="select-none">CHAT #</span>
            <span class="font-mono">{{ chat.current_thread_id }}</span>
          </div>

          <!-- Current chat client code -->
          <div class="shrink-0 whitespace-nowrap pr-3">
            {{ client.code }}
          </div>

          <!-- Current chat client website -->
          <BaseLink
            v-if="client.website_url && client.display_website_url"
            :to="client.website_url"
            class="max-w-[300px] select-none truncate font-medium"
            :show-external-link-icon="true"
          >
            {{ client.display_website_url }}
          </BaseLink>
        </div>

        <div class="ml-auto">
          <BaseButton
            icon-before="fa-solid fa-square-arrow-up-right"
            variant="primary-outline"
            :disabled="!visitorRtosUrl"
            @click="openVisitorRtos"
          >
            <span>View visitor's RTOs</span>
          </BaseButton>
        </div>
      </div>

      <BaseHr />

      <div v-if="chat.rto_sent" class="text-center">
        <div>
          RTO email has been sent.
        </div>
        <div class="mt-3 text-gray-500">
          You can send only one RTO email per chat.
        </div>
      </div>
      <div v-else-if="client.rto_emails.length === 0" class="text-center">
        <div>
          <strong>{{ client.code }}</strong>
          client doesn't have any emails set up for RTO.
        </div>
        <div class="mt-3">
          Please contact your manager to let them know that they need to set up RTO emails for
          <strong>{{ client.code }}</strong> client before you can send RTO emails.
        </div>
      </div>
      <div v-else>
        <div class="mb-3">
          <div>
            <BaseInputLabel>Email subject</BaseInputLabel>
            <BaseInput
              :placeholder="'Enter subject...'"
              :has-error="formErrors.hasOwnProperty('subject')"
              :disabled="isSending || !useCustomSubject"
              v-model.trim="subject"
              @input="delete formErrors['subject']"
            />
            <div class="mt-1.5">
              <BaseCheckbox v-model="useCustomSubject" :true-value="1" :false-value="0" :disabled="isSending">
                Use custom subject
              </BaseCheckbox>
            </div>
            <BaseInputHelpText>{{ formErrors['subject'] }}</BaseInputHelpText>
          </div>
        </div>

        <div class="mb-3">
          <BaseInputLabel>Email content</BaseInputLabel>
          <pre
            class="h-[227px] overflow-y-auto overflow-x-hidden whitespace-pre-line rounded-md font-sans border-2 border-gray-200 bg-gray-50 px-2 py-1.5"
            v-html="emailContent"
          ></pre>
        </div>

        <div class="mb-3">
          <BaseInputLabel>RTO for</BaseInputLabel>
          <div class="flex w-full">
            <BaseRadioSelect
              class="mr-1.5 w-1/2"
              :disabled="isSending"
              :active="rtoFor === 'SALES'"
              @click="rtoFor = 'SALES'"
            >
              SALES
            </BaseRadioSelect>
            <BaseRadioSelect
              class="ml-1.5 w-1/2"
              :disabled="isSending"
              :active="rtoFor === 'SUPPORT'"
              @click="rtoFor = 'SUPPORT'"
            >
              SUPPORT
            </BaseRadioSelect>
          </div>
          <BaseInputHelpText v-if="rtoFor === 'SALES'" variant="info">
            Email will be handled by client's sales team.
          </BaseInputHelpText>
          <BaseInputHelpText v-else-if="rtoFor === 'SUPPORT'" variant="info">
            Email will be handled by client's support team.
          </BaseInputHelpText>
        </div>

        <div class="mb-3 grid grid-cols-2 gap-3">
          <div>
            <BaseInputLabel>Email (To)</BaseInputLabel>
            <BaseInput
              :placeholder="'Enter email...'"
              :has-error="formErrors.hasOwnProperty('email_to')"
              :disabled="isSending"
              v-model.trim="emailTo"
              @input="delete formErrors['email_to']"
            />
            <BaseInputHelpText variant="info">
              The RTO email will be sent to this address.
            </BaseInputHelpText>
            <BaseInputHelpText>{{ formErrors['email_to'] }}</BaseInputHelpText>
          </div>

          <div>
            <BaseInputLabel>Email (Carbon Copy)</BaseInputLabel>
            <BaseInput
              :placeholder="'Enter one or multiple emails (comma-separated)...'"
              :has-error="formErrors.hasOwnProperty('email_cc')"
              :disabled="isSending"
              v-model.trim="emailCC"
              @input="delete formErrors['email_cc']"
            />
            <BaseInputHelpText variant="info">
              The copy of the RTO email will also be sent to these addresses.
              All recipients will see who has been CC'd.
            </BaseInputHelpText>
            <BaseInputHelpText>{{ formErrors['email_cc'] }}</BaseInputHelpText>
          </div>
        </div>

        <div class="mb-3 grid grid-cols-2 gap-3">
          <div>
            <BaseInputLabel>Action items</BaseInputLabel>
            <BaseTextarea
              placeholder="Please explain what kind of issue you have and what the client should do..."
              rows="5"
              :min-rows="5"
              :has-error="formErrors.hasOwnProperty('action_items')"
              :disabled="isSending"
              v-model.trim="actionItems"
              @input="delete formErrors['action_items']"
            />
            <BaseInputHelpText>{{ formErrors['action_items'] }}</BaseInputHelpText>
          </div>

          <div>
            <BaseInputLabel>Visitor details</BaseInputLabel>
            <BaseTextarea
              placeholder="Add visitor contact information..."
              rows="5"
              :min-rows="5"
              :has-error="formErrors.hasOwnProperty('visitor_details')"
              :disabled="isSending"
              v-model.trim="visitorDetails"
              @input="delete formErrors['visitor_details']"
            />
            <BaseInputHelpText>{{ formErrors['visitor_details'] }}</BaseInputHelpText>
          </div>
        </div>

        <div class="mb-3">
          <BaseInputLabel>Priority</BaseInputLabel>
          <div>
            <BaseCheckbox v-model="isUrgent" :true-value="1" :false-value="0" :disabled="isSending">
              Requires immediate action by client
            </BaseCheckbox>
          </div>

          <BaseInputHelpText v-if="isUrgent === 1" variant="info">
            Email will be handled by client as soon as possible (high priorty).
          </BaseInputHelpText>
          <BaseInputHelpText v-if="isUrgent === 0" variant="info">
            Email will be handled by client as usual (normal priority).
          </BaseInputHelpText>
        </div>

        <div>
          <BaseInputLabel>Attachments</BaseInputLabel>

          <FilePreviewList
            :files="attachmentFiles"
            :validate-size="false"
            :can-remove="!isSending"
            @file-removed="removeFile"
          />

          <BaseFileInput
            :id="'rto-attachments-chat-' + chat.id"
            :multiple="true"
            :disabled="isSending"
            @change="handleAttachmentsInputChange"
          />

          <BaseInputHelpText variant="info">
            You can attach multiple files of any format, up to {{ filesize(attachmentFilesMaxTotalSize) }} in total.
          </BaseInputHelpText>
        </div>
      </div>
    </template>
    <template #footer>
      <BaseButton
        v-if="!chat.rto_sent && client.rto_emails.length > 0"
        :disabled="!emailTo || !rtoFor || isSending || !app.online || !app.livechatOnline"
        @click="submit"
      >
        Send email
      </BaseButton>
      <BaseButton
        variant="gray-outline"
        :class="{ 'ml-3': !chat.rto_sent && client.rto_emails.length > 0 }"
        @click="closeModal"
      >
        Close
      </BaseButton>
    </template>
  </BaseModal>
</template>

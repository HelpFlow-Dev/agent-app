<script setup>
import validator from 'validator';
import { useToast } from '@/stores/toasts';
import BaseButton from '@/components/BaseButton.vue';
import BaseInputLabel from '@/components/BaseInputLabel.vue';
import BaseInputHelpText from '@/components/BaseInputHelpText.vue';
import BaseModal from '@/components/BaseModal.vue';
import BaseTextarea from '@/components/BaseTextarea.vue';
import Bugsnag from '@bugsnag/js';

const toast = useToast();

let description = $ref('');
let formErrors = $ref({});

const emit = defineEmits(['close']);

function submit() {
  // Validate inputs
  if (validator.isEmpty(description)) {
    formErrors['description'] = 'Description must not be empty.';
  } else if (!validator.isLength(description, { max: 1000 })) {
    formErrors['description'] = 'Description may not be greater than 1000 characters.';
  }

  // Prevent submitting form with errors
  if (Object.keys(formErrors).length) return false;

  Bugsnag.notify(
    new Error('Bug report from agent: ' + description),
    function (event) {
      event.severity = 'warning';
      event.unhandled = true;
    },
    function (err, event) {
      if (err) {
        toast.bugReportSubmissionFailed();
      } else {
        toast.bugReportSubmitted();
      }
    }
  );

  description = '';
  formErrors = {};

  emit('close');
}
</script>

<template>
  <BaseModal size="lg" :use-white-background="true" @close="$emit('close')">
    <template #title>Report a bug</template>
    <template #default>
      <div>
        <BaseInputLabel>Bug description</BaseInputLabel>
        <BaseTextarea
          placeholder="Please describe the issue and how to reproduce it..."
          rows="3"
          :has-error="formErrors.hasOwnProperty('description')"
          v-model.trim="description"
          @input="delete formErrors['description']"
        />

        <BaseInputHelpText>{{ formErrors['description'] }}</BaseInputHelpText>

        <BaseInputHelpText variant="info">
          Developers will receive this report along with additional data from your browser.
        </BaseInputHelpText>

        <BaseInputHelpText variant="info">
          If the issue is critical to your work, please also create a bug report in Asana.
        </BaseInputHelpText>
      </div>
    </template>
    <template #footer>
      <BaseButton variant="primary" @click="submit">Send bug report</BaseButton>
      <BaseButton class="ml-3" variant="gray-outline" @click="$emit('close')">Cancel</BaseButton>
    </template>
  </BaseModal>
</template>

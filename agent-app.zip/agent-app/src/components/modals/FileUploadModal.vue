<script setup>
import { computed, inject, onMounted, onUnmounted, watch } from 'vue';
import axios from 'axios';
import objectPath from 'object-path';
import { partial } from 'filesize';
import { useMagicKeys, whenever } from '@vueuse/core';
import { useChatsStore } from '@/stores/chats';
import { useToast } from '@/stores/toasts';
import BaseButton from '@/components/BaseButton.vue';
import BaseModal from '@/components/BaseModal.vue';
import FilePreviewList from '@/components/FilePreviewList.vue';

const appEnvironment = inject('appEnvironment');
const delay = inject('delay');
const emitter = inject('emitter');
const filesize = partial({ base: 2, round: 2, pad: true, standard: 'jedec' });
const chats = useChatsStore();
const keys = useMagicKeys();
const toast = useToast();

const props = defineProps({
  show: {
    type: Boolean,
    default: false,
  },
  chat: {
    type: Object,
    required: true,
  },
});

let files = $ref([]);
let isSending = $ref(false);
let fileSizeSoftLimit = $ref(10485760); // 10 MB in binary units (base-2)
let fileSizeHardLimit = $ref(104857600); // 100 MB in binary units (base-2)

const canSend = computed(() => {
  return !isSending && sendableFiles.value.length > 0;
});

// Files that can be uploaded (either to LiveChat or to our own cloud storage)
const sendableFiles = computed(() => {
  return files.filter((file) => file.size <= fileSizeHardLimit);
});

// Files that can be uploaded directly to LiveChat
const smallFiles = computed(() => {
  return files.filter((file) => file.size <= fileSizeSoftLimit);
});

// Files that can be uploaded only to our own cloud storage
const largeFiles = computed(() => {
  return files.filter((file) => file.size > fileSizeSoftLimit && file.size <= fileSizeHardLimit);
});

// Files that cannot be uploaded
const oversizedFiles = computed(() => {
  return files.filter((file) => file.size > fileSizeHardLimit);
});

// Files that are already uploaded
const uploadedFiles = computed(() => {
  return files.filter((file) => file.isUploaded === true);
});

watch(() => files, handleFilesChanged);

// Upload and send using enter key
whenever(keys.enter, () => {
  if (props.show) uploadAndSendFiles();
});

onMounted(() => {
  emitter.on('files-selected', handleFilesSelected);
});

onUnmounted(() => {
  emitter.off('files-selected', handleFilesSelected);

  props.chat.selected_files_count = 0;
});

function handleFilesSelected(data) {
  if (props.chat.id === data.chatId) {
    if (appEnvironment !== 'production') console.debug('[emitter:FileUploadModal] files-selected', data);

    addFiles(data.files);
  }
}

function onFileRemoved(file) {
  removeFile(file);
}

function removeFile(uploadedFile) {
  files = files.filter((file) => file.id !== uploadedFile.id);

  // Send typing indicator when agent removes a file
  chats.sendTypingIndicator(props.chat.id);
}

function openFilePicker() {
  let fileInput = document.getElementById('active-chat-file-input');

  if (fileInput) fileInput.click();
}

function handleFilesChanged() {
  if (files.length) chats.showFileUploadModal(props.chat);

  props.chat.selected_files_count = files.length;
}

function closeModal() {
  props.chat.show_file_upload_modal = false;
}

function addFiles(selectedFiles) {
  let convertedFiles = [];

  if (selectedFiles.length) {
    for (let i = 0; i < selectedFiles.length; i++) {
      convertedFiles.push(convertFile(selectedFiles[i]));
    }
  }

  if (convertedFiles.length) {
    // Send typing indicator when agent adds files
    chats.sendTypingIndicator(props.chat.id);
  }

  // Remove duplicate files
  convertedFiles = convertedFiles.filter((convertedFile) => !files.some((file) => file.id === convertedFile.id));

  files = files.concat(convertedFiles);
}

// Converts JS File object to our own file object
function convertFile(file) {
  return {
    id: `${file.name}-${file.size}-${file.lastModified}-${file.type}`,
    file: file,
    name: file.name,
    type: file.type,
    size: file.size,
    uploadError: null,
    isUploading: false,
    isUploaded: false,
    isQueuedForUpload: false,
  };
}

async function uploadAndSendFiles() {
  if (isSending) return;

  isSending = true;

  // Send typing indicator when agent starts uploading files
  chats.sendTypingIndicator(props.chat.id);

  oversizedFiles.value.forEach((file) => {
    file.isUploaded = false;
    file.uploadError = 'File size is too large';
  });

  sendableFiles.value.forEach((file) => {
    file.isQueuedForUpload = true;
  });

  for (let i = 0; i < sendableFiles.value.length; i++) {
    await sendFileMessage(sendableFiles.value[i], props.chat.id);
  }

  if (uploadedFiles.value.length > 0) {
    toast.filesUploaded(uploadedFiles.value.length);
  }

  if (props.show) {
    // Close modal with a small delay so that user can see the upload progress
    await delay(300);
    closeModal();
  }

  isSending = false;

  files = [];
}

async function sendFileMessage(file) {
  let chat = chats.getChat(props.chat.id);

  file.isUploading = true;
  file.isQueuedForUpload = false;

  if (!chat || chat.is_deactivated) {
    file.isUploaded = false;
    file.uploadError = !chat
      ? 'chat #' + props.chat.id + ' not found'
      : 'chat #' + props.chat.id + ' is not active';

    toast.fileUploadFailed(file, file.uploadError);

    return false;
  }

  let formData = new FormData();
  formData.append('file', file.file);

  // Small files will be uploaded to LiveChat, large files will be uploaded to HelpFlow storage
  await axios
    .post('/api/chats/' + chat.current_thread_id + '/upload-file', formData, {
      headers: { 'Content-Type': 'multipart/form-data' },
    })
    .then(function (response) {
      file.isUploaded = true;

      if (response.data.livechat_file_url) {
        chats.sendMessage(chat, {
          chat_id: chat.id,
          livechat_file_url: response.data.livechat_file_url,
          is_private: chat.is_private_message_mode,
        });
      } else {
        chats.sendMessage(chat, {
          chat_id: chat.id,
          message: response.data.url,
          is_private: chat.is_private_message_mode,
        });
      }
    })
    .catch(function (error) {
      file.isUploaded = false;
      file.uploadError = 'unknown error';

      if (objectPath.has(error, 'response.data.message')) {
        file.uploadError = objectPath.get(error, 'response.data.message');
      } else if (objectPath.has(error, 'message')) {
        file.uploadError = objectPath.get(error, 'message');
      }

      toast.fileUploadFailed(file, file.uploadError);
    })
    .finally(function () {
      file.isUploading = false;
    });
}
</script>

<template>
  <BaseModal :show="chat.show_file_upload_modal" size="sm" @close="closeModal">
    <template #title>Upload and send files</template>
    <template #default>
      <div v-if="oversizedFiles.length" class="mb-1.5">
        Files larger than
        <span class="font-semibold">{{ filesize(fileSizeHardLimit) }}</span>
        can't be uploaded and will be skipped:
      </div>
      <div v-if="oversizedFiles.length">
        <FilePreviewList
          :files="oversizedFiles"
          :can-remove="!isSending"
          :file-size-soft-limit="fileSizeSoftLimit"
          :file-size-hard-limit="fileSizeHardLimit"
          @file-removed="onFileRemoved"
        />
      </div>

      <div v-if="largeFiles.length" class="mb-1.5">
        Files larger than
        <span class="font-semibold">
          {{ filesize(fileSizeSoftLimit) }}
        </span>
        will be uploaded to our storage and sent as links:
      </div>
      <div v-if="largeFiles.length">
        <FilePreviewList
          :files="largeFiles"
          :can-remove="!isSending"
          :file-size-soft-limit="fileSizeSoftLimit"
          :file-size-hard-limit="fileSizeHardLimit"
          @file-removed="onFileRemoved"
        />
      </div>

      <div v-if="smallFiles.length" class="mb-1.5">Ready to send:</div>
      <div v-if="smallFiles.length">
        <FilePreviewList
          :files="smallFiles"
          :can-remove="!isSending"
          :file-size-soft-limit="fileSizeSoftLimit"
          :file-size-hard-limit="fileSizeHardLimit"
          @file-removed="onFileRemoved"
        />
      </div>

      <BaseButton
        class="mr-3"
        variant="primary"
        icon-before="fa-solid fa-plus"
        :disabled="isSending"
        @click="openFilePicker"
      >
        Choose files
      </BaseButton>
    </template>
    <template #footer>
      <BaseButton
        class="mr-3"
        variant="primary-outline"
        icon-before="fa-regular fa-circle-up"
        :show-loader="isSending"
        :disabled="!canSend"
        @click="uploadAndSendFiles"
      >
        <span v-if="isSending">Uploading...</span>
        <span v-else-if="!isSending && sendableFiles.length > 1"
          >Send {{ sendableFiles.length }} files
        </span>
        <span v-else-if="!isSending && sendableFiles.length <= 1">Send file</span>
      </BaseButton>
      <BaseButton @click="closeModal" variant="gray-outline">
        Close
      </BaseButton>
    </template>
  </BaseModal>
</template>

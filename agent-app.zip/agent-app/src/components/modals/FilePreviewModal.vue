<script setup>
import { inject, computed, onMounted } from 'vue';
import { openInNewTab } from '@/helpers';
import heic2any from 'heic2any';
import BaseButton from '@/components/BaseButton.vue';
import BaseModal from '@/components/BaseModal.vue';
import BaseTextMessage from '@/components/BaseTextMessage.vue';

const delay = inject('delay');

let heicImageUrl = $ref(null);
let heicFailedToConvert = $ref(null);

const props = defineProps({
  fileType: {
    type: String,
    default: 'image',
    validator(value) {
      // The value must match one of these strings
      return ['image', 'image-heic', 'file'].includes(value);
    },
  },
  url: {
    type: String,
    required: true,
  },
  fileName: {
    type: String,
    default: '',
  },
});

const emit = defineEmits(['close']);

onMounted(() => {
  if (props.fileType === 'image-heic') {
    convertHeicImageForPreview();
  }
});

function convertHeicImageForPreview() {
  fetch(props.url)
    .then((res) => res.blob())
    .then((blob) => heic2any({ blob, toType: 'image/jpeg' }))
    .then((conversionResult) => {
      heicImageUrl = URL.createObjectURL(conversionResult);
    })
    .catch((e) => {
      console.error(e);

      closeModal();

      heicFailedToConvert = true;
    });
}

const downloadFileIconClass = computed(() => {
  if (props.fileType === 'file') return 'fa-solid fa-circle-down';

  return 'fa-solid fa-square-arrow-up-right';
});

const modalSize = computed(() => {
  if (props.fileType === 'file' || heicFailedToConvert) {
    return 'default';
  }

  return '3xl';
});

async function openFileInNewTab() {
  closeModal();

  await delay(100); // We want modal closing animation to finish

  if (heicImageUrl) {
    openInNewTab(heicImageUrl);
  } else {
    openInNewTab(props.url);
  }
}

function closeModal() {
  emit('close');
}
</script>

<template>
  <BaseModal :size="modalSize" :use-white-background="true" @close="closeModal">
    <template #title>File preview</template>
    <template #default>
      <div v-if="fileType === 'image'" class="flex flex-col items-center justify-center">
        <img :src="url" class="max-h-[75vh] rounded" draggable="false" />
        <BaseTextMessage v-if="fileName" class="mt-3" :grow="false">
          {{ fileName }}
        </BaseTextMessage>
      </div>
      <div v-else-if="fileType === 'image-heic'" class="flex items-center justify-center">
        <div v-if="heicFailedToConvert">
          <BaseTextMessage class="my-6" variant="danger" :grow="false">
            Failed to load the file.
          </BaseTextMessage>
        </div>
        <div v-else-if="heicImageUrl">
          <img :src="heicImageUrl" class="max-h-[75vh] rounded" draggable="false" />

          <BaseTextMessage v-if="fileName" class="mt-3" :grow="false">
            {{ fileName }}
          </BaseTextMessage>
        </div>
        <div v-else>
          <BaseTextMessage class="my-6" :grow="false">
            Loading the file...
          </BaseTextMessage>
        </div>
      </div>
      <div v-else class="flex items-center justify-center">
        <BaseTextMessage class="my-6" :grow="false">
          Cannot preview this file type.
        </BaseTextMessage>
      </div>
    </template>
    <template #footer>
      <BaseButton
        class="mr-3"
        :icon-before="downloadFileIconClass"
        variant="primary-outline"
        @click="openFileInNewTab"
      >
        <span v-if="fileType === 'file'">Download file</span>
        <span v-else>Open in a new tab</span>
      </BaseButton>
      <BaseButton variant="gray-outline" @click="closeModal">Cancel</BaseButton>
    </template>
  </BaseModal>
</template>

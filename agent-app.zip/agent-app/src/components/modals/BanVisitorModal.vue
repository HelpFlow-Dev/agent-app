<script setup>
import validator from 'validator';
import { useAppStore } from '@/stores/app';
import { useChatsStore } from '@/stores/chats';
import BaseButton from '@/components/BaseButton.vue';
import BaseInputLabel from '@/components/BaseInputLabel.vue';
import BaseInputHelpText from '@/components/BaseInputHelpText.vue';
import BaseModal from '@/components/BaseModal.vue';
import BaseRadioSelect from '@/components/BaseRadioSelect.vue';
import BaseTextarea from '@/components/BaseTextarea.vue';

const app = useAppStore();
const chats = useChatsStore();

let reason = $ref('');
let duration = $ref(3); // Default ban duration is 3 days
let formErrors = $ref({});

const emit = defineEmits(['close']);

function submit() {
  // Validate inputs
  if (validator.isEmpty(reason)) {
    formErrors['reason'] = 'Reason must not be empty.';
  } else if (!validator.isLength(reason, { max: 1000 })) {
    formErrors['reason'] = 'Reason may not be greater than 1000 characters.';
  }

  // Prevent submitting form with errors
  if (Object.keys(formErrors).length) return false;

  chats.banVisitor(chats.activeChat, duration, reason);

  reason = '';
  formErrors = {};

  emit('close');
}
</script>

<template>
  <BaseModal size="lg" :use-white-background="true" @close="$emit('close')">
    <template #title>Ban visitor</template>
    <template #default>
      <div class="mb-3">
        <BaseInputLabel>Reason</BaseInputLabel>
        <BaseTextarea
          placeholder="Enter reason..."
          rows="2"
          :has-error="formErrors.hasOwnProperty('reason')"
          v-model.trim="reason"
          @input="delete formErrors['reason']"
        />

        <BaseInputHelpText>{{ formErrors['reason'] }}</BaseInputHelpText>
      </div>

      <div class="mb-3">
        <BaseInputLabel>Duration</BaseInputLabel>
        <div class="flex w-full">
          <BaseRadioSelect
            v-for="(item, index) in app.visitorBanDurations"
            :key="index"
            class="mr-1.5 w-1/2"
            :active="duration === item.duration"
            @click="duration = item.duration"
          >
            {{ item.label }}
          </BaseRadioSelect>
        </div>

        <BaseInputHelpText variant="info">
          Visitor will be banned for {{ duration }} {{ duration === 1 ? 'day' : 'days' }}.
        </BaseInputHelpText>
      </div>

      <div>
        <BaseInputHelpText variant="info">
          Banned visitors will not see the chat widget or receive targeted messages.
        </BaseInputHelpText>
      </div>
    </template>
    <template #footer>
      <BaseButton icon-before="fa-solid fa-ban" variant="danger-outline" @click="submit">
        Ban visitor
      </BaseButton>
      <BaseButton class="ml-3" variant="gray-outline" @click="$emit('close')">Cancel</BaseButton>
    </template>
  </BaseModal>
</template>

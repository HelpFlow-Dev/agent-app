<script setup>
import { nextTick, watch } from 'vue';
import validator from 'validator';
import { useAgentsStore } from '@/stores/agents';
import { useCannedResponsesStore } from '@/stores/cannedResponses';
import { useClientsStore } from '@/stores/clients';
import BaseButton from '@/components/BaseButton.vue';
import BaseInput from '@/components/BaseInput.vue';
import BaseInputLabel from '@/components/BaseInputLabel.vue';
import BaseInputHelpText from '@/components/BaseInputHelpText.vue';
import BaseModal from '@/components/BaseModal.vue';
import BaseRadioSelect from '@/components/BaseRadioSelect.vue';
import BaseTextarea from '@/components/BaseTextarea.vue';

const agents = useAgentsStore();
const cannedResponses = useCannedResponsesStore();
const clients = useClientsStore();

let shortcut = $ref('');
let responseText = $ref('');
let clientId = $ref(null);
let userId = $ref(null);
let formErrors = $ref({});

const props = defineProps({
  show: {
    type: Boolean,
    default: false,
  },
  event: {
    type: Object,
    required: false,
  },
});

const emit = defineEmits(['close']);

watch(() => props.show, handleModalVisibilityChange);

function handleModalVisibilityChange() {
  if (props.show) {
    responseText = props.event.text;

    nextTick(() => {
      let input = document.getElementById('add-canned-response-modal-shortcut-input');

      if (input) input.focus();
    });
  } else {
    shortcut = '';
    clientId = null;
    userId = null;
    formErrors = {};
  }
}

function submit() {
  // Validate inputs
  if (validator.isEmpty(shortcut)) {
    formErrors['shortcut'] = 'Shortcut must not be empty.';
  } else if (!validator.isAlphanumeric(shortcut, 'en-US', { ignore: '_-' })) {
    formErrors['shortcut'] = 'Shortcut may only contain letters, numbers, dashes and underscores.';
  } else if (!validator.isLength(shortcut, { max: 32 })) {
    formErrors['shortcut'] = 'Shortcut may not be greater than 32 characters.';
  }

  if (validator.isEmpty(responseText)) {
    formErrors['response_text'] = 'Response must not be empty.';
  }

  // Prevent submitting form with errors
  if (Object.keys(formErrors).length) return false;

  cannedResponses.store({
    shortcut: shortcut,
    response_text: responseText,
    client_id: clientId,
    user_id: userId,
  });

  emit('close');
}
</script>

<template>
  <BaseModal size="lg" :show="show" :use-white-background="true" @close="$emit('close')">
    <template #title>Save reply as canned response</template>
    <template #default>
      <div class="mb-3">
        <BaseInputLabel>Shortcut</BaseInputLabel>
        <div class="relative flex">
          <i class="fa-solid fa-hashtag absolute left-3 top-3 text-gray-400"></i>
          <BaseInput
            id="add-canned-response-modal-shortcut-input"
            variant="with-icon"
            placeholder="Enter shortcut..."
            :has-error="formErrors.hasOwnProperty('shortcut')"
            v-model.trim="shortcut"
            @input="delete formErrors['shortcut']"
          />
        </div>
        <BaseInputHelpText variant="info">
          Something short and easy to remember, for example #welcome
        </BaseInputHelpText>
        <BaseInputHelpText>{{ formErrors['shortcut'] }}</BaseInputHelpText>
      </div>

      <div class="mb-3">
        <BaseInputLabel>Response</BaseInputLabel>
        <BaseTextarea
          placeholder="Enter response..."
          rows="4"
          :has-error="formErrors.hasOwnProperty('response_text')"
          v-model.trim="responseText"
          @input="delete formErrors['response_text']"
        />
        <BaseInputHelpText>{{ formErrors['response_text'] }}</BaseInputHelpText>
      </div>

      <div class="mb-3">
        <BaseInputLabel>Canned response availability by client</BaseInputLabel>
        <div class="flex w-full">
          <BaseRadioSelect
            class="mr-1.5 w-1/2"
            :active="clientId === null"
            @click="clientId = null"
          >
            Available for all clients
          </BaseRadioSelect>
          <BaseRadioSelect
            v-if="clients.activeClient.code !== 'General'"
            class="ml-1.5 w-1/2"
            :active="clientId === clients.activeClientId"
            @click="clientId = clients.activeClientId"
          >
            Available only for {{ clients.activeClient.code }}
          </BaseRadioSelect>
        </div>
        <BaseInputHelpText v-if="clientId === null" variant="info">
          Response will be available for all chats
        </BaseInputHelpText>
        <BaseInputHelpText v-else-if="clientId === clients.activeClientId" variant="info">
          Response will be available only for {{ clients.activeClient.code }} chats
        </BaseInputHelpText>
      </div>

      <div>
        <BaseInputLabel>Canned response privacy</BaseInputLabel>
        <div class="flex w-full">
          <BaseRadioSelect class="mr-1.5 w-1/2" :active="userId === null" @click="userId = null">
            Shared
          </BaseRadioSelect>
          <BaseRadioSelect
            class="ml-1.5 w-1/2"
            :active="userId === agents.agent.user_id"
            @click="userId = agents.agent.user_id"
          >
            Private
          </BaseRadioSelect>
        </div>
        <BaseInputHelpText v-if="userId === null" variant="info">
          All agents will have access to this canned response
        </BaseInputHelpText>
        <BaseInputHelpText v-else-if="userId === agents.agent.user_id" variant="info">
          Only you will have access to this canned response
        </BaseInputHelpText>
      </div>
    </template>
    <template #footer>
      <BaseButton @click="submit">Save canned response</BaseButton>
      <BaseButton @click="$emit('close')" variant="gray-outline" class="ml-3">Cancel</BaseButton>
    </template>
  </BaseModal>
</template>

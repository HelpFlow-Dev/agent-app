<script setup>
import { watch } from 'vue';
import validator from 'validator';
import { useChatsStore } from '@/stores/chats';
import BaseButton from '@/components/BaseButton.vue';
import BaseInput from '@/components/BaseInput.vue';
import BaseInputLabel from '@/components/BaseInputLabel.vue';
import BaseCheckbox from '@/components/BaseCheckbox.vue';
import BaseInputHelpText from '@/components/BaseInputHelpText.vue';
import BaseModal from '@/components/BaseModal.vue';

const chats = useChatsStore();

let email = $ref('');
let excludeFullDetails = $ref(0);
let formErrors = $ref({});

const emit = defineEmits(['close']);

const props = defineProps({
  show: {
    type: Boolean,
    default: false,
  },
});

watch(() => props.show, handleModalVisibilityChange);

function handleModalVisibilityChange() {
  if (props.show) {
    email = chats.activeChatVisitor.email || '';
  } else {
    email = '';
    excludeFullDetails = 0;
    formErrors = {};
  }
}

function submit() {
  // Validate inputs
  if (validator.isEmpty(email)) {
    formErrors['email'] = 'Email must not be empty.';
  } else if (!validator.isEmail(email)) {
    formErrors['email'] = 'Email must be a valid email address.';
  }

  // Prevent submitting form with errors
  if (Object.keys(formErrors).length) return false;

  chats.sendChatTranscript(
    chats.activeChat,
    chats.activeChatCurrentThreadId,
    email,
    excludeFullDetails
  );

  emit('close');
}
</script>

<template>
  <BaseModal size="sm" :show="show" :use-white-background="true" @close="$emit('close')">
    <template #title>Send chat transcript to email</template>
    <template #default>
      <div>
        <BaseInputLabel>Email</BaseInputLabel>
        <BaseInput
          :placeholder="'Enter email...'"
          :has-error="formErrors.hasOwnProperty('email')"
          v-model.trim="email"
          @input="delete formErrors['email']"
        />
        <BaseInputHelpText>{{ formErrors['email'] }}</BaseInputHelpText>
      </div>

      <div class="mt-3">
        <div>
          <BaseCheckbox
            v-model="excludeFullDetails"
            :true-value="0"
            :false-value="1"
            :disabled="true"
          >
            Include additional information
          </BaseCheckbox>
        </div>

        <BaseInputHelpText v-if="excludeFullDetails === 0" variant="info">
          Transcript will include all system messages, private messages from supervisors,
          information about client and visitor's location.
        </BaseInputHelpText>
        <BaseInputHelpText v-else variant="info">
          Transcript will include most important system messages, all public messages from visitor
          and agents.
        </BaseInputHelpText>
      </div>
    </template>
    <template #footer>
      <BaseButton @click="submit">Send transcript</BaseButton>
      <BaseButton @click="$emit('close')" variant="gray-outline" class="ml-3">Cancel</BaseButton>
    </template>
  </BaseModal>
</template>

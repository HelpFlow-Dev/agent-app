<script setup>
import { computed, nextTick, onUnmounted, watch } from 'vue';
import { useMagicKeys, whenever } from '@vueuse/core';
import { useAgentsStore } from '@/stores/agents';
import { useChatsStore } from '@/stores/chats';
import BaseAvatar from '@/components/BaseAvatar.vue';
import BaseButton from '@/components/BaseButton.vue';
import BaseInput from '@/components/BaseInput.vue';
import BaseModal from '@/components/BaseModal.vue';
import BaseRadioSelect from '@/components/BaseRadioSelect.vue';
import BaseTextMessage from '@/components/BaseTextMessage.vue';

const agents = useAgentsStore();
const chats = useChatsStore();
const keys = useMagicKeys();

const props = defineProps({
  show: {
    type: Boolean,
    default: false,
  },
});

const emit = defineEmits(['close']);

let selectedAgentId = $ref(null);
let searchValue = $ref('');
let availableAgents = $ref([]);
let polling = $ref(null);

watch(() => props.show, handleModalVisibilityChange);

// Confirm using enter key
whenever(keys.enter, () => {
  if (props.show && selectedAgentId) {
    transferChat();
  }
});

const filteredAgents = computed(() => {
  // Filter agents by display_name
  if (searchValue.trim().length) {
    return availableAgents.filter(function (agent) {
      return agent.display_name.toLowerCase().includes(searchValue.toLowerCase());
    });
  }

  return availableAgents;
});

function transferChat() {
  chats.transferChat(chats.activeChat, selectedAgentId);

  emit('close');
}

function canTransferChatToAgent(agentId) {
  return availableAgents.find((availableAgent) => availableAgent.agent_id === agentId);
}

async function getAgentsForChatTransfer() {
  // Close modal if chat is deactivated
  if (chats.activeChat.is_deactivated) {
    emit('close');
  } else {
    availableAgents = await chats.getAgentsForChatTransfer(chats.activeChat);

    availableAgents.map(function (item) {
      let agent = agents.getAgentByLivechatId(item.agent_id);

      item.display_name = agent ? agent.display_name : item.agent_id;
      item.avatar_url = agent ? agent.avatar_url : null;
      item.is_available = agent ? agent.livechat_routing_status === 'accepting_chats' : false;

      return item;
    });
  }
}

async function pollAvailableAgents(ms) {
  polling = setInterval(getAgentsForChatTransfer, ms);
}

function handleModalVisibilityChange() {
  if (props.show) {
    // Get available agents immediately
    getAgentsForChatTransfer();

    // Then start polling for changes every 2 seconds
    pollAvailableAgents(2000);

    nextTick(() => {
      let searchInput = document.getElementById('agent-transfer-search-input');

      if (searchInput) searchInput.focus();
    });
  } else {
    searchValue = '';
    selectedAgentId = null;
    availableAgents = [];

    clearInterval(polling);
  }
}

onUnmounted(() => {
  clearInterval(polling);
});
</script>

<template>
  <BaseModal size="sm" :show="show" @close="$emit('close')">
    <template #title>Transfer chat to...</template>
    <template #default>
      <div class="relative flex flex-col pb-3">
        <div class="relative flex">
          <i class="fa-solid fa-magnifying-glass absolute left-3 top-3 text-gray-400"></i>

          <BaseInput
            id="agent-transfer-search-input"
            variant="with-icon"
            placeholder="Search..."
            v-model="searchValue"
          />
        </div>
      </div>

      <div v-if="filteredAgents.length" class="flex flex-col">
        <BaseRadioSelect
          v-for="(item, index) in filteredAgents"
          :class="{ 'mt-3': index > 0 }"
          :key="item.agent_id"
          :active="selectedAgentId === item.agent_id"
          @click="
            selectedAgentId === item.agent_id
              ? (selectedAgentId = null)
              : (selectedAgentId = item.agent_id)
          "
        >
          <BaseAvatar
            v-if="item.avatar_url"
            class="mr-3 self-center"
            :url="item.avatar_url"
            :is-available="item.is_available"
            :size="40"
          />
          <BaseAvatar
            v-else
            class="mr-3 self-center"
            :text="item.display_name"
            :is-available="item.is_available"
            :size="40"
          />
          <div class="flex w-full flex-col truncate leading-5">
            <div class="truncate">
              {{ item.display_name }}
            </div>
            <div v-if="item.total_active_chats === 0" class="truncate text-gray-400">
              No active chats
            </div>
            <div v-else-if="item.total_active_chats === 1" class="truncate text-gray-400">
              {{ item.total_active_chats }} active chat
            </div>
            <div v-else-if="item.total_active_chats > 1" class="truncate text-gray-400">
              {{ item.total_active_chats }} active chat
            </div>
          </div>
        </BaseRadioSelect>
      </div>
      <div v-else class="my-6 flex flex-col">
        <BaseTextMessage v-if="!availableAgents.length" class="leading-5" :grow="false">
          No agents in <span class="font-semibold">{{ chats.activeChat.client_code }}</span> group
          available for transfer.
        </BaseTextMessage>
        <BaseTextMessage v-else class="leading-5" :grow="false">No agents found.</BaseTextMessage>
      </div>
    </template>
    <template #footer>
      <BaseButton
        variant="primary-outline"
        icon-before="fa-solid fa-arrow-right"
        :disabled="!canTransferChatToAgent(selectedAgentId)"
        @click="transferChat"
      >
        <span>Transfer chat</span>
      </BaseButton>
      <BaseButton @click="$emit('close')" variant="gray-outline" class="ml-3">Cancel</BaseButton>
    </template>
  </BaseModal>
</template>

<script setup>
import { watch } from 'vue';
import { useMagicKeys, whenever } from '@vueuse/core';
import { useAppStore } from '@/stores/app';
import { useChatsStore } from '@/stores/chats';
import BaseButton from '@/components/BaseButton.vue';
import BaseModal from '@/components/BaseModal.vue';

const app = useAppStore();
const chats = useChatsStore();
const keys = useMagicKeys();

const props = defineProps({
  show: {
    type: Boolean,
    default: false,
  },
  chat: {
    type: Object,
    required: true,
  },
});

let showChangelogModal = $ref(false);
let confirmedClosingWithoutSendingRTO = $ref(false);

// Close modal when we switch to a different chat
watch(() => chats.activeChatId, closeModal);

// Confirm using enter key
whenever(keys.enter, () => {
  if (props.show) handleActionConfirmed();
});

function handleActionConfirmed() {
  if (props.chat.status === 'supervising') {
    chats.stopAndCloseChat(props.chat);
    closeModal();
  } else if (!props.chat.is_deactivated) {
    chats.stopChat(props.chat);
    closeModal();
  } else if (chats.checkIfAgentHasToSendRTO(props.chat) && !confirmedClosingWithoutSendingRTO) {
    confirmedClosingWithoutSendingRTO = true;
  } else if (props.chat.is_deactivated) {
    chats.stopAndCloseChat(props.chat);
    closeModal();
  }

  // Don't close modal in other cases
}

function closeModal() {
  props.chat.show_close_chat_confirmation_modal = false;
  confirmedClosingWithoutSendingRTO = false;
}
</script>

<template>
  <BaseModal :show="show" @close="closeModal">
    <template #title>
      <span v-if="chat.status === 'supervising'">
        Stop supervising this chat?
      </span>
      <span v-else-if="chat.is_deactivated">
        Close this chat?
      </span>
      <span v-else>
        Stop this chat?
      </span>
    </template>
    <template #default>
      <div v-if="chat.status === 'supervising'">
        Are you sure you want to stop supervising the <span class="font-bold">{{ chat.client_code }}</span> chat #<span class="font-bold">{{ chat.current_thread_id }}</span>?
      </div>
      <div v-else-if="!chat.is_deactivated">
        Are you sure you want to stop the <span class="font-bold">{{ chat.client_code }}</span> chat #<span class="font-bold">{{ chat.current_thread_id }}</span> with <span class="font-bold">{{ chat.visitor.name }}</span>?
      </div>
      <div v-else-if="chats.checkIfAgentHasToSendRTO(chat) && !confirmedClosingWithoutSendingRTO">
        <!-- TODO-HAS: make an element BaseWarningMessage -->
        <div class="bg-white border-rose-500 border-2 rounded-md p-3 text-rose-500 mb-3">
          <span class="font-bold">Warning:</span> RTO email hasn't been sent!
        </div>
        <div>
          Are you sure you want to close the <span class="font-bold">{{ chat.client_code }}</span> chat #<span class="font-bold">{{ chat.current_thread_id }}</span> without sending RTO?
        </div>
      </div>
      <div v-else>
        Are you sure you want to close the <span class="font-bold">{{ chat.client_code }}</span> chat #<span class="font-bold">{{ chat.current_thread_id }}</span>?
      </div>
    </template>
    <template #footer>
      <BaseButton
        :variant="!chat.is_deactivated || (chat.is_deactivated && chats.checkIfAgentHasToSendRTO(chat) && !confirmedClosingWithoutSendingRTO) ? 'danger' : 'primary'"
        :disabled="!app.online || !app.livechatOnline"
        @click="handleActionConfirmed()"
      >
        <span v-if="chat.status === 'supervising'">
          Stop supervising this chat
        </span>
        <span v-else-if="!chat.is_deactivated">
          Stop this chat
        </span>
        <span v-else-if="chat.is_deactivated && chats.checkIfAgentHasToSendRTO(chat) && !confirmedClosingWithoutSendingRTO">
          Continue without sending RTO
        </span>
        <span v-else>
          Close this chat
        </span>
      </BaseButton>
      <BaseButton
        variant="gray-outline"
        class="ml-3"
        @click="closeModal"
      >
        Close
      </BaseButton>
    </template>
  </BaseModal>
</template>

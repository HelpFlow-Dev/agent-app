<script setup>
import BaseModal from '@/components/BaseModal.vue';
import changelog from '../../../CHANGELOG.md';
</script>

<template>
  <BaseModal @close="$emit('close')">
    <template #title>Changelog</template>
    <template #default>
      <div v-html="changelog" class="markdown-body"></div>
    </template>
  </BaseModal>
</template>

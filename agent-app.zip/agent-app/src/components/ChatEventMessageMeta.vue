<script setup>
import { DateTime } from 'luxon';

defineProps({
  chat: {
    type: Object,
    required: true,
  },
  event: {
    type: Object,
    required: true,
  },
  isInMessageBubble: {
    type: Boolean,
    default: false,
  },
});
</script>

<template>
  <span
    class="flex select-none items-center"
    :class="{
      'ml-auto mt-0.5': !isInMessageBubble,
      'relative bottom-auto right-0 top-1.5 float-right -mr-1 ml-1 px-1 leading-6':
        isInMessageBubble,
    }"
  >
    <div
      class="whitespace-nowrap text-[0.75rem]"
      v-tooltip="event.created_at.toLocaleString(DateTime.DATETIME_FULL_WITH_SECONDS)"
    >
      {{ event.created_at.toLocaleString(DateTime.TIME_WITH_SECONDS) }}
    </div>
    <div
      v-if="event.author_is_agent && event.visibility === 'agents'"
      class="ml-1 text-[0.75rem]"
      v-tooltip="'Private message, visible only to other agents'"
    >
      <i class="fa-regular fa-eye-slash"></i>
    </div>
    <div
      v-else-if="event.author_is_agent ? chat.visitor_events_seen_up_to >= event.created_at : null"
      class="ml-1 text-[0.75rem]"
      v-tooltip="'Message has been read'"
    >
      <i class="fa-regular fa-circle-check"></i>
    </div>
    <div
      v-else-if="event.author_is_agent && event.visibility === 'all'"
      class="ml-1 text-[0.75rem]"
      v-tooltip="'Message has been delivered'"
    >
      <i class="fa-regular fa-circle"></i>
    </div>
  </span>
</template>

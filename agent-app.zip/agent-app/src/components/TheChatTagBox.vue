<script setup>
import { useChatsStore } from '@/stores/chats';
import { useTagsStore } from '@/stores/tags';
import ChatTagInput from '@/components/ChatTagInput.vue';
import ChatTagListItem from '@/components/ChatTagListItem.vue';

const chats = useChatsStore();
const tags = useTagsStore();
</script>

<template>
  <div class="mt-1.5 flex select-none">
    <ChatTagInput />

    <div class="flex max-h-[91px] flex-wrap items-start overflow-y-auto">
      <ChatTagListItem
        v-for="tag in tags.getTagsByIds(tags.getTagIdsForChatThread(chats.activeChat, chats.activeChatCurrentThreadId))"
        :key="tag.id"
        :tag="tag"
      />
    </div>
  </div>
</template>

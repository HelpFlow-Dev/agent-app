<script setup>
defineProps({
  required: {
    type: Boolean,
    default: false,
  },
});
</script>

<template>
  <div class="mb-0.5 font-semibold">
    <slot></slot>
    <span v-if="required" class="ml-0.5 select-none text-rose-500">*</span>
  </div>
</template>

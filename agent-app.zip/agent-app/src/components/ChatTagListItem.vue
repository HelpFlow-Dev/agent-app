<script setup>
import { useChatsStore } from '@/stores/chats';
import { useTagsStore } from '@/stores/tags';

const chats = useChatsStore();
const tags = useTagsStore();

defineProps({
  tag: {
    type: Object,
    required: true,
  },
});
</script>

<template>
  <div
    class="ml-1.5 mt-1.5 flex items-center rounded border-2 px-1.5 py-1 text-sm text-white"
    :class="{
      'bg-yellow-500 border-yellow-500': tag.level === 1,
      'bg-blue-500 border-blue-500': tag.level === 2,
    }"
  >
    <i
      class="fa-solid fa-times fa-fw ml-auto mr-1 flex h-4 w-4 cursor-pointer items-center justify-center rounded transition"
      :class="{
        'hover:bg-yellow-600': tag.level === 1,
        'hover:bg-blue-600': tag.level === 2,
      }"
      @click="tags.removeTagFromChatThread(chats.activeChat, chats.activeChatCurrentThreadId, tag.id)"
    ></i>
    <div>{{ tag.title }}</div>
  </div>
</template>

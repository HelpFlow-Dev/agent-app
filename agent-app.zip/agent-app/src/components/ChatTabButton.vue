<script setup>
import { computed, inject, onBeforeUnmount } from 'vue';
import { DateTime } from 'luxon';
import { useRoute, useRouter } from 'vue-router';
import { useAppStore } from '@/stores/app';
import { useChatsStore } from '@/stores/chats';

const router = useRouter();
const route = useRoute();
const app = useAppStore();
const chats = useChatsStore();
const now = inject('now');

const props = defineProps({
  chat: {
    type: Object,
    required: true,
  },
  client: {
    type: Object,
    required: true,
  },
  secondsSinceLastAgentReply: {
    type: Number,
    required: true,
  },
});

const active = computed(() => {
  return route.name === 'chat' && route.params.id == props.chat.id;
});

onBeforeUnmount(() => {
  // Redirect home when active chat is removed
  if (route.name === 'chat' && route.params.id == props.chat.id) {
    router.push({ name: 'home' });
  }
});
</script>

<template>
  <div
    class="laptop:p-2 relative flex cursor-pointer select-none items-center justify-center rounded-md border-2 p-1 transition"
    :class="{
      'animate-pulse opacity-70 pointer-events-none': !chat.is_loaded,

      'animate-pulse-fast': chats.holdTimeLeftInSeconds(chat) > 0 && chats.holdTimeLeftInSeconds(chat) <= 30,

      'animate-bounce-sm':
        chat.status === 'incoming'
        && !active
        && chat.is_loaded,

      'border-violet-500 bg-white text-violet-500 hover:bg-violet-50 hover:text-violet-500 active:bg-violet-100':
        chat.status === 'incoming'
        && !active
        && !chats.isOnHold(chat),

      'border-emerald-500 bg-white text-emerald-500 hover:border-emerald-500 hover:bg-emerald-50 hover:text-emerald-500 active:bg-emerald-100':
        chat.status === 'ongoing'
        && secondsSinceLastAgentReply <= 90
        && !active
        && !chats.isOnHold(chat),

      'border-emerald-600 bg-emerald-500 text-white':
        ((chat.status === 'ongoing' && secondsSinceLastAgentReply <= 90 && active) || (chat.status === 'incoming' && active))
        && !chats.isOnHold(chat),

      'border-yellow-500 bg-white text-yellow-500 hover:bg-yellow-50 hover:text-yellow-500 active:bg-yellow-100':
        chat.status === 'ongoing'
        && secondsSinceLastAgentReply > 90
        && secondsSinceLastAgentReply <= 120
        && !active
        && !chats.isOnHold(chat),

      'border-yellow-600 bg-yellow-500 text-white':
        chat.status === 'ongoing' &&
        secondsSinceLastAgentReply > 90
        && secondsSinceLastAgentReply <= 120
        && active
        && !chats.isOnHold(chat),

      'border-rose-500 bg-white text-rose-500 hover:bg-rose-50 hover:text-rose-500 active:bg-rose-100':
        chat.status === 'ongoing'
        && secondsSinceLastAgentReply > 120
        && !active
        && !chats.isOnHold(chat),

      'border-rose-700 bg-rose-500 text-white':
        chat.status === 'ongoing'
        && secondsSinceLastAgentReply > 120
        && active
        && !chats.isOnHold(chat),

      'border-gray-400 bg-white text-gray-500 hover:bg-gray-100 active:bg-gray-200':
        chat.status === 'inactive'
        && !active
        && !chats.isOnHold(chat),

      'border-gray-500 bg-gray-400 text-white':
        chat.status === 'inactive'
        && active
        && !chats.isOnHold(chat),

      'border-gray-600 bg-white text-gray-700 hover:bg-gray-200 active:bg-gray-300':
        chat.status === 'supervising'
        && !active
        && !chats.isOnHold(chat),

      'border-gray-700 bg-gray-600 text-white':
        chat.status === 'supervising'
        && active
        && !chats.isOnHold(chat),

      'border-blue-500 bg-white text-blue-500 hover:bg-blue-50 hover:text-blue-500 active:bg-blue-100':
        chats.isOnHold(chat)
        && !active,

      'border-blue-700 bg-blue-500 text-white':
        chats.isOnHold(chat)
        && active,
    }"
  >
    <div class="mr-px flex flex-col overflow-hidden">
      <div class="truncate" v-tooltip="'Client: ' + client.company_name + ' (' + client.code + ')'">
        {{ client.code }}
      </div>
      <div class="truncate" v-tooltip="'Chat thread ID: ' + chat.current_thread_id">
        {{ chat.current_thread_id.substr(chat.current_thread_id.length - 5) }}
      </div>
    </div>

    <div v-if="chats.isOnHold(chat)" class="ml-auto flex shrink-0 flex-col text-right font-mono">
      <div class="flex-1 whitespace-nowrap" v-tooltip="'The chat is currently on hold'">
        ON HOLD
      </div>
      <div
        class="flex-1 whitespace-nowrap text-right"
        v-tooltip="'Total time left before chat is no longer on hold'"
      >
        {{ chats.chatHoldTimerDiffFormatted(chat, now) }}
      </div>
    </div>
    <div v-else-if="chat.is_loaded" class="ml-auto flex shrink-0 flex-col text-right font-mono">
      <div class="flex-1 whitespace-nowrap" v-tooltip="'Total chat time'">
        {{
          chats.chatTimerDiffFormatted(
            chat,
            chat.threads[chat.current_thread_id].created_at,
            null,
            now
          )
        }}
      </div>
      <div
        class="flex-1 whitespace-nowrap text-right"
        v-tooltip="'Total time agent or visitor is waiting for reply from each other'"
      >
        {{
          chats.chatTimerDiffFormatted(
            chat,
            chats.getOtherPartyStartedWaitingTime(chat),
            DateTime.now(),
            now
          )
        }}
      </div>
    </div>

    <div class="shrink-0" :class="{ 'ml-auto': !chat.is_loaded, 'ml-1': chat.is_loaded }">
      <i
        v-if="chat.is_loaded"
        class="fa-solid fa-times fa-fw ml-auto flex h-4 w-4 cursor-pointer items-center justify-center rounded"
        :class="{
          'hover:text-white': !active,

          'text-white': active,

          'hover:bg-violet-500':
            chat.status === 'incoming'
            && !active
            && !chats.isOnHold(chat),

          'hover:bg-emerald-500':
            chat.status === 'ongoing'
            && secondsSinceLastAgentReply <= 90
            && !active
            && !chats.isOnHold(chat),

          'hover:bg-emerald-600':
            ((chat.status === 'ongoing' && secondsSinceLastAgentReply <= 90 && active) || (chat.status === 'incoming' && active))
            && !chats.isOnHold(chat),

          'hover:bg-yellow-600':
            chat.status === 'ongoing'
            && secondsSinceLastAgentReply > 90
            && secondsSinceLastAgentReply <= 120
            && active
            && !chats.isOnHold(chat),

          'hover:bg-yellow-500':
            chat.status === 'ongoing'
            && secondsSinceLastAgentReply > 90
            && secondsSinceLastAgentReply <= 120
            && !active
            && !chats.isOnHold(chat),

          'hover:bg-rose-700':
            chat.status === 'ongoing'
            && secondsSinceLastAgentReply > 120
            && active
            && !chats.isOnHold(chat),

          'hover:bg-rose-500':
            chat.status === 'ongoing'
            && secondsSinceLastAgentReply > 120
            && !active
            && !chats.isOnHold(chat),

          'hover:bg-blue-500': chats.isOnHold(chat) && !active,

          'hover:bg-blue-700': chats.isOnHold(chat) && active,

          'hover:bg-gray-400':
            chat.status === 'inactive'
            && !active
            && !chats.isOnHold(chat),

          'hover:bg-gray-500':
            chat.status === 'inactive'
            && active
            && !chats.isOnHold(chat),

          'hover:bg-gray-600':
            chat.status === 'supervising'
            && !active
            && !chats.isOnHold(chat),

          'hover:bg-gray-800':
            chat.status === 'supervising'
            && active
            && !chats.isOnHold(chat),
        }"
        @click.stop="chats.showCloseChatModal(chat)"
      ></i>
    </div>
    <span
      v-if="chat.is_loaded && (chats.getUnreadMessagesCount(chat) || chat.status === 'incoming')"
      class="absolute right-0 top-0 -mr-1.5 -mt-1.5 flex h-4 w-4"
    >
      <span
        class="absolute inline-flex h-full w-full animate-ping rounded-full bg-rose-400 opacity-75"
      ></span>
      <span
        class="relative inline-flex h-4 w-4 rounded-full border-2 border-white bg-rose-500 shadow"
      ></span>
    </span>
    <span
      v-if="chat.status === 'supervising' && chats.isProspectChat(chat)"
      class="absolute -bottom-px -mb-2.5 -mt-px flex rounded-full border-2 border-inherit bg-inherit px-1.5 pb-px leading-[12px] laptop:leading-[15px] text-inherit"
      v-tooltip="'This chat is being supervised by you and is coming from a possible prospect'"
    >
      supervised • prospect
    </span>
    <span
      v-else-if="chat.status === 'supervising'"
      class="absolute -bottom-px -mb-2.5 -mt-px flex rounded-full border-2 border-inherit bg-inherit px-1.5 pb-px leading-[12px] laptop:leading-[15px] text-inherit"
      v-tooltip="'This chat is being supervised by you'"
    >
      supervised
    </span>
    <span
      v-else-if="chats.isProspectChat(chat)"
      class="absolute -bottom-px -mb-2.5 -mt-px flex rounded-full border-2 border-inherit bg-inherit px-1.5 pb-px leading-[12px] laptop:leading-[15px] text-inherit"
      v-tooltip="'This chat is coming from a possible prospect'"
    >
      prospect
    </span>
  </div>
</template>

<script setup>
import { inject, onMounted, onUnmounted, watch } from 'vue';
import { DateTime } from 'luxon';
import { v4 as uuidv4 } from 'uuid';
import { useScreenRecordingsStore } from '@/stores/screenRecordings';
import Bugsnag from '@bugsnag/js';
import fixWebmDuration from 'fix-webm-duration';
import ScreenRecorderModal from '@/components/modals/ScreenRecorderModal.vue';

const appEnvironment = inject('appEnvironment');
const screenRecordings = useScreenRecordingsStore();
const emitter = inject('emitter');

defineProps({
  showModal: {
    type: Boolean,
    required: true,
  },
});

defineEmits(['closeModal']);

// Intervals
let queueRecordingsInterval = $ref(null);
let uploadRecordingsInterval = $ref(null);

// These messages are not errors and should not be reported to BugSnag
let wembDurationFixNonErrorMessages = $ref([
  '[fix-webm-duration] Duration section is missing',
  '[fix-webm-duration] Duration section is present, but the value is empty',
]);

// We need this to avoid queueing recording multiple times
let lastQueuedAt = $ref(null);

// List of screens
let screens = $ref({
  1: {
    id: 1, // screen number
    stream: null, // MediaStream object
    recorder: null, // MediaRecorder object
    captureStartedAt: null, // the start of screen recording that shows the total time agent is recording the screen
    recordingStartedAt: null, // the time we started recording this last minute of footage
  },
  2: {
    id: 2, // screen number
    stream: null, // MediaStream object
    recorder: null, // MediaRecorder object
    captureStartedAt: null, // the start of screen recording that shows the total time agent is recording the screen
    recordingStartedAt: null, // the time we started recording this last minute of footage
  },
  3: {
    id: 3, // screen number
    stream: null, // MediaStream object
    recorder: null, // MediaRecorder object
    captureStartedAt: null, // the start of screen recording that shows the total time agent is recording the screen
    recordingStartedAt: null, // the time we started recording this last minute of footage
  },
});

onMounted(() => {
  // Upload (or retry uploading) queued recordings every 10 seconds
  uploadRecordingsInterval = setInterval(screenRecordings.uploadRecordings, 1000 * 10);

  emitter.on('screen-recording-pick-screen', (data) => {
    if (appEnvironment !== 'production') {
      console.debug('[emitter:TheScreenRecorder] screen-recording-pick-screen', data);
    }

    startCapture(data.screenId);
  });

  emitter.on('screen-recording-started', (data) => {
    if (appEnvironment !== 'production') {
      console.debug('[emitter:TheScreenRecorder] screen-recording-started', data);
    }

    screenRecordings.recordingInProgress = true;

    if (!screenRecordings.recordingStartedAt) {
      screenRecordings.recordingStartedAt = DateTime.now();
    }
  });

  emitter.on('screen-recording-stopped', (data) => {
    if (appEnvironment !== 'production') {
      console.debug('[emitter:TheScreenRecorder] screen-recording-stopped', data);
    }

    stopCapture(data.screenId);
  });
});

onUnmounted(() => {
  clearInterval(queueRecordingsInterval);
  clearInterval(uploadRecordingsInterval);

  emitter.off('screen-recording-pick-screen');
  emitter.off('screen-recording-stopped');
});

watch(() => screenRecordings.recordingInProgress, handleScreenRecordingToggled);

async function startCapture(screenId) {
  try {
    screens[screenId].stream = await navigator.mediaDevices.getDisplayMedia(
      screenRecordings.displayMediaOptions
    );

    screens[screenId].stream.oninactive = () => {
      emitter.emit('screen-recording-stopped', { screenId: screenId });
    };

    screens[screenId].captureStartedAt = DateTime.now();

    screens[screenId].recorder = new MediaRecorder(
      screens[screenId].stream,
      screenRecordings.recorderOptions
    );

    screens[screenId].recorder.addEventListener('dataavailable', (event) => {
      // We need to handle a rare case where user started and stopped screen capture before recording even began
      let recordingStartedAt =
        screens[screenId].recordingStartedAt === null
          ? DateTime.now()
          : screens[screenId].recordingStartedAt;
      let recordingEndedAt = DateTime.now();

      screens[screenId].recordingStartedAt = null;

      let duration = recordingEndedAt.diff(recordingStartedAt).as('milliseconds');
      let durationFormatted = (duration / 1000).toFixed(2);

      // If recording duration is too small, we won't upload the recording
      // because it's highly likely that agent accidentally started recording
      if (duration > screenRecordings.minDuration * 1000) {
        console.debug('Processing screen recording (duration: ' + durationFormatted + 's)...');

        // Use promise-style call (with disabled logging) for better performance
        fixWebmDuration(event.data, duration, {
          logger: function (message) {
            if (wembDurationFixNonErrorMessages.includes(message)) return false;

            console.error(message);

            Bugsnag.notify(new Error(message), function (event) {
              event.severity = 'warning';
              event.unhandled = true;
            });
          },
        }).then(async function (fixedBlob) {
          let recording = {
            id: uuidv4(),
            screenId: screenId,
            file: fixedBlob,
            startedAt: recordingStartedAt,
            endedAt: recordingEndedAt,
            duration: duration, // in milliseconds
            uploading: false,
            uploaded: false,
          };

          screenRecordings.queue(recording);

          console.debug('Queued a new screen recording:', recording);
        });
      } else {
        console.debug(
          'Screen recording is less than ' +
            screenRecordings.minDuration +
            ' seconds long, skipping...'
        );
      }
    });

    screens[screenId].recorder.addEventListener('start', (event) => {
      screens[screenId].recordingStartedAt = DateTime.now();
    });

    screens[screenId].recorder.addEventListener('stop', (event) => {
      screens[screenId].recordingStartedAt = null;
    });

    screens[screenId].recorder.start();

    emitter.emit('screen-recording-started', { screenId: screenId });
  } catch (e) {
    // Most likely permission was denied
    console.error(e);
  }
}

function stopCapture(screenId) {
  if (screens[screenId].stream !== null) {
    screens[screenId].recorder.stop();

    screens[screenId].stream.getTracks().forEach((track) => track.stop());
    screens[screenId].stream = null;
    screens[screenId].captureStartedAt = null;
  }

  // If we are no longer recording any screen
  if (Object.values(screens).every((element) => element.stream === null)) {
    screenRecordings.recordingInProgress = false;
    screenRecordings.recordingStartedAt = null;
  }
}

function handleScreenRecordingToggled() {
  if (screenRecordings.recordingInProgress) {
    // We need to be sure this AlWAYS runs at :00 seconds
    // because we need to stop and start up to 3 screen recordings in less than 1 second
    // so this is why we run it so often
    queueRecordingsInterval = setInterval(queueRecordings, 100);
  } else {
    // Clear the interval if we're not recording the screen to improve performance
    clearInterval(queueRecordingsInterval);
  }
}

// Every minute at :00 we stop recording and put recordings into queue for uploading
function queueRecordings() {
  let currentTime = new Date(); // We'll use native Date object for the best performance

  if (currentTime.getSeconds() !== 0) return;

  let canBeQueuedAgain = !lastQueuedAt || DateTime.now().diff(lastQueuedAt).as('seconds') >= 45;

  if (!canBeQueuedAgain) return;

  lastQueuedAt = DateTime.now();

  for (const screenId in screens) {
    if (screens[screenId].recorder !== null && screens[screenId].captureStartedAt) {
      screens[screenId].recorder.stop();
      screens[screenId].recorder.start();
    }
  }
}
</script>

<template>
  <ScreenRecorderModal :show="showModal" :screens="screens" @close="$emit('closeModal')" />
</template>

<script setup>
import { useSlots } from 'vue';

const slots = useSlots();

defineProps({
  variant: {
    type: String,
    default: 'error',
    validator(value) {
      // The value must match one of these strings
      return ['error', 'info'].includes(value);
    },
  },
});
</script>

<template>
  <div
    v-if="slots.default"
    class="hide-if-empty mt-0.5 w-full"
    :class="{
      'text-rose-500': variant === 'error',
      'text-gray-500': variant === 'info',
    }"
  >
    <slot></slot>
  </div>
</template>

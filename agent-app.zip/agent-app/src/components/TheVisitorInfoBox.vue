<script setup>
import { computed, inject, watch } from 'vue';
import { DateTime } from 'luxon';
import { useChatsStore } from '@/stores/chats';
import { useClientsStore } from '@/stores/clients';
import { pageVisitDurationFormatted, removeProtocolFromUrl } from '@/helpers';
import BaseButton from '@/components/BaseButton.vue';
import BaseLink from '@/components/BaseLink.vue';
import BaseTextMessage from '@/components/BaseTextMessage.vue';
import VisitedPagesModal from '@/components/modals/VisitedPagesModal.vue';

const chats = useChatsStore();
const clients = useClientsStore();
const now = inject('now');

let showVisitedPagesModal = $ref(false);

const visitorGeolocation = computed(() => chats.getVisitorGeolocation(chats.activeChat));
const visitorIsFromGDPRCountry = computed(() => chats.visitorIsFromGDPRCountry(chats.activeChat));
const visitorLocationFormatted = computed(() => chats.getVisitorLocationFormatted(chats.activeChat, true));
const visitorCountryName = computed(() => chats.getVisitorCountryName(chats.activeChat));
const visitorCountryCode = computed(() => chats.getVisitorCountryCode(chats.activeChat));
const visitorUserAgent = computed(() => { return chats.activeChatVisitor.user_agent; });

const rtoButtonTooltip = computed(() => {
  if (chats.activeChat.rto_sent) {
    return 'This chat has been emailed to client via RTO process';
  }

  if (chats.checkIfAgentHasToSendRTO(chats.activeChat)) {
    return 'You need to email this chat to client via RTO process';
  }

  return 'Email this chat to client via RTO process';
});

const visitorUserAgentOS = computed(() => {
  if (!visitorUserAgent.value) return 'Unknown';

  let os = visitorUserAgent.value.os.name;

  if (visitorUserAgent.value.os.version) {
    os += ' ' + visitorUserAgent.value.os.version;
  }

  return os;
});

const visitorUserAgentBrowser = computed(() => {
  if (!visitorUserAgent.value) return 'Unknown';

  let browser = visitorUserAgent.value.browser.name;

  if (visitorUserAgent.value.browser.version) {
    browser += ' ' + visitorUserAgent.value.browser.version;
  }

  return browser;
});

const osIconClass = computed(() => {
  if (!visitorUserAgent.value) return 'fa-solid fa-desktop';

  if (visitorUserAgent.value.os.name === 'Windows') {
    return 'fa-brands fa-windows';
  }

  if (visitorUserAgent.value.os.name === 'Mac OS') {
    return 'fa-brands fa-apple';
  }

  if (visitorUserAgent.value.os.name === 'Chromium OS') {
    return 'fa-brands fa-chrome';
  }

  if (visitorUserAgent.value.os.name === 'iOS') {
    return 'fa-brands fa-apple';
  }

  if (visitorUserAgent.value.os.name === 'Android') {
    return 'fa-brands fa-android';
  }

  return 'fa-solid fa-desktop';
});

const browserIconClass = computed(() => {
  if (!visitorUserAgent.value) return 'fa-regular fa-window-maximize';

  if (visitorUserAgent.value.browser.name === 'Chrome') {
    return 'fa-brands fa-chrome';
  }

  if (
    visitorUserAgent.value.browser.name === 'Safari' ||
    visitorUserAgent.value.browser.name === 'Mobile Safari'
  ) {
    return 'fa-brands fa-safari';
  }

  if (
    visitorUserAgent.value.browser.name === 'Opera' ||
    visitorUserAgent.value.browser.name === 'Opera Mini' ||
    visitorUserAgent.value.browser.name === 'Opera Mobi'
  ) {
    return 'fa-brands fa-opera';
  }

  if (visitorUserAgent.value.browser.name === 'Firefox') {
    return 'fa-brands fa-firefox-browser';
  }

  if (visitorUserAgent.value.browser.name === 'Edge') {
    return 'fa-brands fa-edge';
  }

  if (visitorUserAgent.value.browser.name === 'IE') {
    return 'fa-brands fa-internet-explorer';
  }

  return 'fa-regular fa-window-maximize';
});

const visitedPages = computed(() => {
  if (chats.activeChatVisitor && chats.activeChatVisitor.is_loaded) {
    // We'll copy and reverse the default order, so now we'll have from currently viewing page first
    return chats.activeChatVisitor.last_visit.last_pages.slice().reverse();
  }

  return [];
});

const currentPage = computed(() => {
  if (chats.activeChatVisitor.last_visit.last_pages.length) {
    return chats.activeChatVisitor.last_visit.last_pages[
      chats.activeChatVisitor.last_visit.last_pages.length - 1
    ];
  }

  return null;
});

const currentPageUrl = computed(() => {
  if (currentPage.value) {
    return currentPage.value.url;
  }

  return 'javascript:void(0);';
});

const currentPageTitle = computed(() => {
  if (currentPage.value) {
    if (currentPage.value.title) return currentPage.value.title;

    return removeProtocolFromUrl(currentPageUrl.value);
  }

  return 'Unknown page';
});

const archivedChatsUrl = computed(() => {
  return window.location.origin + '/chats?visitorId=' + chats.activeChatVisitor.id;
});

// Close modal when we manually change current page
watch(() => chats.activeChatId, closeVisitedPagesModal);

// Close modal when we update visitor data
watch(() => chats.activeChatVisitor, closeVisitedPagesModal);

function getVisitorLocalTime(now) {
  return DateTime.now().setZone(chats.activeChatVisitor.timezone);
}

function closeVisitedPagesModal() {
  showVisitedPagesModal = false;
}

function openRTOModal() {
  // Open RTO modal for active chat
  chats.activeChat.show_rto_modal = true;
}
</script>

<template>
  <div
    class="relative mx-3 mt-3 flex h-[154px] flex-none flex-col rounded-md border-2 p-3"
    :class="{
      'border-blue-300 bg-blue-50': chats.activeChat && chats.activeChatVisitorIsLoaded,
      'justify-center border-gray-200 bg-white':
        !chats.activeChat || !chats.activeChatVisitorIsLoaded,
    }"
  >
    <div v-if="chats.activeChat && chats.activeChatVisitorIsLoaded" class="flex">
      <div class="flex flex-1 flex-col">
        <div
          class="-mx-3 mb-3 grid select-none grid-cols-3 gap-x-3 border-b-2 border-blue-300 px-3 pb-3 text-center"
        >
          <div>
            <BaseLink
              :to="archivedChatsUrl"
              :use-default-padding="false"
              variant="black"
              class="flex h-full flex-col justify-center border-2 border-transparent font-semibold leading-snug hover:border-blue-300"
              v-tooltip="'Open archived chats with this visitor'"
            >
              <div class="truncate">Chats</div>
              <div class="truncate">{{ chats.activeChatVisitor.statistics.threads_count }}</div>
            </BaseLink>
          </div>
          <div>
            <BaseLink
              :to="archivedChatsUrl"
              :use-default-padding="false"
              variant="black"
              class="flex h-full flex-col justify-center border-2 border-transparent font-semibold hover:border-blue-300"
              v-tooltip="'Open archived chats with this visitor'"
            >
              <div class="truncate">Visits</div>
              <div class="truncate">{{ chats.activeChatVisitor.statistics.visits_count }}</div>
            </BaseLink>
          </div>
          <div>
            <BaseLink
              to="javascript:void(0);"
              :use-default-padding="false"
              variant="black"
              class="flex h-full flex-col justify-center border-2 border-transparent font-semibold hover:border-blue-300"
              v-tooltip="rtoButtonTooltip"
              @click="openRTOModal"
            >
              <div v-if="chats.activeChat.rto_sent" class="flex justify-center items-center truncate">
                <i class="fa-regular fa-square-check fa-fw text-[20px] text-emerald-500"></i><span>RTO</span>
              </div>
              <div v-else-if="chats.checkIfAgentHasToSendRTO(chats.activeChat)" class="flex justify-center items-center truncate">
                <i class="fa-regular fa-square fa-fw text-[20px] text-rose-500"></i><span>RTO</span>
              </div>
              <div v-else class="truncate">
                <span>RTO</span>
              </div>
              <div class="truncate">{{ chats.activeChatVisitor.rto_count }}</div>
            </BaseLink>
          </div>
        </div>

        <div class="grid grid-cols-1 content-center items-center gap-x-3">
          <div class="truncate">
            <i
              class="fa-regular fa-calendar fa-fw mr-1.5"
              v-tooltip="'Visitor\'s previous chat date'"
            ></i>
            <span>Last chatted on: </span>
            <span v-if="chats.activeChat.previous_thread_id">
              {{
                chats.activeChat.threads[
                  chats.activeChat.previous_thread_id
                ].created_at.toLocaleString(DateTime.DATETIME_MED)
              }}
            </span>
            <span v-else>never</span>
          </div>

          <div class="truncate" :class="{ 'text-rose-500': visitorIsFromGDPRCountry }">
            <i class="fa-solid fa-location-dot fa-fw mr-1.5" v-tooltip="'Visitor\'s location'"></i>
            <span
              class="fi mr-1.5"
              :class="'fi-' + (visitorCountryCode ? visitorCountryCode.toLowerCase() : 'xx')"
              v-tooltip="visitorCountryName"
            ></span><span>{{ visitorLocationFormatted }}</span>
          </div>
        </div>
      </div>
      <div
        class="desktop:min-w-[350px] desktop:w-[350px] laptop:min-w-[280px] laptop:w-[280px] -my-3 ml-3 flex w-[250px] min-w-[250px] border-l-2 border-blue-300 py-3 pl-3"
      >
        <div class="grid w-full grid-cols-1 content-center items-center">
          <div class="truncate">
            <i
              class="fa-fw mr-1.5"
              :class="osIconClass"
              v-tooltip="'Visitor\'s operating system (OS)'"
            ></i>
            <span>{{ visitorUserAgentOS }}</span>
          </div>
          <div class="truncate">
            <i class="fa-fw mr-1.5" :class="browserIconClass" v-tooltip="'Visitor\'s browser'"></i>
            <span>{{ visitorUserAgentBrowser }}</span>
          </div>
          <div class="truncate">
            <i class="fa-regular fa-clock fa-fw mr-1.5" v-tooltip="'Visitor\'s local time'"></i>
            <span
              v-if="chats.activeChatVisitor.timezone"
              v-text="getVisitorLocalTime(now).toFormat('MMM dd, ttt')"
            ></span>
            <span v-else>Unknown</span>
          </div>

          <div class="-ml-1 flex">
            <BaseLink
              :to="currentPageUrl"
              :disabled="currentPageUrl === 'javascript:void(0);'"
              class="ml-px truncate font-medium"
              v-tooltip="'Open the page visitor is currently viewing'"
            >
              <i class="fa-regular fa-eye fa-fw mr-1.5"></i>
              <span>Viewing: </span>
              <span>{{ currentPageTitle }}</span>
            </BaseLink>
          </div>

          <div class="-ml-1 flex">
            <BaseLink
              to="javascript:void(0);"
              :disabled="!visitedPages.length"
              class="ml-px truncate font-medium"
              v-tooltip="'View a list of pages visitor has visited'"
              @click="visitedPages.length ? (showVisitedPagesModal = true) : null"
            >
              <i class="fa-solid fa-clock-rotate-left fa-fw mr-1.5"></i>
              <span v-if="visitedPages.length"
                >Visited: {{ visitedPages.length }}
                {{ visitedPages.length === 1 ? 'page' : 'pages' }} in
                {{
                  pageVisitDurationFormatted(
                    visitedPages[visitedPages.length - 1].opened_at,
                    chats.getChatDeactivatedAt(chats.activeChat),
                    now
                  )
                }}
              </span>
              <span v-else>Visited: Unknown page</span>
            </BaseLink>
          </div>
        </div>
      </div>

      <VisitedPagesModal
        :chat="chats.activeChat"
        :visited-pages="visitedPages"
        :show="showVisitedPagesModal"
        @close="closeVisitedPagesModal"
      />
    </div>
    <div v-else-if="chats.activeChat && chats.activeChatVisitorIsLoaded === null">
      <BaseTextMessage>Loading visitor information...</BaseTextMessage>
    </div>
    <div
      v-else-if="chats.activeChat && chats.activeChatVisitorIsLoaded === false"
      class="flex flex-col items-center justify-center"
    >
      <BaseTextMessage variant="danger">Failed to load visitor information</BaseTextMessage>

      <BaseButton class="mt-3" @click="chats.loadVisitor(chats.activeChat)">Reload</BaseButton>
    </div>
    <div v-else>
      <BaseTextMessage>Open a chat to view visitor information</BaseTextMessage>
    </div>
  </div>
</template>

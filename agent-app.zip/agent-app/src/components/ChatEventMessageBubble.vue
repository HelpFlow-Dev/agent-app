<script setup>
import BaseTypingIndicator from '@/components/BaseTypingIndicator';
import ChatEventMessageMeta from '@/components/ChatEventMessageMeta';

defineProps({
  chat: {
    type: Object,
    required: true,
  },
  event: {
    type: Object,
    required: true,
  },
});
</script>

<template>
  <div
    class="rounded-lg border px-2 py-1.5"
    :class="{
      'border-blue-600 bg-blue-500 text-white': event.author_is_agent && event.visibility === 'all',
      'border-gray-600 bg-gray-500 text-white':
        event.author_is_agent && event.visibility === 'agents',
      'border-slate-200 bg-slate-50': event.author_is_visitor,
    }"
  >
    <div
      class="message-bubble-text break-word flow-root whitespace-pre-line leading-6"
      :class="{ 'text-gray-400': event.type === 'sneak_peek' }"
    >
      <BaseTypingIndicator
        v-if="event.type === 'sneak_peek'"
        class="top-[3px]"
        :class="{ 'mr-1': event.text }"
      />

      <slot>
        <div class="inline" v-html="event.text"></div>
      </slot>

      <ChatEventMessageMeta
        v-if="!['sneak_peek', 'file'].includes(event.type)"
        :chat="chat"
        :event="event"
        :is-in-message-bubble="true"
      />
    </div>
  </div>
</template>

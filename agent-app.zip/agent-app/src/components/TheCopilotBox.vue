<script setup>
import { computed, inject, nextTick, onMounted, onUnmounted, watch } from 'vue';
import { useChatsStore } from '@/stores/chats';
import { useCopilot } from '@/stores/copilot';
import BaseButton from '@/components/BaseButton.vue';
import BaseIconButton from '@/components/BaseIconButton.vue';
import BaseInput from '@/components/BaseInput.vue';
import BaseInputLabel from '@/components/BaseInputLabel.vue';
import BaseTextarea from '@/components/BaseTextarea.vue';
import Moveable from 'vue3-moveable';

const appEnvironment = inject('appEnvironment');
const chats = useChatsStore();
const copilot = useCopilot();

let appWrapper = $ref(document.getElementById('app'));
let copilotBox = $ref(null);
let windowWidth = $ref(true);
let windowHeight = $ref(true);
let isDragging = $ref(false);

onMounted(() => {
  if (appEnvironment !== 'production') console.debug('[onMounted:TheCopilotBox]');

  window.addEventListener('resize', handleWindowResize);

  handleWindowResize();
});

onUnmounted(() => {
  if (appEnvironment !== 'production') console.debug('[onUnmounted:TheCopilotBox]');

  window.removeEventListener('resize', handleWindowResize);
});

watch(() => copilotBox, handleCopilotVisibilityChange);

const copilotBoxClassObject = computed(() => ({
  'dragging cursor-grabbing': isDragging,
  'cursor-grab': !isDragging,
}));

const snappableRightBoundary = computed(() => {
  return windowWidth - 12;
});

const snappableBottomBoundary = computed(() => {
  return windowHeight - 12;
});

function handleCopilotVisibilityChange() {
  // When we show the Copilot box we need to move it to its previous position
  if (copilotBox && copilot.positionTransform) copilotBox.style.transform = copilot.positionTransform;
}

function handleWindowResize() {
  // The min width of the app is 1200px
  windowWidth = window.innerWidth > 1200 ? window.innerWidth : 1200;
  windowHeight = window.innerHeight;
}

function handleInputEscKey(event) {
  event.target.blur();
}

function handleCopilotAnswerInputEvent(event) {
  chats.sendTypingIndicator(chats.activeChatId);
}

function onDragStart() {
  //
}

function onDrag({ transform, top, right }) {
  isDragging = true;

  // Update Copilot box transform property directly,
  // otherwise bounds will not be detected correctly
  copilotBox.style.transform = transform;
}

function onDragEnd({ lastEvent }) {
  isDragging = false;

  // Save Copilot position
  if (lastEvent && lastEvent.transform) copilot.positionTransform = lastEvent.transform;
}
</script>

<template>
  <div
    v-if="copilot.show"
    ref="copilotBox"
    class="copilot-box desktop:w-[650px] absolute z-10 flex w-[502px] flex-col rounded-md border-2 border-gray-200 bg-white shadow-[3px_3px_10px_-6px_rgba(0,0,0,0.2)] backdrop-blur-sm opacity-[.98]"
    :class="copilotBoxClassObject"
    :style="{ top: copilot.positionTop + 'px', right: copilot.positionRight + 'px' }"
  >
    <div class="flex items-center border-b-2 border-gray-200 p-3 font-bold leading-10">
      <div class="mr-3 truncate pointer-events-none">HelpFlow Copilot</div>
      <BaseIconButton
        class="fa-solid fa-times ml-auto shrink-0"
        size="sm"
        @click="copilot.close()"
      />
    </div>
    <div class="flex border-b-2 border-gray-200 p-3">
      <BaseButton
        variant="gray-outline"
        icon-before="fa-solid fa-caret-left"
        :disabled="!copilot.canViewPreviousRequest"
        @click="copilot.goToRequestIndex(copilot.currentThread.visibleRequestIndex - 1)"
      >
        View previous request
      </BaseButton>
      <BaseButton
        variant="gray-outline"
        class="ml-auto"
        icon-after="fa-solid fa-caret-right"
        :disabled="!copilot.canViewNextRequest"
        @click="copilot.goToRequestIndex(copilot.currentThread.visibleRequestIndex + 1)"
      >
        View next request
      </BaseButton>
    </div>

    <div v-if="copilot.visibleRequest" class="overflow-y-auto p-3">
      <div class="mb-3">
        <BaseInputLabel class="pointer-events-none">Question</BaseInputLabel>
        <div class="relative flex">
          <BaseInput
            v-model.trim="copilot.visibleRequest.question"
            :disabled="copilot.visibleRequest.id !== null || copilot.isLoading"
            @keydown.esc.stop="handleInputEscKey"
          />
        </div>
      </div>
      <div>
        <div class="flex flex-row items-center">
          <BaseInputLabel class="pointer-events-none">AI-generated answer</BaseInputLabel>
          <div v-if="copilot.visibleRequest.response_time" class="ml-auto text-gray-500">
            Response time: {{ (copilot.visibleRequest.response_time / 1000).toFixed(2) }} seconds
          </div>
        </div>
        <BaseTextarea
          id="copilot-answer-input"
          :placeholder="
            copilot.isLoading
              ? 'The answer will appear here shortly...'
              : copilot.visibleRequestIsTheLastOne
              ? 'Genereate an answer and it will appear here'
              : ''
          "
          v-model.trim="copilot.visibleRequest.answer"
          rows="5"
          :readonly="!copilot.visibleRequestIsTheLastOne"
          :disabled="copilot.isLoading || copilot.visibleRequest.id === null"
          :resizeable="false"
          @input="handleCopilotAnswerInputEvent"
          @keydown.esc.stop="handleInputEscKey"
          @keydown.enter.exact.prevent="copilot.sendAnswer()"
        />
        <div v-if="copilot.visibleRequest.reply_source_text" class="text-sm text-gray-500">
          {{ copilot.visibleRequest.reply_source_text }}
        </div>
      </div>
    </div>

    <div v-if="copilot.visibleRequestIsTheLastOne" class="relative flex border-t-2 border-gray-200 p-3">
      <BaseButton
        v-if="copilot.visibleRequest.id === null"
        :show-loader="copilot.isLoading"
        :disabled="copilot.isLoading"
        @click="copilot.generateAnswer()"
      >
        {{ copilot.isLoading ? 'Generating answer...' : 'Generate answer' }}
      </BaseButton>
      <BaseButton
        v-if="copilot.visibleRequest.id !== null"
        :show-loader="copilot.isLoading"
        :disabled="copilot.isLoading"
        @click="copilot.regenerateAnswer()"
      >
        {{ copilot.isLoading ? 'Generating answer...' : 'Regenerate answer' }}
      </BaseButton>
      <BaseButton
        v-if="copilot.visibleRequest.id !== null && !copilot.isLoading"
        variant="gray-outline"
        class="ml-3"
        @click="copilot.generateFreshRequest()"
      >
        <span>Edit</span> <span class="hidden desktop:inline">question</span>
      </BaseButton>

      <BaseIconButton
        v-if="copilot.visibleRequest.id !== null && !copilot.isLoading"
        class="fa-thumbs-up ml-3"
        :class="{
          'fa-regular': copilot.visibleRequestUnrated || copilot.visibleRequestRatedBad,
          'fa-solid': copilot.visibleRequestRatedGood,
        }"
        v-tooltip="copilot.visibleRequestRatedGood ? 'Copilot answer rated as good' : 'Rate Copilot answer as good'"
        :active="copilot.visibleRequestRatedGood"
        variant="success"
        @click="copilot.setRating(1)"
      ></BaseIconButton>

      <BaseIconButton
        v-if="copilot.visibleRequest.id !== null && !copilot.isLoading"
        class="relative fa-thumbs-down ml-3"
        :class="{
          'fa-regular': copilot.visibleRequestUnrated || copilot.visibleRequestRatedGood,
          'fa-solid': copilot.visibleRequestRatedBad,
        }"
        v-tooltip="copilot.visibleRequestRatedBad ? 'Copilot answer rated as bad' : 'Rate Copilot answer as bad'"
        :active="copilot.visibleRequestRatedBad"
        variant="danger"
        @click="copilot.setRating(0)"
      ></BaseIconButton>

      <BaseButton
        v-if="copilot.visibleRequest.id !== null && !copilot.isLoading"
        variant="primary-outline"
        class="ml-auto"
        icon-after="fa-regular fa-circle-right"
        :disabled="!copilot.visibleRequest.answer"
        @click="copilot.sendAnswer()"
      >
        Send
      </BaseButton>
    </div>
    <div v-else class="relative flex border-t-2 border-gray-200 p-3">
      <BaseIconButton
        v-if="copilot.visibleRequest.id !== null && !copilot.isLoading"
        class="fa-thumbs-up"
        :class="{
          'fa-regular': copilot.visibleRequestUnrated || copilot.visibleRequestRatedBad,
          'fa-solid': copilot.visibleRequestRatedGood,
        }"
        v-tooltip="copilot.visibleRequestRatedGood ? 'Copilot answer rated as good' : 'Rate Copilot answer as good'"
        :active="copilot.visibleRequestRatedGood"
        variant="success"
        @click="copilot.setRating(1)"
      ></BaseIconButton>

      <BaseIconButton
        v-if="copilot.visibleRequest.id !== null && !copilot.isLoading"
        class="relative fa-thumbs-down ml-3"
        :class="{
          'fa-regular': copilot.visibleRequestUnrated || copilot.visibleRequestRatedGood,
          'fa-solid': copilot.visibleRequestRatedBad,
        }"
        v-tooltip="copilot.visibleRequestRatedBad ? 'Copilot answer rated as bad' : 'Rate Copilot answer as bad'"
        :active="copilot.visibleRequestRatedBad"
        variant="danger"
        @click="copilot.setRating(0)"
      ></BaseIconButton>

      <BaseButton
        variant="primary-outline"
        class="ml-auto"
        icon-after="fa-regular fa-circle-right"
        :disabled="!copilot.visibleRequest.answer"
        @click="copilot.sendAnswer(true)"
      >
        Send
      </BaseButton>
    </div>
  </div>

  <Moveable
    v-if="copilot.show"
    className="moveable"
    :target="['.copilot-box']"
    :draggable="true"
    :snappable="true"
    :checkInput="true"
    :hideDefaultLines="true"
    :preventClickDefault="false"
    :snapContainer="appWrapper"
    :bounds="{ left: 12, right: snappableRightBoundary, top: 75, bottom: snappableBottomBoundary }"
    :origin="false"
    @dragStart="onDragStart"
    @drag="onDrag"
    @dragEnd="onDragEnd"
  />
</template>

<script setup>
import { useClientsStore } from '@/stores/clients';
import PromotionItem from '@/components/PromotionItem.vue';

const clients = useClientsStore();

defineProps({
  promotions: {
    type: Array,
    required: true,
  },
});
</script>

<template>
  <div class="flex flex-col">
    <PromotionItem
      v-for="(promotion, index) in promotions"
      :is-last-item="index == promotions.length - 1"
      :key="promotion.id"
      :promotion="promotion"
      @open="clients.expandPromotion(promotion)"
      @close="clients.collapsePromotion(promotion)"
    ></PromotionItem>
  </div>
</template>

<script setup>
import { computed, inject } from 'vue';
import { DateTime } from 'luxon';
import { useClientsStore } from '@/stores/clients';
import BaseButton from '@/components/BaseButton.vue';
import BaseLink from '@/components/BaseLink.vue';

const now = inject('now');
const clients = useClientsStore();

const props = defineProps({
  promotion: {
    type: Object,
    required: true,
  },
  isLastItem: {
    type: Boolean,
    required: true,
  },
});

defineEmits(['open', 'close']);

const promotionUrlIsValidUrl = computed(() => {
  return props.promotion.url && props.promotion.url.startsWith('http');
});

const promotionDocumentUrlIsValidUrl = computed(() => {
  return props.promotion.document_url && props.promotion.document_url.startsWith('http');
});
</script>

<template>
  <div
    class="flex items-center rounded-md border-2 border-gray-200 p-3"
    :class="{
      'mb-3': !promotion.is_expanded && !isLastItem,
      'rounded-b-none border-b-0': promotion.is_expanded,
    }"
  >
    <div class="flex pr-3 font-medium">{{ promotion.title }}</div>
    <div class="ml-auto flex w-32 shrink-0 whitespace-nowrap">
      <BaseButton v-if="!promotion.is_expanded" class="w-full" @click="$emit('open')">
        Show details
      </BaseButton>
      <BaseButton v-if="promotion.is_expanded" class="w-full" @click="$emit('close')">
        Hide details
      </BaseButton>
    </div>
  </div>
  <div
    v-if="promotion.is_expanded"
    class="flex-col rounded-md rounded-t-none border-2 border-gray-200 p-3 text-sm"
    :class="{ 'mb-3': !isLastItem }"
  >
    <div class="font-semibold">Promo period:</div>
    <div class="mb-3">
      {{ promotion.starts_at.toLocaleString(DateTime.DATE_MED) }}
      —
      {{ promotion.ends_at.toLocaleString(DateTime.DATE_MED) }}
      ({{ promotion.ends_at < now ? 'ended' : 'ends' }}
      {{ clients.promotionEndsAtDiffFormatted(promotion, now) }})
    </div>

    <div class="font-semibold">Is there a possibility of promo extension?</div>
    <div class="mb-3">{{ promotion.allow_extension || 'Unknown' }}</div>

    <div class="font-semibold">Promo/Sale Page URL:</div>
    <div v-if="promotionUrlIsValidUrl" class="-ml-1 mb-3 flex">
      <BaseLink :to="promotion.url" class="truncate">{{ promotion.url }}</BaseLink>
    </div>
    <div v-else class="mb-3">{{ promotion.url || 'N/A' }}</div>

    <div class="font-semibold">Details:</div>
    <div class="mb-3">{{ promotion.description }}</div>

    <div class="font-semibold">Link to the document that contains details for the promo:</div>
    <div v-if="promotionDocumentUrlIsValidUrl" class="-ml-1 mb-3 flex">
      <BaseLink :to="promotion.url" class="truncate">{{ promotion.document_url }}</BaseLink>
    </div>
    <div v-else class="mb-3">{{ promotion.document_url || 'N/A' }}</div>

    <div class="font-semibold">
      Are we allowed to disclose details of the promo if visitors ask specifically? Or do we only
      inform them of the details on the day itself?
    </div>
    <div>{{ promotion.allow_disclosure || 'Unknown' }}</div>
  </div>
</template>

<script setup>
import { useRoute, useRouter } from 'vue-router';

const route = useRoute();
const router = useRouter();

defineProps({
  disabled: {
    type: Boolean,
    default: false,
  },
});

function handleClick() {
  if (route.name === 'supervise') {
    // Go back home
    router.push({ name: 'home' });
  } else {
    // Open supervise chat page
    router.push({ name: 'supervise' });
  }
}
</script>

<template>
  <div
    class="flex cursor-pointer items-center justify-center rounded-md transition h-10 ml-3 px-2.5 border-2 select-none border-gray-200 bg-white hover:border-blue-500 hover:bg-blue-100 hover:text-blue-500 active:border-blue-500 active:bg-blue-100 active:text-blue-500"
    :class="{
      'pointer-events-none opacity-50': disabled,
    }"
    v-tooltip="route.name === 'supervise' ? 'Go back to home page' : 'Start supervising chats'"
    @click="handleClick"
  >
    <i
      class="text-lg"
      :class="{
        'fa-solid fa-caret-left': route.name === 'supervise',
        'fa-regular fa-eye': route.name !== 'supervise',
      }"
    ></i>
    <span
      class="pl-2"
      v-text="route.name === 'supervise' ? 'Go back' : 'Supervise'"
    ></span>
  </div>
</template>

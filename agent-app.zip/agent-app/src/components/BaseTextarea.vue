<script>
export default {
  inheritAttrs: false,
};
</script>

<script setup>
defineProps({
  modelValue: {
    type: [String, Number],
    default: '',
  },
  placeholder: {
    type: String,
    default: '',
  },
  hasError: {
    type: Boolean,
    default: false,
  },
  resizeable: {
    type: Boolean,
    default: true,
  },
  disabled: {
    type: Boolean,
    default: false,
  },
  minRows: {
    type: Number,
    default: 1,
  },
});

const emit = defineEmits(['update:modelValue']);

function onInput(event) {
  emit('update:modelValue', event.target.value);
}
</script>

<template>
  <textarea
    class="w-full select-none rounded-md border-2 bg-white p-3 outline-none transition placeholder:text-gray-400 disabled:pointer-events-none disabled:bg-gray-100 disabled:opacity-60"
    :class="{
      'border-gray-200 focus:border-blue-500 active:border-blue-500': !hasError,
      'border-rose-500': hasError,
      'resize-none': !resizeable,
      'min-h-[52px]': minRows === 1,
      'min-h-[76px]': minRows === 2,
      'min-h-[100px]': minRows === 3,
      'min-h-[124px]': minRows === 4,
      'min-h-[148px]': minRows >= 5,
    }"
    v-bind="$attrs"
    :placeholder="placeholder"
    :disabled="disabled"
    :value="modelValue"
    @input="onInput"
  ></textarea>
</template>

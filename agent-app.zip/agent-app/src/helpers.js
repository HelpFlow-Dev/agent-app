import { DateTime } from 'luxon';

// Client ID for staging & production is determined by LiveChat
export const livechatClientId = 'bb9e5b2f1ab480e4a715977b7b1b4279';

// Detect current environment: "local", "staging" or "production"
export function detectAppEnvironment() {
  // Get current host
  let host = window.location.host;
  let hostSubdomain = host.split('.')[0];

  return host.endsWith('.test') ? 'local' : (hostSubdomain === 'staging' ? 'staging' : 'production');
}

export function openInNewTab(url) {
  window.open(url, '_blank');
}

export function preloadImage(url) {
  let img = new Image();
  img.src = url;
}

// For example: "08d 04h 54m 41s"
export function formatLuxonDuration(duration, now) {
  // We always want to display seconds
  let format = "ss's'";

  if (duration.as('minutes') >= 1.0) format = "mm'm' " + format;
  if (duration.as('hours') >= 1.0) format = "hh'h' " + format;
  if (duration.as('days') >= 1.0) format = "dd'd' " + format;

  return duration.toFormat(format);
}

// For example: "04:54:41" or "54:41" (if short format is used)
export function formatLuxonChatTimerDuration(duration, useShortFormat) {
  // In some cases we may want to use short timer format (e.g. chat hold timer)
  if (useShortFormat) return duration.toFormat('mm:ss');

  // We always want to display hours, minutes and seconds in the long format
  return duration.toFormat('hh:mm:ss');
}

export function pageVisitDurationFormatted(openedAt, closedAt, now) {
  if (closedAt) {
    return formatLuxonDuration(closedAt.diff(openedAt));
  }

  return formatLuxonDuration(DateTime.now().diff(openedAt));
}

export function convertCommaSeparatedStringToArray(string) {
  // Convert comma-separated string to array and remove empty strings from array
  return string.split(',').filter(Boolean);
}

// For example: http://youtube.com OR https://youtube.com -> youtube.com
export function removeProtocolFromUrl(url) {
  return url.replace(/^https?:\/\//, '');
}

// Opens URL in a new tab
export function openUrlInNewTab(url) {
  window.open(url, '_blank').focus();
}

// Returns aspect ratio from given dimensions
export function getAspectRatio(width, height) {
  return width / height;
}

// Waits for some condition to become true in order to execute callback function
export function waitFor(condition, callback) {
    if (!condition()) {
      // Checks the flag every 250ms
      window.setTimeout(waitFor.bind(null, condition, callback), 250);
    } else {
      callback();
    }
}

// Generate a string of random alphanumeric characters
export function randomString(length) {
  let chars = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
  let result = '';

  for (var i = length; i > 0; --i) result += chars[Math.floor(Math.random() * chars.length)];

  return result;
}

// Returns icon class for given file type
export function getFontAwesomeIconClassForFileMimeType(mimeType) {
  // Images
  if (
    [
      'image/jpeg',
      'image/png',
      'image/svg+xml',
      'image/webp',
      'image/heif',
      'image/heic',
    ].includes(mimeType)
  ) {
    return 'fa-regular fa-file-image';
  }

  // PDF files
  if (['application/pdf'].includes(mimeType)) {
    return 'fa-regular fa-file-pdf';
  }

  // CSV files
  if (['text/csv'].includes(mimeType)) {
    return 'fa-solid fa-file-csv';
  }

  // Microsoft Excel files
  if (
    [
      'application/excel',
      'application/x-excel',
      'application/x-msexcel',
      'application/vnd.ms-excel',
      'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
    ].includes(mimeType)
  ) {
    return 'fa-regular fa-file-excel';
  }

  // Microsoft PowerPoint files
  if (
    [
      'application/mspowerpoint',
      'application/powerpoint',
      'application/vnd.ms-powerpoint',
      'application/x-mspowerpoint',
      'application/vnd.openxmlformats-officedocument.presentationml.presentation',
    ].includes(mimeType)
  ) {
    return 'fa-regular fa-file-powerpoint';
  }

  // Microsoft Word files
  if (
    [
      'application/doc',
      'application/ms-doc',
      'application/msword',
      'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
    ].includes(mimeType)
  ) {
    return 'fa-regular fa-file-word';
  }

  // Plain text files
  if (['text/plain'].includes(mimeType)) {
    return 'fa-regular fa-file-lines';
  }

  // Audio files
  if (['audio/mpeg', 'audio/ogg', 'audio/wav'].includes(mimeType)) {
    return 'fa-regular fa-file-audio';
  }

  // Video files
  if (
    [
      'application/mp4',
      'application/x-troff-msvideo',
      'image/mov',
      'video/avi',
      'video/mp4',
      'video/msvideo',
      'video/quicktime',
      'video/webm',
      'video/x-quicktime',
      'video/x-msvideo',
      'video/x-ms-wmv',
      'video/x-ms-asf',
    ].includes(mimeType)
  ) {
    return 'fa-regular fa-file-video';
  }

  // Archives
  if (['application/zip', 'application/x-gzip'].includes(mimeType)) {
    return 'fa-regular fa-file-zipper';
  }

  // Code files
  if (['application/json', 'text/html', 'text/php'].includes(mimeType)) {
    return 'fa-regular fa-file-code';
  }

  // Unknown file type
  return 'fa-regular fa-file';
}

export function downloadBlob(blob, filename) {
    if (
      window.navigator &&
      window.navigator.msSaveOrOpenBlob
    ) return window.navigator.msSaveOrOpenBlob(blob);

    // For other browsers:
    // Create a link pointing to the ObjectURL containing the blob.
    const data = window.URL.createObjectURL(blob);

    const link = document.createElement('a');
    link.href = data;
    link.download = filename;

    // this is necessary as link.click() does not work on the latest firefox
    link.dispatchEvent(
      new MouseEvent('click', {
        bubbles: true,
        cancelable: true,
        view: window
      })
    );

    setTimeout(() => {
      // For Firefox it is necessary to delay revoking the ObjectURL
      window.URL.revokeObjectURL(data);
      link.remove();
    }, 100);
}

var lastTime = (new Date()).getTime();
var checkInterval = 1000; // Every second

setInterval(function () {
  var currentTime = (new Date()).getTime();

  // If device was sleeping for more than 10 seconds and just woke up we'll send a wakeup message
  if (currentTime > (lastTime + checkInterval + 10000)) {
    postMessage('wakeup');
  }

  lastTime = currentTime;
}, checkInterval);

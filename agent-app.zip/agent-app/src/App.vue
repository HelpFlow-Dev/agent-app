<script setup>
import { inject, onMounted, onUnmounted, nextTick, watch } from 'vue';
import { RouterView, useRoute, useRouter } from 'vue-router';
import { useAgentsStore } from '@/stores/agents';
import { useAppStore } from '@/stores/app';
import { useAudioStore } from '@/stores/audio';
import { useNotificationsStore } from '@/stores/notifications';
import { useCannedResponsesStore } from '@/stores/cannedResponses';
import { useChatsStore } from '@/stores/chats';
import { useClientsStore } from '@/stores/clients';
import { useCopilot } from '@/stores/copilot';
import { useTagsStore } from '@/stores/tags';
import { useToast } from '@/stores/toasts';
import { useScreenRecordingsStore } from '@/stores/screenRecordings';
import { useMagicKeys, whenever } from '@vueuse/core';
import BaseButton from '@/components/BaseButton.vue';
import BaseTextMessage from '@/components/BaseTextMessage.vue';
import Bugsnag from '@bugsnag/js';
import ChatTabList from '@/components/ChatTabList.vue';
import IconLoader from '@/components/icons/IconLoader.vue';
import TheClientInfoBox from '@/components/TheClientInfoBox.vue';
import TheClientInfoTabBox from '@/components/TheClientInfoTabBox.vue';
import TheCopilotBox from '@/components/TheCopilotBox.vue';
import TheHeader from '@/components/TheHeader.vue';
import TheVisitorInfoBox from '@/components/TheVisitorInfoBox.vue';
import TheScreenRecorder from '@/components/TheScreenRecorder.vue';
import UpdateCopilotAnswerRatingModal from '@/components/modals/UpdateCopilotAnswerRatingModal.vue';

const appEnvironment = inject('appEnvironment');
const helpflowApiToken = inject('helpflowApiToken');
const livechatApiToken = inject('livechatApiToken');
const livechatApi = inject('livechatApi');
const emitter = inject('emitter');
const delay = inject('delay');
const agents = useAgentsStore();
const app = useAppStore();
const audio = useAudioStore();
const cannedResponses = useCannedResponsesStore();
const chats = useChatsStore();
const copilot = useCopilot();
const clients = useClientsStore();
const keys = useMagicKeys();
const notifications = useNotificationsStore();
const router = useRouter();
const route = useRoute();
const screenRecordings = useScreenRecordingsStore();
const tags = useTagsStore();
const toast = useToast();

const props = defineProps({
  data: {
    type: Object,
    default: null,
  },
});

// Intervals
let checkLivechatApiConnectionInterval = $ref(null);
let checkRecordingInProgressWhenAcceptingChatsInterval = $ref(null);
let handlePendingNotificationsTickInterval = $ref(null);
let killHangingLoadingChatsInterval = $ref(null);
let loadClientsInterval = $ref(null);
let loadCannedResponsesInterval = $ref(null);
let loadTagsInterval = $ref(null);
let reloadVisitorsInterval = $ref(null);
let syncStatusWithLivechatInterval = $ref(null);
let syncMissingChatsAndMessagesInterval = $ref(null);

// Modals
let showScreenRecorderModal = $ref(false);
let showCopilotAnswerRatingModal = $ref(false);

// Workers
let wakeupDetectorWorker = $ref(null);

// Update Copilot Answer rating modal data
let copilotAnswerRatingModalRequestId = $ref(null);
let copilotAnswerRatingModalRating = $ref(null);

watch(() => chats.totalUnreadMessagesCount, chats.updateUnreadChatsOnTabName);
watch(() => app.initialized, handleAppInitialized);

onMounted(() => {
  init();

  emitter.on('show-screen-recorder-modal', () => {
    if (appEnvironment !== 'production') console.debug('[emitter:App] show-screen-recorder-modal');

    // Close any active modal
    emitter.emit('shortcut-close-modal');

    // We need to use nextTick to wait for other modal to close
    nextTick(() => {
      showScreenRecorderModal = true;
    });
  });

  emitter.on('show-update-copilot-answer-rating-modal', (data) => {
    if (appEnvironment !== 'production') console.debug('[emitter:App] show-update-copilot-answer-rating-modal');

    copilotAnswerRatingModalRequestId = data.requestId;
    copilotAnswerRatingModalRating = data.rating;

    // Close any active modal
    emitter.emit('shortcut-close-modal');

    // We need to use nextTick to wait for other modal to close
    nextTick(() => {
      showCopilotAnswerRatingModal = true;
    });
  });
});

onUnmounted(() => {
  emitter.off('show-screen-recorder-modal');
  emitter.off('show-update-copilot-answer-rating-modal');
});

async function init() {
  console.log('Initializing the application...');

  try {
    validateAPITokens();

    initGeneralEventHandlers();

    if (app.livechatEnabled) {
      initLiveChatEventHandlers();

      loadGoogleAnalyticsForTriggeringChatEventsManually();
    }

    await setInitialData();

    await audio.init();

    notifications.init();

    // Set BugSnag user
    Bugsnag.setUser(agents.agent.user_id, agents.agent.livechat_id, agents.agent.display_name);

    if (app.livechatEnabled) {
      await initLiveChat();
    }

    initShortcutKeys();

    // Initialize data refresh intervals
    loadCannedResponsesInterval = setInterval(loadCannedResponses, 1000 * 60 * 15); // Every 15 minutes
    loadClientsInterval = setInterval(loadClients, 1000 * 60); // Every minute
    loadTagsInterval = setInterval(loadTags, 1000 * 60 * 15); // Every 15 minutes

    app.initialized = true;

    console.log('Application has been initialized.');
  } catch (error) {
    app.throwCriticalError('initialization', error);

    destroyApp();

    console.error('Application initialization failed: ', '\n', error);
  }
}

async function setInitialData() {
  console.debug('Initializing Pinia data stores...');

  // Load agents
  agents.statuses = props.data.agentStatuses;
  agents.authAgentId = props.data.authAgentId;
  agents.agents = props.data.agents;
  agents.agents.forEach((item) => {
    // We'll set inital routing status value to "offline" and will sync a bit later
    item.livechat_routing_status = 'offline';
  });

  // Load canned responses
  cannedResponses.cannedResponses = props.data.cannedResponses;

  // Load tags
  tags.tags = props.data.tags;
  tags.prospectTagId = props.data.prospectTagId;

  // Load clients
  clients.mapAndSetClients(props.data.clients);
}

function initGeneralEventHandlers() {
  console.debug('Initializing general event handlers...');

  // We need to use full URL due to some browsers not recognizing the path correctly
  wakeupDetectorWorker = new Worker('/agent-app/workers/DetectWakeup.js');

  // When you close your MacBook and then return later on after machine was sleeping for a while
  // the LiveChat API SDK won't detect that and reconnect automatically
  wakeupDetectorWorker.onmessage = function (e) {
    if (e && e.data === 'wakeup') {
      console.debug('Detected device wakeup, marking the application as out of sync...');

      app.throwCriticalError(
        'sleep',
        "We've detected that you've been away for too long, please reload the application."
      );

      destroyApp();
    }
  };

  window.addEventListener('offline', function () {
    app.online = false;

    toast.internetDisconnected();
  });

  window.addEventListener('online', function () {
    app.online = true;

    toast.internetReconnected();

    chats.syncMissingChatsAndMessages();
  });

  window.onbeforeunload = function (event) {
    if (screenRecordings.recordingInProgress) {
      return 'Screen recording in progress, please stop it before closing the tab.';
    } else if (screenRecordings.queuedRecordingsCount) {
      return 'Screen recording upload in progress, please wait a few seconds before closing the tab.';
    }
  };

  document.addEventListener('visibilitychange', function () {
    if (document.visibilityState === 'visible') {
      emitter.emit('tabFocused');
    }
  });
}

function initLiveChatEventHandlers() {
  console.debug('Initializing LiveChat event handlers...');

  new BroadcastChannel('faq_search_loaded').onmessage = (event) => {
    if (appEnvironment !== 'production') {
      console.debug('[BroadcastChannel:faq_search_loaded]', event.data);
    }

    if (chats.activeChat) {
      chats.broadcastChatSwitchedMessage(chats.activeChat);
    }
  };

  new BroadcastChannel('faq_search_use_reply').onmessage = (event) => {
    if (appEnvironment !== 'production') {
      console.debug('[BroadcastChannel:faq_search_use_reply]', event.data);
    }

    if (chats.activeChatIsLoaded) {
      chats.setMessageDraft(chats.activeChat, event.data);
    }
  };
}

async function loadClients() {
  await clients.load();
}

async function loadTags() {
  await tags.load();
}

async function loadCannedResponses() {
  await cannedResponses.load();
}

async function syncStatusWithLivechat() {
  await agents.syncLiveChatRoutingStatuses();
}

// prettier-ignore
function loadGoogleAnalyticsForTriggeringChatEventsManually() {
  console.debug('Initializing Google Analytics...');

  // Google Analytics V3
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','https://www.google-analytics.com/analytics.js','ga');

  ga('create', 'UA-114360078-2', 'auto');
  ga('set', 'checkProtocolTask', null);
}

async function initLiveChat() {
  console.debug('Initializing LiveChat API...');

  livechatApi.init({ personal_access_token: livechatApiToken });

  console.debug('Logging in to LiveChat...');

  // We need to wait until we log in to LiveChat in order to continue
  while (!livechatApi._isLoggedIn) await delay(50);

  console.debug('Successfully logged in to LiveChat.');

  await agents.loadAuthAgentDataFromLiveChat();

  await agents.syncStatus();

  await chats.loadActiveChats();

  checkLivechatApiConnectionInterval = setInterval(app.checkLivechatApiConnection, 1000); // Every second
  syncStatusWithLivechatInterval = setInterval(syncStatusWithLivechat, 1000 * 20); // Every 20 seconds
  syncMissingChatsAndMessagesInterval = setInterval(chats.syncMissingChatsAndMessages, 1000 * 25); // Every 25 seconds
  reloadVisitorsInterval = setInterval(chats.reloadVisitors, 1000 * 10); // Every 10 seconds
  killHangingLoadingChatsInterval = setInterval(chats.killHangingLoadingChats, 1000 * 1); // Every second
  handlePendingNotificationsTickInterval = setInterval(chats.handlePendingNotificationsTick, 1000 * 1); // Every second
  checkRecordingInProgressWhenAcceptingChatsInterval = setInterval(screenRecordings.checkIfRecordingInProgressWhenAcceptingChats, 1000 * 20); // Every 20 seconds

  // Listen to incoming messages
  livechatApi.on('incoming_event', chats.handleIncomingEvent);

  // Listen to incoming chats
  livechatApi.on('incoming_chat', chats.handleIncomingChat);

  // Listen to incoming customers (when customer reloads the website LC may think this as a new visit)
  livechatApi.on('incoming_customer', chats.handleIncomingCustomer);

  // Listen to updates to LiveChat routing status to keep it in sync with HelpFlow
  livechatApi.on('routing_status_set', agents.handleRoutingStatusChange);

  // Listen to marking LiveChat events as seen by agents and visitors
  livechatApi.on('events_marked_as_seen', chats.handleEventsMarkedAsSeen);

  // Listen to chat thread tag added
  livechatApi.on('thread_tagged', tags.handleThreadTagged);

  // Listen to chat thread tag removed
  livechatApi.on('thread_untagged', tags.handleThreadUntagged);

  // Listen to chat transfers
  livechatApi.on('chat_transferred', chats.handleChatTransferred);

  // Listen to chat deactivation (when chat is archived after 15 minutes of inactivity)
  livechatApi.on('chat_deactivated', chats.handleChatDeactivated);

  // Listen to customer changed page event
  livechatApi.on('customer_page_updated', chats.handleVisitorPageChange);

  // Listen to customer banned event
  livechatApi.on('customer_banned', chats.handleVisitorBanned);

  // Listen for visitor message they are currently typing
  livechatApi.on('incoming_sneak_peek', chats.handleIncomingSneakPeek);

  // Listen for chat property updates
  livechatApi.on('chat_properties_updated', chats.handleChatPropertiesUpdated);

  // Listen for event property updates
  livechatApi.on('event_properties_updated', chats.handleEventPropertiesUpdated);

  // TODO-HAS: if the current agent is suspended, then we need to reload the page and show the error
  // https://developers.livechat.com/docs/messaging/agent-chat-api/rtm-pushes#agent_suspended
  // https://developers.livechat.com/docs/messaging/agent-chat-api/rtm-pushes#agent_deleted
}

function validateAPITokens() {
  console.debug('Validating API tokens...');

  // Check HelpFlow API token
  if (!helpflowApiToken) {
    throw 'HF API token is missing, please contact developers to get one.';
  }

  if (appEnvironment !== 'production') console.debug('HelpFlow API token: ', helpflowApiToken);

  if (livechatApiToken) app.livechatEnabled = true;

  // Check LiveChat API token
  if (appEnvironment !== 'production') {
    if (livechatApiToken) {
      console.debug('LiveChat API token: ', livechatApiToken);
    } else {
      console.debug('LiveChat API token is not set, LiveChat integration will be disabled.');
    }
  }
}

function handleAppInitialized() {
  // Auto-open screen recorder modal
  if (app.initialized && appEnvironment === 'production') {
    emitter.emit('show-screen-recorder-modal');
  }
}

// Remove all intervals, LC API connection, useful when critical error occurs
function destroyApp() {
  console.debug('Destroying the application...');

  // Go back home
  router.push({ name: 'home' });

  if (app.livechatEnabled) {
    // We'll destroy the LC connection to prevent it from getting reestablished behind the scenes
    // because at this point we know that the app is out of sync and needs to be reloaded anyway
    livechatApi.destroy();
  }

  // Close all UI elements
  emitter.emit('shortcut-close-dropdown-menu');
  emitter.emit('shortcut-close-tag-picker');
  emitter.emit('shortcut-close-emoji-picker');
  emitter.emit('shortcut-close-modal');

  // Stop screen recording
  emitter.emit('screen-recording-stopped', { screenId: 1 });
  emitter.emit('screen-recording-stopped', { screenId: 2 });
  emitter.emit('screen-recording-stopped', { screenId: 3 });

  // Clear LiveChat-related intervals
  if (app.livechatEnabled) {
    clearInterval(checkLivechatApiConnectionInterval);
    clearInterval(checkRecordingInProgressWhenAcceptingChatsInterval);
    clearInterval(reloadVisitorsInterval);
    clearInterval(handlePendingNotificationsTickInterval);
    clearInterval(killHangingLoadingChatsInterval);
    clearInterval(syncMissingChatsAndMessagesInterval);
    clearInterval(syncStatusWithLivechatInterval);
  }

  // Clear other intervals
  clearInterval(loadClientsInterval);
  clearInterval(loadCannedResponsesInterval);
  clearInterval(loadTagsInterval);

  // Clear chats data
  chats.chats = [];

  // Terminate all Workers
  if (wakeupDetectorWorker) wakeupDetectorWorker.terminate();

  console.debug('Application has been destroyed.');
}

function initShortcutKeys() {
  console.debug('Initializing keyboard shortcuts...');

  // Shortcuts specific to chatting
  if (app.livechatEnabled) {
    whenever(keys.alt_up, () => {
      if (chats.activeChat) emitter.emit('shortcut-jump-prev-chat');
    });

    whenever(keys.alt_down, () => {
      if (chats.activeChat) emitter.emit('shortcut-jump-next-chat');
    });

    whenever(keys.control_alt_backspace, () => {
      if (chats.activeChatIsLoaded) chats.showCloseChatModal(chats.activeChat);
    });

    whenever(keys.control_shift_z, () => {
      if (chats.activeChatIsLoaded) {
        if (!chats.activeChat.show_rto_modal) {
          // Close any active modal
          emitter.emit('shortcut-close-modal');

          // Open RTO modal for active chat
          chats.activeChat.show_rto_modal = true;
        } else {
          // Close RTO modal
          emitter.emit('shortcut-close-modal');
        }
      }
    });

    whenever(keys.control_alt_m, () => {
      if (chats.activeChatIsLoaded) emitter.emit('shortcut-toggle-tag-picker');
    });

    // Special handling for macOS
    whenever(keys.control_alt_µ, () => {
      if (chats.activeChatIsLoaded) emitter.emit('shortcut-toggle-tag-picker');
    });
  }

  whenever(keys.control_shift_slash, () => {
    if (!app.chatInputFocused) emitter.emit('shortcut-show-shortcuts-modal');
  });

  whenever(keys.escape, () => {
    if (app.dropdownMenuOpen) {
      emitter.emit('shortcut-close-dropdown-menu');
    } else if (app.tagPickerOpen) {
      emitter.emit('shortcut-close-tag-picker');
    } else if (app.emojiPickerOpen) {
      emitter.emit('shortcut-close-emoji-picker');
    } else if (app.modalOpen) {
      emitter.emit('shortcut-close-modal');
    } else if (copilot.show) {
      copilot.close();
    } else if (route.name === 'chat' && !app.chatInputFocused) {
      router.push({ name: 'home' });
    } else if (route.name === 'supervise') {
      router.push({ name: 'home' });
    }
  });
}
</script>

<template>
  <div
    v-if="app.error && app.error.type === 'sleep'"
    class="flex h-screen max-h-screen min-h-screen w-full flex-col"
  >
    <BaseTextMessage class="flex-col">
      <div class="text-4xl">
        <i class="fa-regular fa-clock"></i>
      </div>
      <div class="mt-3 font-bold">You've been away for a while</div>
      <div class="my-3">{{ app.error.message }}</div>
      <BaseButton @click="app.reload">Reload application</BaseButton>
    </BaseTextMessage>
  </div>
  <div
    v-if="app.error && app.error.type === 'connection'"
    class="flex h-screen max-h-screen min-h-screen w-full flex-col"
  >
    <BaseTextMessage class="flex-col">
      <div class="text-4xl">
        <i class="fa-solid fa-plug-circle-exclamation"></i>
      </div>
      <div class="mt-3 font-bold">Connection error</div>
      <div class="my-3">{{ app.error.message }}</div>
      <BaseButton @click="app.reload">Reload application</BaseButton>
    </BaseTextMessage>
  </div>
  <div
    v-else-if="app.error && app.error.type === 'initialization'"
    class="flex h-screen max-h-screen min-h-screen w-full flex-col"
  >
    <BaseTextMessage class="flex-col">
      <div class="text-4xl text-rose-500">
        <i class="fa-solid fa-circle-exclamation"></i>
      </div>
      <div class="mt-3 font-bold">Application initialization failed</div>
      <div class="mt-3">You can see the error that caused the crash below.</div>
      <div class="mt-3">
        <pre
          class="rounded-md border-2 border-gray-200 bg-white p-3 text-rose-500"
          v-text="app.error.message"
        />
      </div>
      <div class="my-3">Check the developer console for more details.</div>
      <BaseButton @click="app.reload">Reload application</BaseButton>
    </BaseTextMessage>
  </div>
  <div
    v-else-if="app.initialized"
    class="relative flex h-screen max-h-screen min-h-screen flex-wrap overflow-y-hidden"
  >
    <TheHeader />

    <TheCopilotBox />

    <!-- Left column -->
    <div class="app-column flex w-7/12 flex-col">
      <div class="flex h-full flex-auto flex-col">
        <TheVisitorInfoBox />

        <ChatTabList />

        <div
          class="mx-3 mb-3 flex flex-1 flex-col rounded-md border-2 border-gray-200 bg-white"
          :class="{
            'overflow-y-auto': route.name === 'supervise',
          }"
        >
          <RouterView :key="route.fullPath" />
        </div>
      </div>
    </div>

    <!-- Right column -->
    <div class="app-column flex w-5/12 flex-col py-3 pr-3">
      <div class="flex flex-auto flex-col overflow-y-auto">
        <TheClientInfoTabBox v-if="app.livechatEnabled" />

        <div
          class="flex flex-1 flex-col overflow-y-auto rounded-md border-2 border-gray-200 bg-white p-3"
        >
          <TheClientInfoBox />
        </div>
      </div>
    </div>
  </div>
  <div v-else class="flex h-screen max-h-screen min-h-screen w-full flex-col">
    <BaseTextMessage class="flex-col">
      <IconLoader size="lg" class="text-blue-500"></IconLoader>

      <div v-if="agents.agent && agents.agent.display_name" class="my-3 font-bold">
        Welcome back, {{ agents.agent.display_name }}!
      </div>
      <div v-else class="my-3 font-bold">Welcome back!</div>
      <div>Loading the application...</div>
    </BaseTextMessage>
  </div>

  <TheScreenRecorder
    :show-modal="showScreenRecorderModal"
    @closeModal="showScreenRecorderModal = false"
  />

  <UpdateCopilotAnswerRatingModal
    size="sm"
    :request-id="copilotAnswerRatingModalRequestId"
    :rating="copilotAnswerRatingModalRating"
    :show="showCopilotAnswerRatingModal"
    @close="showCopilotAnswerRatingModal = false"
  />
</template>

/* eslint-env node */
require("@rushstack/eslint-patch/modern-module-resolution");

module.exports = {
    root: true,
    extends: [
        "plugin:vue/vue3-essential",
        "plugin:tailwindcss/recommended",
        "eslint:recommended",
        "@vue/eslint-config-prettier",
    ],
    parserOptions: {
        ecmaVersion: "latest",
    },
    "rules": {
        "no-undef": "off",
        "no-unused-vars": ["warn", { "args": "none" }],
        "vue/no-v-text-v-html-on-component": "warn",
        "tailwindcss/no-custom-classname": "off",
    },
};

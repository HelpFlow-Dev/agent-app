# Agent Chat app
Welcome to the source code for **Agent Chat application**, a core part of **HelpFlow Agent Suite** (also known as **HAS**).

This app is designed to work with the another part of HAS — **FAQ Search interface** so agents can be as efficient as possible.

This is a single-page application that only appears to be a standalone app, but actually runs on the same backend as HelpFlow.

The app has it\'s own distinct UI specifically designed for best agent performance. This is where agents will spend most of their time.

## WIP notice
This project is still work in progress, so things may change.

If you notice that this README is missing some key information or is outdated, feel free to point it out so we can keep it up to date.

## LC RTM API
We use LiveChat as a backend for sending messages. More specifically, we use [LiveChat RTM API](https://developers.livechat.com/docs/messaging/agent-chat-api/rtm-reference).

### LC RTM API Integration
In order to integrate LiveChat RTM API and have an efficient chat app we use [LiveChat Chat SDK](https://developers.livechat.com/docs/messaging/chat-sdk), more on that later.

### LC RTM pushes
Every time some event happens, like incoming message or chat, LC will send a push for that event.

There are many possible pushes, feel free to view a full list of [RTM pushes](https://developers.livechat.com/docs/messaging/agent-chat-api/rtm-pushes).

Also, you can take a look at the [data structures](https://developers.livechat.com/docs/messaging/chat-sdk#data-structures) to better understand what happens.

Extensive debug information is also be available in developer's console when you run the app.

### Authentication
We use two APIs - LiveChat RTM API and HelpFlow API, so we need two API tokens for authentication.

Once they are set up in DB, they will be loaded automatically.

If agent is missing at least one token they will see an error during app loading.

##### HelpFlow API
We use Bearer API tokens for authentication.

Each agent has an API token that can be found in `users` table as `api_token`.

##### LiveChat API
We use LiveChat Personal Access Token (PAT) tokens for authentication.

Each agent has a PAT that can be found in `agents` table as `livechat_base64_token`.

To create a new PAT please visit [LiveChat Developer Console](https://developers.livechat.com/console/tools/personal-access-tokens).

## Project dependencies

### [Vue.js](https://vuejs.org)
The project is built using the latest Vue version (v3 at the time of writing).

### [Pinia](https://pinia.vuejs.org)
We use Pinia as our app's in-memory storage solution because we need to fetch, process, and display a lot of data in realtime.

Most of our business logic is located in Pinia stores. You can take a look at the largest one where we handle most of chat-related logic [src/stores/chats.js](src/stores/chats.js) or one of the smallest ones like [src/stores/tags.js](src/stores/tags.js) where handle everything tag-related.

### [LiveChat Chat SDK](https://developers.livechat.com/docs/messaging/chat-sdk)
We use Chat SDK for handling most things like establishing websockets connection to LiveChat, listening and receiving pushes from LiveChat and sending API requests to LiveChat.

We've extended Chat SDK in [src/livechat-api.js](src/livechat-api.js) to make it easy for us to send requests to LiveChat.

When we send the request we get a Promise and expect a response, and sometimes one or multiple pushes from LiveChat as well. Pushes will be handled automatically by handler functions defined in [src/App.vue](src/App.vue) and update the data we have stored in Pinia in one way or another.

### [Tailwind CSS](https://tailwindcss.com)
UI is built with Tailwind as it allows us, essentially, to not write any CSS while being very flexible with the UI design.

Most of the component design is completed as you can take a look at the app and Tailwind classes used on elements to get better idea on how it works.

### [Vue-Toastification](https://github.com/Maronato/vue-toastification)
For displaying small toast notifications we use this plugin.

For simplicity, we store all available toast notifications in one place in [src/stores/toasts.js](src/stores/toasts.js)

We've also heavily modified plugin's CSS in [src/css/toast.scss](src/css/toast.scss), so now its design matches with our app perfectly.

## Project structure

### Vue Router
We use [Vue Router](https://router.vuejs.org) for routing, though there are only a few routes:
- Home (empty page with no active chat)
- Active chat (chat tab that is active)
- 404 (redirects to home)

### Vue Components
Each component is in their own separate file.

Each component is built using [Composition API](https://vuejs.org/guide/extras/composition-api-faq.html).

##### Base components
Components that start with **Base** are the ones that can be freely reused, like **BaseLink** component, or even extended, like **BaseModal** component.

##### Single-instance components
Components that start with **The** are the ones that should be included only once in the app.

##### Other components
Remember, all rules from [Vue Style Guide](https://vuejs.org/style-guide) apply for component names:
- [Single-file component filename casing](https://vuejs.org/style-guide/rules-strongly-recommended.html#single-file-component-filename-casing)
- [Base component names](https://vuejs.org/style-guide/rules-strongly-recommended.html#base-component-names)
- [Single-instance component names](https://vuejs.org/style-guide/rules-strongly-recommended.html#single-instance-component-names)
- [Tightly coupled component names](https://vuejs.org/style-guide/rules-strongly-recommended.html#tightly-coupled-component-names)
- [Order of words in component names](https://vuejs.org/style-guide/rules-strongly-recommended.html#order-of-words-in-component-names)

## Development

### Local environment setup
The first thing you need to do is to setup your local dev environment, more on this in our [SETUP](SETUP.md) file.

### Versioning
Releases are be numbered with the following format:

`<major>.<minor>.<patch>`

For more information on semantic versioning, please visit [semver.org](https://semver.org).

Every time before submit a pull request make sure you've:
- Increased the version in the [package.json](package.json) file
- Added a list of changes to the [CHANGELOG](CHANGELOG.md) file
- Compiled the code using `npm run production`
- Compiled the code **after** changes are made to [package.json](package.json) file

### LC RTM API Reference
When developing a new feature you will always need to check [LC RTM API Reference](https://developers.livechat.com/docs/messaging/agent-chat-api/rtm-reference) to see what LiveChat offers in terms of API routes so you can verify feasibility and better estimate what's needed.

### LC RTM API limitations and issues

###### No ability to get active chats with all related data
There's no ability to get chats with all related data in one API call, which requires us to make a few different calls when we do the initial app loading.

###### No unban_customer action
You can ban customer, but you cannot unban them via API for some reason, so for now there's only ability to unban them via LiveChat website.

### LC Chat SDK limitations and issues

###### Bug with Promises
ChatSDK sends Promise requests, but sometimes the response can come later then push notification for certain action, e.g. banning visitor, and if we do try-catch on the API request then we'll catch the response and not an actual error. In places where it matters we have some logic for handling this.

### Coding guidelines

### Vue
We conform to [Vue Style Guide](https://vuejs.org/style-guide).

### [EditorConfig](https://editorconfig.org)

We use a separate .editorconfig specifically for the chat app, take a look at it.

This is required to follow, so make sure your IDE supports it.

### [Prettier](https://prettier.io)
We use Prettier to make more robust and good looking code specifically in the chat app. We

This is optional, but feel free to add support for it in your IDE.

### [ESLint](https://eslint.org)
We use ESLint to check code for issues specifically in the chat app.

This is optional, but feel free to add support for it in your IDE.

## Testing
There are a few key things to note for developers and QA:
- Always disable HelpFlow Chrome extension when testing agent chat app
- Make sure that nobody else uses the same account when you are testing, otherwise it can cause conflicts like inability to sync status
- Always go to [LiveChat Chats page](https://my.livechatinc.com/chats) to check that what you have in agent chat app is in sync with LiveChat when testing, this can avoid many issues like understanding what happened with the chat, etc.

### Testing accounts
- `sandbox1@helpflow.net` account should be used for testing on staging **only by QA**
- `sandbox2@helpflow.net` account should be used for testing and development **only by Alex**
- `sandbox3@helpflow.net` account should be used for testing and development **only by Eric**

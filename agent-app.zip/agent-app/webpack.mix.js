let mix = require('laravel-mix');
let webpackConfig = require('./webpack.config');

mix.webpackConfig(webpackConfig)
   .setResourceRoot('/agent-app')
   .setPublicPath('../public/agent-app')
   .copyDirectory('src/assets', '../public/agent-app/assets')
   .js('src/app.js', '../public/agent-app')
   .js('src/workers/DetectWakeup.js', '../public/agent-app/workers')
   .vue()
   .version();

if (mix.inProduction()) {
  mix.sourceMaps();
}
